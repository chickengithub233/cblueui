#ifndef CBLUEUI_CEDITTEXTRICHUI_BLXDY_INC_H_
#define CBLUEUI_CEDITTEXTRICHUI_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CControlUI.h"
#include "CScrollBarUI.h"
#include "CEditLine.h"

namespace BUI {

/**
 * @brief 多行文本输入框(自主设计自绘，未使用系统原生编辑输入框,可方便移植到嵌入式平台)
 *
 */
class UI_EXP CEditRichUI : public CScrollAreaUI, public CEditLineStyle
{
	DECLARE_DYNAMIC_OBJ_CLASS(CEditRichUI)
  public:
	CEditRichUI();
	~CEditRichUI();

	void AppendEditText(LPCTSTR str, BOOL bRefresh = FALSE);
	void AppendEditTextA(LPCSTR str, BOOL bRefresh = FALSE);
	void GetEditText(BeString& str);

	CEditLine* InsertLine(int pos, LPCTSTR text, int count = -1, BOOL bRefresh = TRUE);
	void DeleteLine(int pos, int count, BOOL bRefresh = TRUE);
	void Clear(BOOL bRefresh = TRUE);

	void SelectSessionAll(BOOL isSelect, BOOL bRefresh);

	/* CEditLineStyle menthods:*/
	BOOL GetRectTextView(RECT& rc) override;

	/* CScrollAreaUI menthods:*/
	void OnControlSize() override;
	void OnShow(bool bShow) override;
	void OnCtrlKillFocus() override;
	void OnCtrlSetFocus() override; // ui控件获得焦点
	void OnFontChange() override;   // 字体更改
	// void  OnShow(bool bShow) override;
	// BOOL  OnTimerEvent(unsigned int timerid, UINT umsec) override;
	// BOOL  OnNcHitTest(POINT pt) override;
	BOOL OnLButtonDown(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonCliked(WPARAM wParam, LPARAM lParam) override;

	BOOL OnKeyDown(WPARAM wParam, LPARAM lParam) override;
	BOOL OnChar(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseMove(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

	/* override IControlUI menthos:*/
	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;

  protected:
	BOOL DoInputChar(WPARAM wParam, LPARAM lParam, BOOL isFocus);
	BOOL DoInputPreeditChar(WPARAM wParam, LPARAM lParam, BOOL isFocus);
	BOOL DoInputCommitChar(WPARAM wParam, LPARAM lParam, BOOL isFocus);
	void MergeLine(int line1, int line2);
	BOOL DeleteSession(RECT& rcUpdate);
	BOOL OnClickPoint(POINT pt);
	int FindLine(int dy, int& div);
	RECT GetRefreshRect(int line1, int line2);
	BOOL GetEditRangeLine(int& start, int& end);

	void ScrollHorzToPos(RECT& rcUpdate, int line, int pos, BOOL nearLeft); // 水平移动到指定字符
	void ScrollVertToPos(RECT& rcUpdate, int line, int pos, BOOL nearTop);  // 垂直移动到指定字符

	void MoveChars(int i);
	void MoveLine(int& line, int i, int dx);
	void UpdateSelectRangeState(int last_pos, RECT& rcUpdate);
	int GetScrollRangeX() const;
	int GetScrollRangeY(int no);

	int GetLineTextLeft(RECT& rcText) const;
	void PasteString();
	void CutString();
	void CopyString();

  protected:
	std::vector<CEditLine*> m_lines;
	std::vector<CEditLine*> m_lines_editing; // 激活态的
	int m_select_first;
	int m_first_cursor_pos;
	int m_select_last;
	int m_last_cursor_pos;
	int m_ver_dx; // 上下移动时记录偏移量
	POINT m_ptAutoMoveTrace;
};



}

#endif