#ifndef CBLUEUI_BUTTON_BLXDY_INC_H_
#define CBLUEUI_BUTTON_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CLabelUI.h"
#include "CBaseSelectState.h"
#include "CNodeCell.h"
#include "CNodeData.h"
#include "graphics/GImageIconInfo.h"


class GPathStorageSVG;

namespace BUI {

enum ButtonStyle
{
	TextButton, ///< 文本风格
	IconButton  ///< 图标风格
};

/**
 * @brief 按钮
 *
 */
class UI_EXP CButtonUI : public CLabelUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CButtonUI)
  protected:
	SIZE m_szTextDown; // 文本按下偏移量
  public:
	CButtonUI();
	~CButtonUI();

	void SetButtonStyle(ButtonStyle style);
	void SetTextOffsetWhenMouseDown(int dx, int dy); ///< 设置鼠标在按下状态时，文本的偏移量

	void ChangeThemeColors(int theme) override;
	void OnCreate() override;
	void Activate() override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonCliked(WPARAM wParam, LPARAM lParam) override;

	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;
};

/**
 * @brief 系统按钮
 *
 */
class UI_EXP CButtonSysUI : public CButtonUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CButtonSysUI)
  public:
	CButtonSysUI();
	~CButtonSysUI();

	void SetSysButtonType(CmdEventType btnType);

	void ChangeThemeColors(int theme) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	BOOL DoPaintBackGround(ISurface* pSurface, RECT* lpUpdate) override;

	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

  private:
	void drawSysButton(ISurface* pSurface, RECT rect);     ///< 绘制系统按钮
	void drawCloseButton(ISurface* pSurface, RECT rect);   ///< 绘制关闭按钮
	void drawMinSizeButton(ISurface* pSurface, RECT rect); ///< 绘制最小化按钮
	void drawMaxSizeButton(ISurface* pSurface, RECT rect); ///< 绘制最小化按钮
  private:
	UINT m_uSysType;
};

/**
 * @brief 菜单按钮
 *
 */
class UI_EXP CButtonMenuUI : public CControlUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CButtonMenuUI)
  private:
	UINT_PTR m_uCmdID;
	UINT m_uFlags;
	int m_nIicoWidth;
	BOOL m_bIsSubPopWnd; // 标识子菜单是实体窗口句柄，还是抽象的ui类型控件
	BeString m_textid;
	GImageIconInfo* m_icon;

  public:
	CButtonMenuUI();
	~CButtonMenuUI();

	UINT CheckMenuItem(UINT nCheck);

	BOOL MenuInfo(UINT nFlags, UINT_PTR nID, LPCTSTR lpszTextID = NULL, GImageIconInfo* const icon = NULL);

	void CloneAttribute(CControlUI* clone) override;
	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	void OnCtrlKillFocus() override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseMove(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseLeave(WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

  private:
	void darwCheckFlag(ISurface* pSurface, RECT rc, COLORREF color);
	void showPopMenu(CControlUI* pPopUI, bool bShow);
	void showParentPopMenu(bool bShow);
};

/**
 * @brief SVG图标按钮
 *
 */
class UI_EXP CButtonSVGUI : public CButtonUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CButtonSVGUI)
  private:
	GPathStorageSVG* m_svgPath;

  public:
	CButtonSVGUI();
	~CButtonSVGUI();

	void CloneAttribute(CControlUI* clone) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;
};

/**
 * @brief 切图按钮(普通，高亮，选中，禁用四种状态)横排和竖排皆可，顺序打乱也可以。
 *        结合实际开发经验，开发和美工属于不同的部门，虽然两个部门都有规范，但是人员流动带来的变动导致规范无法成型。此类支持美工任意切图。
 */
class UI_EXP CButtonImageUI : public CControlUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CButtonImageUI)
  public:
	CButtonImageUI();
	~CButtonImageUI();

	void CloneAttribute(CControlUI* clone) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;

  protected:
	GImageIconInfo* m_iconInfo;
};

/**
 * @brief 开关按钮控件，支持两种状态
 *
 */
class UI_EXP CButtonSwitchImageUI : public CControlUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CButtonSwitchImageUI)
  protected:
	BOOL m_bSelected;
	GImageIconInfo* m_sw_icon[2];

  public:
	CButtonSwitchImageUI();
	~CButtonSwitchImageUI();

	BOOL GetCheck();            // 获得Check状态  true 表示选中
	void SetCheck(BOOL bCheck); // 设置Check状态

	void CloneAttribute(CControlUI* clone) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;
};

/**
 * @brief 渐变按钮
 *
 */
class UI_EXP CButtonGradientUI : public CButtonUI, public CBrushGradientSet
{
	DECLARE_DYNAMIC_OBJ_CLASS(CButtonGradientUI)
  public:
	CButtonGradientUI();
	~CButtonGradientUI();

	void CloneAttribute(CControlUI* clone) override;
	BOOL DoPaintBorder(ISurface* pSurface, RECT* lpUpdate) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	BOOL DoPaintBackGround(ISurface* pSurface, RECT* lpUpdate) override;

	void ShellAttribute(const BeString& szName, const BeString& szText) override;
};

/**
 * @brief 组合复杂的按钮
 *
 */
class UI_EXP CButtonNodeUI : public CButtonUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CButtonNodeUI)
  public:
	CButtonNodeUI();
	~CButtonNodeUI();

	CNodeDataLists* GetNodeDataList();
	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;

  protected:
	CNodeDataLists m_nodeList;
};




}
#endif