#ifndef CBLUEUI_CNODEEDITORUI_BLXDY_INC_H_
#define CBLUEUI_CNODEEDITORUI_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "uicontrol/CControlUI.h"
#include "uicontrol/CContainLayoutUI.h"

namespace BUI {

struct ConnectPoint
{
	double x_per;
	double y_per;
	int dx;
	int dy;
	CControlUI* graphui;

	ConnectPoint()
	    : x_per(0)
	    , y_per(0)
	    , dx(0)
	    , dy(0)
	    , graphui(NULL){};

	POINT Position()
	{
		POINT pt = {0, 0};
		if (!graphui) return pt;
		RECT rcAbs = graphui->GetControlRect();
		pt.x       = (rcAbs.right - rcAbs.left) * x_per + rcAbs.left + dx;
		pt.y       = (rcAbs.bottom - rcAbs.top) * y_per + rcAbs.top + dy;

		return pt;
	};
};

struct ConnectEdge
{
	ConnectPoint u;
	ConnectPoint v;
};

/**
 * @brief 节点可视化(用于图布局和组态控制)
 *
 */
class UI_EXP CNodeEditorUI : public CContainLayoutUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CNodeEditorUI)

  private:
	std::vector<ConnectEdge> m_edges;
	COLORREF m_crEdgeLine;
	COLORREF m_crEdgePoint;

  public:
	CNodeEditorUI();
	virtual ~CNodeEditorUI();

	void AddEdge(ConnectEdge edge);
	void Clear(BOOL bRefresh = TRUE);

	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaintFinished(ISurface* pSurface, RECT* lpUpdate) override;
	void OnParseItemData(XMLItem* pNode) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;
};

}
#endif