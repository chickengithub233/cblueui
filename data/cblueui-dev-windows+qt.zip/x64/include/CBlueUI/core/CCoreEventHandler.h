﻿#ifndef CBLUEUI_CEVENTHANDLER_PRO_BLXDY_INC_H_
#define CBLUEUI_CEVENTHANDLER_PRO_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"
#include <vector>
#include <memory>
#pragma warning(disable : 4251)

namespace BUI {

class UI_EXP IEventHandler
{
  protected:
	IEventHandler();
	virtual ~IEventHandler();

  public:
	virtual BOOL OnMessageHandler(UINT message, WPARAM wp, LPARAM lp);
};

class UI_EXP INotifyHandler
{
  protected:
	INotifyHandler();
	virtual ~INotifyHandler();

  public:
	virtual BOOL OnNotifyMessage(IEventHandler* notify, UINT message, WPARAM wp, LPARAM lp);
};

class UI_EXP IActionNotify
{
  public:
	IActionNotify();
	virtual ~IActionNotify();

	virtual void DoAction() = 0;
};

class UI_EXP ActionList : public IActionNotify
{
  public:
	ActionList();
	~ActionList();

	void AddAction(std::shared_ptr<IActionNotify> notify);

	void DoAction() override;

  private:
	std::vector<std::shared_ptr<IActionNotify>> m_bind_list;
};

/* 基本交互事件组管理类*/
class UI_EXP EventTrigger
{
  public:
	EventTrigger();
	~EventTrigger();

	void BindActionNotify(ActionEvent ev, std::shared_ptr<IActionNotify> notify);

	void TriggerEvent(UINT message, WPARAM wp, LPARAM lp);

  private:
	std::shared_ptr<IActionNotify> m_events[6];
};

class UI_EXP IUserData
{
  public:
	IUserData(){};
	virtual ~IUserData(){};

	virtual void OnSelected() = 0;
};



}

#endif