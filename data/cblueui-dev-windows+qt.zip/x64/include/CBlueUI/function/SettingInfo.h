#ifndef CBLUEUI_SETTING_LITE_BLXDY_INC_H_
#define CBLUEUI_SETTING_LITE_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
#include <vector>
#include <string>
#include <memory>
#include "core/CCoreBasePro.h"
#include "MarkupItem.h"

namespace BUI {


enum StettingFileType
{
	JSON_FMT,
	XML_FMT,
};

/* JSON Types: */
#define JSON_NULL   0
#define JSON_False  1
#define JSON_True   2
#define JSON_Object 3
#define JSON_Array  4
#define JSON_String 5
#define JSON_Number 6

class UI_EXP SettingNode : public XMLItem
{
  public:
	SettingNode();
	~SettingNode();

	static SettingNode* AllocSettingNode(int type = JSON_String);

	SettingNode* AppendChild(int type);

	void Print(FILE* fp, BOOL bFormate, int depth);
	int type_;
};

/**
 * @brief 配置读写类(支持json，xml格式)且读取方式更灵活
 *
 */
class UI_EXP CSettingInfo
{
  public:
	CSettingInfo();
	~CSettingInfo();

	void Clear();
	void LoadBuffer(const char* data, BOOL no_write = FALSE, UINT filetyme = 0);

	void LoadFile(const TCHAR* filePath);

	void SaveAsFile(const TCHAR* filePath = NULL, BOOL is_format = TRUE);

	SettingNode* Root();

	BeString FilePath();

  protected:
	SettingNode m_treeRoot;
	BeString m_filefullname;
};

extern "C" {

/**
 * @brief 安装全局配置信息对象
 *
 */
UI_EXP void InstallSetingInfo(CSettingInfo* config);

/**
 * @brief 获得全局配置信息对象
 *
 */
UI_EXP CSettingInfo* GetCSettingInfo();
}


}


#endif
