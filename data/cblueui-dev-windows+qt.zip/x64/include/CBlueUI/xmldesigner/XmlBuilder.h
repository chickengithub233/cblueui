﻿#ifndef CBLUEUI_XML_PARSE_DESIGNER_H__
#define CBLUEUI_XML_PARSE_DESIGNER_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <assert.h>
#include <string>
#include <vector>
#include <map>

#include "core/CCoreBasePro.h"
#include "core/CCoreObject.h"
#include "core/CCoreEventHandler.h"
#include "function/XmlStorageA.h"
#include "function/XmlStorage.h"

namespace BUI {

class CControlUI;

struct ParseSetting
{
	IManageHandler* pManger;
	CControlUI* pParent;
	ILayout* pLayoutBox;
	IEventHandler* handler;
};

struct LayoutSize
{
	int layWidth;
	int layHeight;
	SizeMode wType;
	SizeMode hType;
};

typedef CControlUI* (*CreateControl_cb)(const TCHAR* typeName, const TCHAR* desClassName, const TCHAR* className);

/**
 * @brief UI构建工具类
 *
 */
class UI_EXP XmlBuilder
{
	typedef void (XmlBuilder::*ParseNodeProc_cb)(XMLItem* pNode, ParseSetting* param);

  public:
	XmlBuilder();
	virtual ~XmlBuilder();

	// 加载xml中的图片和文件资源
	static void ApplyResourceWithFile(const char* uixml);
	static void ApplyResourceWithFile(const WCHAR* uixml);
	static void ApplyResourceWithData(const char* data);

	/* 加载ui到指定控件内*/
	static int LoadControlUIFile(const char* file, CControlUI* pCtrl, IEventHandler* handler = NULL);
	static int LoadControlUIFile(const WCHAR* file, CControlUI* pCtrl, IEventHandler* handler = NULL);
	static int LoadControlUIString(const char* xmlcontent, CControlUI* pCtrl, IEventHandler* handler = NULL, BOOL no_write = TRUE);

	void SetDesignParse(BOOL bDesignParse);

	/* interface api*/
	void LoadUIFileA(LPCSTR filepath, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL);

	void LoadUIFileW(LPCWSTR filepath, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL);

	void LoadBuffer(const char* xmlText, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL, BOOL no_write = TRUE);
#ifdef _WIN32
	void LoadUIResource(UINT nID, LPCTSTR szType, HINSTANCE hMode, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL);
#endif
	void LoadUITempCache(XmlStorage* templat, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL);

	void ParseUiFileUNICODE(const WCHAR* wfilename, IManageHandler* pManger, CControlUI* pParent, ILayout* pParBox, IEventHandler* handler);

	void ParseUiFile(const char* filename, IManageHandler* pManger, CControlUI* pParent, ILayout* pParBox, IEventHandler* handler);

	void ParseNode(XMLItem* pNode, ParseSetting* param);

	void ParsePopManager(XMLItem* pXmlNode, ParseSetting* param);
	void ParseDesignWindow(XMLItem* pNode, ParseSetting* param);

	CControlUI* ParseControl(XMLItem* pNode, ParseSetting* param, CreateControl_cb lpCreateControl = NULL);

	ILayout* ParseAdsorbLayout(XMLItem* pNode, ParseSetting* param);

	void ParseNodedata(XMLItem* pNode, ParseSetting* param, CreateControl_cb lpCreateControl = NULL);

	void ParseControlFont(XMLItem* pNode, ParseSetting* param);

	void ParseImage(XMLItem* pNode, ParseSetting* param);

	void ParseDesignLayout(XMLItem* pNode, ParseSetting* param);

	void ParseLayout(XMLItem* pNode, ParseSetting* param);

	void ParseZipResurce(XMLItem* pNode, ParseSetting* param);

	void ParseSharedNode(XMLItem* pNode);

	void PreLoadClassStyle(XMLItem* root);

	XMLItem* GetStyleNode(const TCHAR* name);

  public:
	virtual void OnParseWindow(const TCHAR* desClassName, const TCHAR* className);
	virtual void OnParseControl(CControlUI* pObjCtl, const TCHAR* desClassName, const TCHAR* className, const TCHAR* objName);
	virtual CControlUI* OnParseDesLayout(IManageHandler* pM, CControlUI* parent, const TCHAR* layoutname, LayoutSize* infodata, ILayout** outBoxLayout);

  private:
	BeString m_skinModule;
	BeString m_prefix_path; // 路径前缀
	ParseNodeProc_cb m_ParseWindows_cbfun;
	ParseNodeProc_cb m_ParseLayoyt_cbfun;
	CreateControl_cb m_CreateControl_cbfun;
	std::map<std::tstring, XMLItem*> m_StroageStyle; // 共享风格缓存
	int m_szie_cx;
	int m_szie_cy;
	SizeMode m_nWidMode;
	SizeMode m_nHeiMode;
};




}

#endif