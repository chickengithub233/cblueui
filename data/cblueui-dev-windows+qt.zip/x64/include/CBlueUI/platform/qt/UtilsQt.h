﻿#ifndef BLUEUI_TOOLQTUTILS_18DD04_INC_H_
#define BLUEUI_TOOLQTUTILS_18DD04_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"
#include "cstring/String.h"
#include "cstring/StringA.h"
#include "cstring/StringShort.h"

#include <map>
#include <vector>
#include <string>

#include <qstring.h>
#include <qrect.h>


UI_EXP QString ConvertToQString(LPCTSTR text, int len = -1);

UI_EXP void ConvertToLPCTSTR(BeStringShort260& buffer, QString text);

UI_EXP RECT QRectConvertToRECT(const QRect& qrc);

UI_EXP int TextFormatToQAlign(UINT format);

UI_EXP int GetScreenIndex();                       // 获取当前屏幕索引

UI_EXP QRect GetScreenRect(bool available = true); // 获取当前屏幕尺寸区域
#endif
