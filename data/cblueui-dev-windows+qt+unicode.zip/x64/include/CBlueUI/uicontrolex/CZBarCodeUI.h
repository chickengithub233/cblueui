﻿#ifndef BLUEUI_CZBARCODEUI_BLXDY_INC_H_
#define BLUEUI_CZBARCODEUI_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "uicontrol/CControlUI.h"

namespace BUI {


UI_EXP BOOL ReadBarCode(BeString& out_text_code, BeString& out_barfmt, const uint8_t* buffer, int w, int h, XPixelFormat pixfmt);

class UI_EXP CZBarCodeUI : public CControlUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CZBarCodeUI)
  public:
	CZBarCodeUI();
	~CZBarCodeUI();

	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;
	void OnCreate() override;
	void OnControlSize() override;
	void OnCtrlKillFocus() override;

	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ChangeThemeColors(int theme) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

  private:
	BeString m_strCodeFormat;
	GImage* m_code_img;
	int m_margin;   // Margin around barcode
	int m_eccLevel; // Error correction level, [0 - 8]
	BOOL m_isChanged;
};


}
#endif
