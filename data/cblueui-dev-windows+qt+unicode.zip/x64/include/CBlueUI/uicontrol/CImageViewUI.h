#ifndef BLUEUI_IMAGEVIEW_BLXDY_INC_H_
#define BLUEUI_IMAGEVIEW_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CControlUI.h"

namespace BUI {

class UI_EXP CImageViewUI : public CControlUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CImageViewUI)
  private:
	GImageIconInfo* m_pImage;
	double m_scale;
	double m_angel;
	ImageRatioStyle m_PreserveAspRatio; // 纵横比方式
  public:
	CImageViewUI();
	~CImageViewUI();

	void SetImage(GImageIconInfo* pimg);
	void SetScale(double scale);
	void SetRoateAngel(double angel);
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;
};

// gif格式动画控件
class UI_EXP CGIFViewUI : public CControlUI, public IGIFHost
{
	DECLARE_DYNAMIC_OBJ_CLASS(CGIFViewUI)
  public:
	CGIFViewUI();
	~CGIFViewUI();

	void SetGifImage(GImageGIF* pGif);
	void Play();
	void Stop();

	/* CControlUI method:*/
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

	/* IGIFHost method:*/
	void OnUpdataUI() override;
	void OnUpdataAll() override;
	void OnFreeObject() override;

  private:
	GImageGIF* m_pGIF;
	UINT m_nCurpos;
};

}

#endif
