#ifndef BLUEUI_CTITLECONTAINERUI_BLXDY_INC_H_
#define BLUEUI_CTITLECONTAINERUI_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <memory>
#include "CControlUI.h"
#include "CScrollBarUI.h"
#include "CNodeCell.h"
#include "platform/UIManager.h"

#define MAX_COLUMN_COUNT 64

namespace BUI {

enum BoxHitState
{
	HT_COL_HEILIGHT,
	HT_COL_DRAG,
	HT_LIST_ROW,
	HT_NC_NONE,
	HT_ROW_CHECKBOX,
	HT_ROW_FOLD,
};

// 选择模式
// enum SelectMode{ SelectRow = 0, SelectCol, SelectCell, SelectNULL };
enum GridLineMode
{
	GridLineNone   = 0x00,
	GridLineX      = 0x01,
	GridLineY      = 0x02,
	GridLineBorder = 0x04
};

// 表头的单元格
class UI_EXP TableHeaderNodeCell : public CNodeCell, public MatchFeatures
{
  public:
	int m_nWidth;
	UINT m_uTxtAlign;
	int m_nColumShowPosition;  // 列显示的位置, 小于0，代表位置不变
	BOOL m_bEnableSort;        // 是否支持排序
	BOOL m_bNoCase;            // 是否忽略大小写
	DataType m_sortType;       // 排序值类型
	OrderByType m_orderType;   // 排序方式
	int m_nMinWidth;           // 最小宽度
	int m_nMaxWidth;           // 最大宽度
	bool m_bEnableExChangePos; // 可移动标志
	PaddingInfo m_padding;     // 单元格内容的边距
	std::shared_ptr<CControlUI> m_pEditorUI;

	BeString m_cell_className;

  public:
	TableHeaderNodeCell();
	TableHeaderNodeCell(std::shared_ptr<CNodeData> valuedata, int nColWidth, UINT nFormat);
	~TableHeaderNodeCell();

	void SetPadding(int l, int t, int r, int b);
	int Width() const;
	void SetWidth(int w);
	void SetWidthRange(int min_, int max_);
	void SetCellRect(int x, int y, int w, int h);
	void SetCellClassName(BeString& name);
	void EnableSort(BOOL bSort);
	void EnableExchangePos(bool benbale);
	bool IsExchangePos() const;
	TableHeaderNodeCell* HitTestCell(POINT pt);
	TableHeaderNodeCell* HitTestCellLine(POINT pt);

	std::shared_ptr<CNodeData> CreateThisColNodeData();
	void OnDrawTitleCellText(ISurface* pSurface, RECT rcCell, COLORREF textColor, UINT textAlignFlag, int dx = 0, int dy = 0);

	virtual BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam);
};

// 表头结构对象
class UI_EXP CContainTitleUI : public CScrollAreaUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CContainTitleUI)
  protected:
	std::vector<std::shared_ptr<TableHeaderNodeCell>> m_vecHeaderInfo; // 列信息数组
	std::vector<int> m_vecFilterRs;                                    // 可见的过滤结果
	COLORSTYLE m_titleBkColors;                                        // 标题栏背景颜色风格
	COLORSTYLE m_titleTextColors;                                      // 标题栏文本颜色风格
	COLORSTYLE m_gridColors;                                           // 网格线颜色风格
	COLORSTYLE m_LineNumTextColors;                                    // 行号文本颜色风格
	COLORREF m_crMoveCol;                                              // 移动行背景色
	PenType m_gridlineStyle;                                           // 网格线风格
	GFont* m_pTitleFont;                                               // 标题字体
	int m_nTrackWidth;
	int m_nTrackPosX;                                                  // 跟踪的位置
	int m_nHighlightColIndex;
	int m_nTrackCol;                                                   // 调整宽度原始状态
	TableHeaderNodeCell* m_pHighLight;
	TableHeaderNodeCell* m_pDragColCell;
	TableHeaderNodeCell* m_pSortCell;

	UINT m_uTitleHitFlag; // 鼠标状态标志
	int m_nLeadWidth;     // 前导宽度
	int m_nTitleHeight;   // 标题高度
	int m_FixColumCount;  // 表格表头固定功能,默认-1，无固定操作.

	int m_nMoveSourceCol; // 移动列索引
	int m_nMoveTargetCol; // 移动目标列索引

	bool m_bChangeWidth;  // 调整列宽使能
  public:
	CContainTitleUI();
	~CContainTitleUI();

	
	COLORREF GridLineColor() const;

	BOOL IsFixColum(int col) const;
	int SetColumFilterList(std::vector<int>& rs); // 设定可现实行的索引列表
	void ClearColumFilterList();                  // 恢复原状
	PenType GetGridLineStyle() const;
	void SetGridLineStyle(PenType penStyle);      // 设置网格线风格
	void SetMovingColor(COLORREF cr);             // 设置移动列的背景色

	void SetLeadWidth(int nWidth);                // 设置容器左侧边宽度
	int GetLeadWidth() const;
	int GetColumWidthSum() const;                 // 获得标题栏的总宽度
	int TitleHeight() const;                      // 标题高度
	void SetTitleHeight(int h);                   // 设置标题高度
	void SetFixColCount(int c);                   // 设置前缀固定行数量
	UINT TextAlign(UINT nCol) const;              // 获得列文本对齐方式
	int GetColWidth(UINT nCol) const;             // 获得列宽

	// colum impl
	int GetColumPos(int col) const;                 // 获得数据排序后的真实索引
	TableHeaderNodeCell* GetColumn(int ncol) const; // 获得标题栏单元格对象
	void SwapTitleColum(int c1, int c2);            // 交换列
	void MoveColumPos(int col, int ins_col);        // 移动列到ins_col位置
	void SetTitleFont(GFont* font);                 // 设置标题栏字体

	BOOL GetColumCellXBound(int col, int& x1, int& x2) const;
	int ColumnCount() const;              // 获得实际标题栏列总数
	int VisableColumnCount() const;       // 获得可见标题栏列总数
	void ClearColumn(BOOL bErase = TRUE); // 清空所有列
	void RemoveColum(UINT nCol);          // 删除指定列, nCol表示一级表头
	int SetColumns(std::vector<std::shared_ptr<TableHeaderNodeCell>>& titlelist);
	int InsertColumn(int nCol, std::shared_ptr<TableHeaderNodeCell> titleCell);
	int AppendColumn(std::shared_ptr<TableHeaderNodeCell> titleCell);

	int FindColumnIndexByName(BeString& name) const;                      // 根据名称id查询列号

	int GetColumnIndexByName(LPCTSTR szID) const;                         // 根据名称获得索引
	void SetColumnName(int nCol, LPCTSTR szID);                           // 设置列字符ID
	void SetColWidth(UINT nCol, int width);                               // 设置列宽

	void SetColumEditorUI(int nCol, std::shared_ptr<CControlUI> pEditor); // 设置列编辑ui


	// 子类重载接口列表
	virtual void OnReLayout();
	virtual void OnChangeHeaderColWidth();
	virtual void OnInsertColumn(int ncol, int sum);
	virtual void OnDeleteColumn(int ncol, int sum);
	virtual void OnSortColum(int ncol, OrderByType ordertype, DataType sortType, BOOL bNoCase);
	virtual void OnPaintMovingColum(int ncol, int dx, ISurface* pSurface, RECT* lpUpdate);

	void ChangeThemeColors(int theme) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;
	void OnParseItemData(XMLItem* pNode) override;
	void OnControlSize() override;
	BOOL OnNcHitTest(POINT pt) override;
	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonDown(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonCliked(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseMove(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseLeave(WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	int LayoutAdaptWidth(int expH) override;

	CControlUI* HitTestControl(POINT pt) override;

  protected:
	void GetColumnAreaRect(int col, RECT* rc); // 获得列显示区域,包含了title高度
	int PtInColumn(int x);
	int PtInTargetColumn(int x);
	int GetFixColumWidth() const;
	BOOL PtInTitle(POINT pt) const;
	TableHeaderNodeCell* GetAbsColumn(int ncol) const; // 获得标题栏单元格对象

  private:
	UINT hitTestColLine(POINT pt) const;
	TableHeaderNodeCell* hitTestHeaderCell(POINT pt) const;
	TableHeaderNodeCell* hitTestHeaderCellLine(POINT pt) const;
};



}

#endif