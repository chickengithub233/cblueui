﻿#ifndef BLUEUI_LABEL_BLXDY_INC_H_
#define BLUEUI_LABEL_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CControlUI.h"
#include "CNodeDataQuote.h"

namespace BUI {


class UI_EXP CLabelUI : public CControlUI, public CTextLayout
{
	DECLARE_DYNAMIC_OBJ_CLASS(CLabelUI)
  public:
	CLabelUI();
	~CLabelUI();


	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;
	void ChangeThemeColors(int theme) override;
	void OnCreate() override;
	void OnControlSize() override;
	void OnCtrlKillFocus() override;

	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;
};

class UI_EXP CLineUI : public CControlUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CLineUI)
  public:
	CLineUI();
	~CLineUI();

	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

  protected:
	int m_line_size;
	BOOL m_isHorzLine;
	int m_pos_percent;
	PenType m_line_bru_type;
};

struct ArrowPoint
{
	CControlUI* ui;
	SizeValue x;
	SizeValue y;

	ArrowPoint()
	    : ui(NULL)
	{}
};

class UI_EXP CLineArrowUI : public CControlUI
{
	DECLARE_DYNAMIC_OBJ_CLASS(CLineArrowUI)
  public:
	CLineArrowUI();
	~CLineArrowUI();

	BOOL HitTest(POINT pt) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void OnParseItemData(XMLItem* pNode) override;
	void ShellAttribute(const BeString& szName, const BeString& szText) override;

  protected:
	int m_arc_size;
	int m_arrow_size;
	int m_line_size;
	PenType m_line_bru_type;
	ArrowPoint m_point_start;
	ArrowPoint m_point_end;
};



}
#endif