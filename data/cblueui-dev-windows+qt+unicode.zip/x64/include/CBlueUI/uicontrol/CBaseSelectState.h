#ifndef BLUEUI_COPTIONSTATE_BLXDY_INC_H_
#define BLUEUI_COPTIONSTATE_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CControlUI.h"

namespace BUI {

enum CommandScope
{
	S_GLOBAL,  // 全局
	S_CURRENT, // 当前
	S_CHILD    // 子
};

enum CommandLinkageType
{
	CLT_VISIBLE = 1,
	CLT_ENABLE,
	CLT_USER,
};

struct CommandLinkage
{
	std::map<CommandScope, std::vector<BeString> > cmdlines;
};

class UI_EXP CSelectState
{
  public:
	CSelectState(CControlUI* ui);
	~CSelectState();

	void SetSelected(BOOL bSelect);
	BOOL IsSelected() const;
	void ShellSelectAttribute(const BeString& szName, const BeString& szText);

  protected:
	CControlUI* m_host_ui;                 // 宿主ui
	SelectState m_selectState;             // 控件状态
	std::map<UINT, CommandLinkage> m_cmds; // 关联动作命令。key = CommandLinkageType
};



}
#endif