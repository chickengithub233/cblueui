#ifndef CWIDGETQT_UI_H
#define CWIDGETQT_UI_H

#pragma once

#include <qwidget.h>
#include <qeventloop.h>
#include "core/CCoreBasePro.h"

#ifdef __APPLE__
void CocoaWindowTitleLess(QWidget* qwin, BOOL isShow);
#endif

namespace BUI {

class UI_EXP CWidgetQt : public QWidget
{
  public:
	CWidgetQt(QWidget* parent = nullptr);
	~CWidgetQt();

	void SetStandardButtonHidden(int type, bool show);

	unsigned int DoModal();

	void EnableDragMove(BOOL isDragMove); // 窗口是否可以拖拽移动


	void CenterWindow(); /* 居中显示*/

	void ExitEventLoop();
	// void SetPopWindowStyle();
  protected:
	void paintEvent(QPaintEvent* event) override;
	bool event(QEvent* e) override;
	void closeEvent(QCloseEvent* event) override;
	void showEvent(QShowEvent* event) override;
	void hideEvent(QHideEvent* event) override;
	// 拖拽窗口
	void mousePressEvent(QMouseEvent* event) override;
	void mouseMoveEvent(QMouseEvent* event) override;
	void mouseReleaseEvent(QMouseEvent* event) override;

  protected:
	QEventLoop m_eventLoop;
	QPointF m_mouseStartPoint;
	QPointF m_windowTopLeftPoint;
	BOOL m_isEnableDragMove;
};

}
#endif
