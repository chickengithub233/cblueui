﻿#ifndef BLUEUI_GRADIENTBRUSH_BLXDY_INC_H_
#define BLUEUI_GRADIENTBRUSH_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <map>
#include "core/CCoreBasePro.h"
#include "core/CGeometryStruct.h"
#include "core/Transform2d.h"
#include "GColor.h"
#include "GPathStorage.h"

namespace BUI {

enum BrushStyle
{
	BRUSH_SOLID,
	GRADIENT_LINEAR,
	GRADIENT_RADIAL,
	GRADIENT_CONIC
};

// 2d trans_affine
struct TransformGradient : public Transform2d
{
	BrushStyle gradient_bru;

	TransformGradient()
	    : gradient_bru(GRADIENT_LINEAR)
	{}
};

UI_EXP void CalcLinearGradientTransform(double x1, double y1, double x2, double y2, TransformGradient& mtx, double gradient_d2 = 100.0);

UI_EXP void CalcRadialGradientTransform(double cx, double cy, double rx, double ry, double angel, TransformGradient& mtx, double gradient_d2 = 100.0);

UI_EXP void RotationGradientTransform(Transform2d& mtx, double dx, double dy);

class UI_EXP PathTransformAffine : public PathTransform
{
  public:
	PathTransformAffine();
	PathTransformAffine(Transform2d& mtx);
	Transform2d& GetTransform2d();
	virtual ~PathTransformAffine();
	void Transform(double* x, double* y) override;
	void Transform2x2(double* x, double* y) override;

  public:
	Transform2d m_affine;
};

/**
 * @brief 渐变的渲染颜色
 *   + Size() 返回颜色细腻程度。值越大，代表颜色细致
 *   + operator[] 返回颜色值
 */
class UI_EXP GradientColors
{
  public:
	GradientColors() {}

	virtual ~GradientColors() {}

	virtual void SetColorsSize(int size) = 0; // 设置颜色细腻程度

	virtual unsigned Size() const = 0;

	virtual GColor operator[](unsigned i) = 0;
};

/**
 * @brief 双值线性颜色表
 *
 */
class UI_EXP GradientLinearColors : public GradientColors
{
  public:
	GradientLinearColors(const GColor& c1, const GColor& c2);
	virtual ~GradientLinearColors();

	UINT Size() const override;
	void SetColorsSize(int size) override;

	GColor operator[](unsigned i) override;

  private:
	unsigned m_size;
	GColor m_c1;
	GColor m_c2;
};

/**
 * @brief 相位颜色表
 *
 */
class UI_EXP GradientLinearPhaseColors : public GradientColors
{
  public:
	GradientLinearPhaseColors(GColorHSV c1, GColorHSV c2);
	virtual ~GradientLinearPhaseColors();

	UINT Size() const override;
	void SetColorsSize(int size) override;

	GColor operator[](unsigned i) override;

  private:
	unsigned m_size;
	GColorHSV m_c1;
	GColorHSV m_c2;

	GColorHSV m_cdx;
};

/**
 * @brief 自定义位置线性颜色表
 *
 */
class UI_EXP GradientStopsColors : public GradientColors
{

  public:
	GradientStopsColors();
	virtual ~GradientStopsColors();

	void SetColorsSize(int size) override;
	unsigned Size() const override;
	GColor operator[](unsigned i) override;

	void AddColor(double offset, const GColor& color);

	void SetProfilePoint(std::map<double, GColor>& points);

	void SetRangeOfKey(double fmin, double fmax);
	void ClearProfilePoint();

	BOOL IsColorEmpty() const;

	int ProfilePointSize() const;
	void BuildLutColorBuffer();

  private:
	void Release();

  private:
	std::map<double, GColor> m_profile_point; // key:在[m_min, m_max]的值。默认范围为[0~1]
	double m_min;
	double m_max;
	unsigned m_Lut_size;
	GColor* m_colorbuffer;
	unsigned m_capacity;
};

class UI_EXP GBrushGradient
{
  public:
	GBrushGradient();
	virtual ~GBrushGradient();
	void SetGradientColors(GradientColors* colors); // 设置不同状态下的颜色表
	GradientColors* GetStatusColors() const;
	TransformGradient& GradientTransMtx();

	virtual void ApplyBrushTransform(PathTransform* trans);
	virtual void ApplyBrushRect(RECT rc) = 0;

  protected:
	GradientColors* m_stopcolors;
	TransformGradient m_mtx;
};

class UI_EXP GBrushGradientLinear : public GBrushGradient
{
  public:
	GBrushGradientLinear();
	GBrushGradientLinear(const Point2d& p1, const Point2d& p2);
	GBrushGradientLinear(double x1, double y1, double x2, double y2);
	~GBrushGradientLinear();

	void SetPosition(const Point2d& p1, const Point2d& p2); // 线性渲染的起始坐标。坐标由百分比表示
	void ShellGradientAttribute(const BeString& szName, const BeString& szText);

	void ApplyBrushTransform(PathTransform* trans) override;
	void ApplyBrushRect(RECT rc) override;

  protected:
	Point2d m_pt1;
	Point2d m_pt2;
};

class UI_EXP GBrushGradientRadial : public GBrushGradient
{
  public:
	GBrushGradientRadial();
	GBrushGradientRadial(float x, float y, float r, float fx, float fy, float angel = 0);
	~GBrushGradientRadial();

	void SetRotateAngel(float angel);
	void SetPosition(const Point2d& ptcenter, float r, float fx, float fy); // 放射渲染的中心坐标。坐标由百分比表示
	void ShellGradientAttribute(const BeString& szName, const BeString& szText);

	void ApplyBrushTransform(PathTransform* trans) override;
	void ApplyBrushRect(RECT rc) override;

  protected:
	Point2d m_ptcenter;
	float m_r;
	float m_fx;
	float m_fy;
	float m_angel; // 起点偏移左侧水平基线角度。[0~360]
};

class UI_EXP GBrushGradientConic : public GBrushGradient
{
  public:
	GBrushGradientConic();
	GBrushGradientConic(float x, float y, float angel = 0);
	~GBrushGradientConic();
	void SetRotateAngel(float angel);
	void SetPosition(const Point2d& ptcenter); // 放射渲染的中心坐标。坐标由百分比表示
	void ShellGradientAttribute(const BeString& szName, const BeString& szText);

	void ApplyBrushTransform(PathTransform* trans) override;
	void ApplyBrushRect(RECT rc) override;

  protected:
	Point2d m_ptcenter;
	float m_r;
	float m_fx;
	float m_fy;
	float m_angel;
};

class UI_EXP CBrushGradientSet
{
  public:
	CBrushGradientSet();
	~CBrushGradientSet();

	void SetBrushGradient(ShowStatus state, GBrushGradient* bru);
	GBrushGradient* GetBrushGradient(ShowStatus state) const;

  protected:
	GBrushGradient* m_bru[UIS_COUNT];
};




}
#endif