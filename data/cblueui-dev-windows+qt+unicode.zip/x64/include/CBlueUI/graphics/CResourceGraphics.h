
#ifndef BLUEUI_CRESOURCEGRAPHICS_BLXDY_INC_H_
#define BLUEUI_CRESOURCEGRAPHICS_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"
#include "core/CCoreChartDefs.h"
#include "cstring/String.h"
#include "cstring/StringA.h"

#include <map>
#include <memory>

namespace BUI {

class GImage;
class GImageGIF;
class GPathStorageSVG;
class GradientColors;
class GBrushGradient;
class GImageIconInfo;
#ifdef USE_MINIZIP
class FileReaderZip;
#endif

class UI_EXP CResourceGraphics
{
  public:
	CResourceGraphics();
	~CResourceGraphics();

  private:
	std::map<BeString, std::map<BeString, COLORREF>> m_mapColors;
	std::map<BeString, GImage*> m_mapSGimg;
	std::map<BeString, GImageGIF*> m_mapSGimgGif;
	std::map<BeString, GPathStorageSVG*> m_mapSvg;

	std::map<BeString, GradientColors*> m_mapGradientColors;
	std::map<BeString, GBrushGradient*> m_mapGradientBrush;

	std::map<BeString, GImageIconInfo*> m_mapImageStatus; // 图标组合状态
#ifdef USE_MINIZIP
	std::map<BeString, FileReaderZip*> m_mapZip;
#endif

	std::map<BeString, std::shared_ptr<CandlesStyle>> m_mapCandlesStyle; // K线图样式
	std::map<BeString, std::shared_ptr<BoxPlotStyle>> m_mapBoxPlotStyle; // 盒子图样式
  public:
	// GImage资源
	GImage* LoadSGImageFromBuffer(const BeString& keyid, unsigned char* buffer, UINT dwSize);
	GImage* GetSGImage(const BeString& keyid);

	// GImage GIF资源
	GImageGIF* LoadSGImageGIFFromBuffer(const BeString& keyid, unsigned char* buffer, UINT dwSize);
	GImageGIF* GetSGImageGIF(const BeString& keyid);

	// SVG_HANDLE资源
	GPathStorageSVG* LoadSVGFromBuffer(const BeString& keyid, const char* buffer, UINT dwSize);
	GPathStorageSVG* GetSVGImage(const BeString& keyid);

	// Colors资源
	void AddColors(const BeString& keyid, std::map<BeString, COLORREF>& colors);
	void GetColors(const BeString& keyid, COLORSTYLE& outColors);

	// Gradient Colors资源
	void AddGradientColors(const BeString& keyid, GradientColors* gra_colors);
	GradientColors* GetGradientColors(const BeString& keyid);


	// Gradient brush
	void AddGradientBrush(const BeString& keyid, GBrushGradient* linear);
	GBrushGradient* GetGradientBrush(const BeString& keyid);


	// Gradient brush
	void AddSGImageIconInfo(const BeString& keyid, GImageIconInfo* icon);
	GImageIconInfo* GetSGImageIconInfo(const BeString& keyid);

	// zip resource
	DataBuffer GetZipArchiveFileData(const char* zipfile, const char* archiveName);

	void AddCandlesStyle(const BeString& keyid, std::shared_ptr<CandlesStyle> style);
	std::shared_ptr<CandlesStyle> GetCandlesStyle(const BeString& keyid);

	void AddBoxPlotStyle(const BeString& keyid, std::shared_ptr<BoxPlotStyle> style);
	std::shared_ptr<BoxPlotStyle> GetBoxPlotStyle(const BeString& keyid);
};

// 安装资源管理对象
UI_EXP void InstallResourceGraphics(CResourceGraphics* res);

// 获得资源管理对象
UI_EXP CResourceGraphics* ResourceGraphics();

}

#endif