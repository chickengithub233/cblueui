#ifndef BLUEUI_DATEINFO_UNTILS_BLXDY_INC_H_
#define BLUEUI_DATEINFO_UNTILS_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"

struct LunarDate
{
	int32_t lunarYear;
	int32_t lunarMonth;
	int32_t lunarDay;
	int32_t solarYear;
	int32_t solarMonth;
	int32_t solarDay;
	int32_t weekNumber;
	int32_t termIndex;
	bool isToday, isLeap;
};

class UI_EXP DateInfo
{
  public:
	DateInfo(int year = 1901, int month = 1, int day = 1);
	DateInfo(const DateInfo& d);

	BOOL IsLeapYear() const;
	void Zero();
	BOOL IsZero() const;

	int WeekFirstDay(int year, int month); // 计算当前月的第一天是星期几
	int DayOfTheWeek();                    // 获得周几

	DateInfo operator+(int day);           // 日期加天数
	DateInfo operator-(int day);           // 日期减天数

	bool operator==(const DateInfo& d);
	bool operator!=(const DateInfo& d);
	bool operator<=(const DateInfo& d);
	bool operator>=(const DateInfo& d);

	bool operator<(const DateInfo& d);
	bool operator>(const DateInfo& d);
	DateInfo& operator=(const DateInfo& d);

	void PrintfLunarDate(char* buffer, int buffersize) const; // 农历日期

	void PrintfLunarYear(char* buffer, int buffersize) const; // 农历生肖年份
	int MonthDayCounts() const;                               // 计算当年月的天数


  public:
	int m_year;       // 年
	int m_month;      // 月
	int m_dayOfMonth; // 日
};


#endif
