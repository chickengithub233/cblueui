#ifndef BLUEUI_XML_XMLSTORAGEW_BLXDY_INC_H_
#define BLUEUI_XML_XMLSTORAGEW_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <assert.h>
#include <string>
#include <vector>

#include "core/CCoreBasePro.h"
#include "cstring/StringA.h"
#include "cstring/String.h"
#include "MarkupItem.h"


typedef BOOL (*TransformTextProcW)(BeStringW& outstr, LPCWSTR text);

namespace BUI {

class UI_EXP XmlStorageW
{
  private:
	TransformTextProcW m_key_transform;
	XMLItemW m_treeRoot;
	BeStringW m_filebaseName;
	std::vector<BeStringW> m_share;

  public:
	static void SaveAsXmlFile(const XMLItemW* root, const char* filepath);

	XmlStorageW(TransformTextProcW func = NULL);
	XmlStorageW(const char* file_utf8, TransformTextProcW func = NULL);
	XmlStorageW(const WCHAR* file, TransformTextProcW func = NULL);
	~XmlStorageW();

	int LoadBuffer(const char* data, int len = -1, BOOL no_write = FALSE);

	BeStringW AddShareLabel(const char* str, int len, BOOL isKey = FALSE);
	BeStringW FileBaseName() const;

	XMLItemW* Root();
};

#if defined(UNICODE) || defined(_UNICODE)
typedef XmlStorageW XmlStorage;
#endif


}
#endif