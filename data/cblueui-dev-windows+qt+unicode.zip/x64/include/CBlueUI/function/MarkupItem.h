﻿#ifndef BLUEUI_BASE_MARKUPITEM_BLXDY_INC_H_
#define BLUEUI_BASE_MARKUPITEM_BLXDY_INC_H_

#include "core/CCoreBasePro.h"
#include "cstring/StringA.h"
#include "cstring/String.h"
#include <vector>

namespace BUI {

UI_EXP void ParseLayoutModel(LPCTSTR szText, int* wl, int* hl, SizeMode* tw, SizeMode* th);

class UI_EXP StringPairA
{
  public:
	BeStringA m_name;
	BeStringA m_value;

	StringPairA();
	StringPairA(const BeStringA& name, const BeStringA& value);
	StringPairA(const StringPairA& pair);
	~StringPairA();
};

class UI_EXP XMLItemA
{
  public:
	XMLItemA();
	~XMLItemA();
	StringPairA& LabelPair();

	void Clear();
	size_t GetChildCounts() const;
	XMLItemA* GetChildObject(int index) const;
	StringPairA& AttrbuteTextPair(unsigned int i);

	unsigned int AttrbuteCount() const;

	XMLItemA* FirstChild() const;

	XMLItemA* LastChild() const;

	XMLItemA* PrevSibling() const;

	XMLItemA* NextSibling() const;

	XMLItemA* Parent() const;

	BOOL FindAttribute(const char* name, BeStringA& outstr);

	long FindAttributeInt(const char* name, long default_value);

	double FindAttributeFloat(const char* name, double default_value);

	XMLItemA* FindChildByName(const char* name) const;

	XMLItemA* FindObjectByKeyPath(const char* keyPath) const;
	// 不用递归的遍历时调用
	static XMLItemA* NextItem(XMLItemA* item);

  public:
	XMLItemA* parent;
	XMLItemA* firstChild;
	XMLItemA* lastChild;
	XMLItemA* prevSibling;
	XMLItemA* nextSibling;
	StringPairA label;
	std::vector<StringPairA> attributeList;
};

class UI_EXP StringPairW
{
  public:
	BeStringW m_name;
	BeStringW m_value;

	StringPairW();
	StringPairW(const BeStringW& name, const BeStringW& value);
	StringPairW(const StringPairW& pair);
	~StringPairW();
};

class UI_EXP XMLItemW
{
  public:
	XMLItemW();
	~XMLItemW();

	StringPairW& LabelPair();

	void Clear();
	size_t GetChildCounts() const;
	XMLItemW* GetChildObject(int index) const;
	StringPairW& AttrbuteTextPair(unsigned int i);

	unsigned int AttrbuteCount() const;

	XMLItemW* FirstChild() const;

	XMLItemW* LastChild() const;

	XMLItemW* PrevSibling() const;

	XMLItemW* NextSibling() const;

	XMLItemW* Parent() const;

	BOOL FindAttribute(const WCHAR* name, BeStringW& outstr);

	long FindAttributeInt(const WCHAR* name, long default_value);

	double FindAttributeFloat(const WCHAR* name, double default_value);

	XMLItemW* FindChildByName(const WCHAR* name) const;
	XMLItemW* FindObjectByKeyPath(const WCHAR* keyPath) const;
	// 不用递归的遍历时调用
	static XMLItemW* NextItem(XMLItemW* item);

  public:
	XMLItemW* parent;
	XMLItemW* firstChild;
	XMLItemW* lastChild;
	XMLItemW* prevSibling;
	XMLItemW* nextSibling;
	StringPairW label;
	std::vector<StringPairW> attributeList;
};

#if defined(UNICODE) || defined(_UNICODE)
typedef StringPairW StringPair;
typedef XMLItemW XMLItem;
#else
typedef StringPairA StringPair;
typedef XMLItemA XMLItem;
#endif

}

#endif