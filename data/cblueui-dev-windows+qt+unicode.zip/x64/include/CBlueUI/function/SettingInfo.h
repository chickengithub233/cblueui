#ifndef BLUEUI_SETTING_LITE_BLXDY_INC_H_
#define BLUEUI_SETTING_LITE_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
#include <vector>
#include <string>
#include <memory>
#include "core/CCoreBasePro.h"
#include "MarkupItem.h"

namespace BUI {


enum StettingFileType
{
	JSON_FMT,
	XML_FMT,
};

class UI_EXP SettingNode : public XMLItem
{
  public:
	SettingNode();
	~SettingNode();
	void Print(FILE* fp, BOOL bFormate, int depth) const;
	int type_;
};

class UI_EXP CSetttingInfo
{
  public:
	CSetttingInfo();
	~CSetttingInfo();

	void Clear();
	void LoadBuffer(const char* data, BOOL no_write = FALSE, UINT filetyme = 0);

	void LoadFile(const TCHAR* filePath);

	void SaveAsFile(const TCHAR* filePath = NULL, BOOL is_format = TRUE);

	SettingNode* Root();

  protected:
	SettingNode m_treeRoot;
	BeString m_filefullname;
};





}


#endif
