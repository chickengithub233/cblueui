#ifndef BLUEUI_XML_XMLSTORAGEA_BLXDY_INC_H_
#define BLUEUI_XML_XMLSTORAGEA_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <assert.h>
#include <string>
#include <vector>

#include "core/CCoreBasePro.h"
#include "cstring/StringA.h"
#include "cstring/String.h"
#include "MarkupItem.h"


typedef BOOL (*TransformTextProcA)(BeStringA& outstr, LPCSTR text);

namespace BUI {



class UI_EXP XmlStorageA
{
  private:
	TransformTextProcA m_key_transform;
	XMLItemA m_treeRoot;
	BeString m_filebaseName;
	std::vector<BeStringA> m_share;

  public:
	static void SaveAsXmlFile(const XMLItemA* root, const char* filepath);

	XmlStorageA(TransformTextProcA func = NULL);
	XmlStorageA(const char* file_utf8, TransformTextProcA func = NULL);
	XmlStorageA(const WCHAR* file, TransformTextProcA func = NULL);

	~XmlStorageA();
	int LoadBuffer(const char* xmlText, int len = -1, BOOL no_write = FALSE);

	BeStringA AddShareLabel(const char* str, int len, BOOL isKey = FALSE);
	BeString FileBaseName() const;

	XMLItemA* Root();
};

#if !defined(UNICODE) && !defined(_UNICODE)
typedef XmlStorageA XmlStorage;
#endif

}
#endif