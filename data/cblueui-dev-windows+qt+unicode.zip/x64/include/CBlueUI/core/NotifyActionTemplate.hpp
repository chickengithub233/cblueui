﻿
/*
This template requires c++11 standard
*/
#ifndef BLUEUI_NOTIFYACTIONTEMPLATE_PRO_BLXDY_INC_H_
#define BLUEUI_NOTIFYACTIONTEMPLATE_PRO_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"
#include "core/CCoreEventHandler.h"
#include "core/CCoreCharFunction.h"
// c standard
#include <stdlib.h>
// c++ standard
#include <vector>
#include <functional>

template<typename T = void()>
class FunctionActuator;

template<typename Ret, typename... Args>
class FunctionActuator<Ret(Args...)>
{
  public:
	typedef Ret value_type;
	typedef std::function<Ret(Args...)> CallValueFunc;

	FunctionActuator(CallValueFunc call)
	    : m_func(call)
	{
	}

	~FunctionActuator()
	{
	}

	value_type operator()(Args... args)
	{
		return m_func(args...);
	}

	value_type operator()(Args... args) const
	{
		return m_func(args...);
	}

  protected:
	CallValueFunc m_func;
};


template<typename T = void()>
class FunctorAction;

template<typename Ret>
class FunctorAction<Ret()> : public FunctionActuator<Ret()>, public BUI::IActionNotify
{
	typedef std::function<Ret()> CallValueFunc;

  public:
	FunctorAction(CallValueFunc call)
	    : FunctionActuator<Ret()>(call)
	{
	}

	~FunctorAction()
	{
	}

	void DoAction() override
	{
		FunctionActuator<Ret()>::m_func();
	}
};



template<typename funtype>
class FunctorLists;

template<typename Ret, typename Param>
class FunctorLists<Ret(Param)>
{
  public:
	typedef std::shared_ptr<FunctionActuator<Ret(Param)>> FunctorPtr;
	typedef Param param_type;

	FunctorLists()
	{
	}

	~FunctorLists()
	{
	}

	void AddFunctor(FunctorPtr ptr)
	{
		m_callers.push_back(ptr);
	}

	Ret operator()(Param par)
	{
		int len = m_callers.size();
		for (int i = 0; i < len; ++i)
			(*m_callers[i])(par);
	}

	Ret operator()(Param par) const
	{
		int len = m_callers.size();
		for (int i = 0; i < len; ++i)
			(*m_callers[i])(par);
	}

  protected:
	std::vector<FunctorPtr> m_callers;
};

template<class InputDataType>
class ConvertTextToInt
{
  public:
	typedef int value_type;

	ConvertTextToInt(InputDataType data)
	    : m_data(data)
	{
	}

	~ConvertTextToInt()
	{
	}

	value_type operator()()
	{
		LPCTSTR str = (LPCTSTR)m_data();
		long num = _tcstoll(str, NULL, 10);
		return num;
	}

	value_type operator()() const
	{
		LPCTSTR str = (LPCTSTR)m_data();
		long num = _tcstoll(str, NULL, 10);
		return num;
	}

  private:
	InputDataType m_data;
};

template<class InputDataType>
class ConvertTextToDouble
{
  public:
	typedef double value_type;

	ConvertTextToDouble(InputDataType data)
	    : m_data(data)
	{
	}

	~ConvertTextToDouble()
	{
	}

	value_type operator()()
	{
		return do_convert();
	}

	value_type operator()() const
	{
		return do_convert();
	}

  protected:
	value_type do_convert() const
	{
		LPCTSTR str = m_data();
		double fnum = _tcstod(str, NULL);
		return fnum;
	}

  private:
	InputDataType m_data;
};

template<class InputDataType>
class ConvertTextToRadian
{
  public:
	typedef double value_type;

	ConvertTextToRadian(InputDataType data)
	    : m_data(data)
	{
	}

	~ConvertTextToRadian()
	{
	}

	value_type operator()()
	{
		return do_convert();
	}

	value_type operator()() const
	{
		return do_convert();
	}

  protected:
	value_type do_convert() const
	{
		double fnum = m_data();
		fnum = PI * fnum / 180.0;
		return fnum;
	}

  private:
	InputDataType m_data;
};

template<class InputDataType>
class ConvertStringToText
{
  public:
	typedef LPCTSTR value_type;

	ConvertStringToText(InputDataType data)
	    : m_data(data)
	{
	}

	~ConvertStringToText()
	{
	}

	value_type operator()()
	{
		return m_data().c_str();
	}

	value_type operator()() const
	{
		return m_data().c_str();
	}

  private:
	InputDataType m_data;
};











#endif
