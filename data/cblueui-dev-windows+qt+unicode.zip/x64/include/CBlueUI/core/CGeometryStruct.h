﻿/*
 * Geometry Data Structure Definition
 */

#ifndef BLUEUI_CBASEUTILS_BLXDY_INC_H_
#define BLUEUI_CBASEUTILS_BLXDY_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "CCoreBasePro.h"

namespace BUI {

struct Point2d
{
	double x;
	double y;
};

// 向量
class UI_EXP Vector2d
{
  public:
	double dx;
	double dy;

  public:
	Vector2d();
	Vector2d(double x, double y);
	Vector2d(int x, int y);
	Vector2d(long x, long y);
	Vector2d(const Vector2d& vt);
	~Vector2d();

	double Length() const;
	Vector2d NormalVector() const; // 获得法向量

	void Normalization();          // 标准化向量
	void PositiveSign();           // 正向化
	void Inverse();                // 反向
	void Multiply(double k);

	const Vector2d& operator=(const Vector2d& other);
	Vector2d operator-(const Vector2d& other);
	Vector2d operator+(const Vector2d& other);
	double operator*(const Vector2d& other);
};

// 点
class UI_EXP GPoint
{
  public:
	GPoint();
	GPoint(long x_, long y_);
	~GPoint();
	void Translate(long dx_, long dy_);
	const GPoint& operator=(const GPoint& other);
	const GPoint& operator-(const GPoint& other);

  public:
	long x;
	long y;
};

// double 2d point
class UI_EXP Point2Double
{
  public:
	Point2Double();
	Point2Double(double x_, double y_);
	~Point2Double();
	void Translate(double dx_, double dy_);
	const Point2Double& operator=(const Point2Double& other);
	const Point2Double& operator-(const Point2Double& other);

  public:
	double x;
	double y;
};

// double 3d point
class UI_EXP Point3D : public Point2Double
{
  public:
	Point3D();
	Point3D(double x_, double y_, double z_);
	~Point3D();
	void Translate(double dx_, double dy_, double dz_);
	const Point3D& operator=(const Point3D& other);
	const Point3D& operator-(const Point3D& other);

  public:
	double z;
};

// 矩形区域
class UI_EXP GRect
{
  public:
	GRect();
	GRect(int l, int t, int r, int b);
	GRect(const GRect& rt);

  public:
	BOOL IsRectEmpty() const;
	BOOL IsInRect(int x, int y) const;

	void Normalization();

	int Width() const;

	void SetWidth(int w);

	int Height() const;

	void SetHeight(int h);

	void OffsetRect(int x, int y);

	void SetPoint(int x, int y);

	void SetSize(int w, int h);

	void SetRect(int l, int t, int r, int b);

	void SetRect(const GRect& rt);

	GPoint CenterPoint() const;

	int Length() const;

	int Area() const;

	BOOL IntersectRect(const GRect& rt);

	BOOL IntersectRect(const GRect& rt1, const GRect& rt2);

	void UnionRect(const GRect& rt);

	void UnionRect(const GRect& rt1, const GRect& rt2);

	void InflateRect(int l, int t, int r, int b);

	void InflateRect(int x, int y);

	void InflateRect(const GRect& rt);

	void DeflateRect(int l, int t, int r, int b);

	void DeflateRect(int x, int y);

	void SwapLeftRight();

	void SwapTopBottom();

	void Swap();

	void SetRectEmpty();

	void Translate(int dx_, int dy_);

	RECT ToRECT() const;

	const GRect& operator=(const GRect& rt);

	BOOL operator==(const GRect& rt) const;

	BOOL operator!=(const GRect& rt) const;

	const GRect& operator&=(const GRect& rt);

	const GRect& operator|=(const GRect& rt);

	GRect operator&(const GRect& rt) const;

	GRect operator|(const GRect& rt) const;


  public:
	int left;
	int right;
	int top;
	int bottom;
};

// 大小
class UI_EXP GSize
{
  public:
	GSize();
	GSize(int cx_, int cy_);
	~GSize();

	const GSize& operator=(const GSize& other);

  public:
	int cx;
	int cy;
};



}

#endif