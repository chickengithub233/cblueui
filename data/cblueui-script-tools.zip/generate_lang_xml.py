﻿#!/usr/bin/env python3 
# -*- coding: utf-8 -*-
import os
import sys
import time
import re
import argparse
import shutil
import string
import xml.dom.minidom as xmldom
from typing import Union
# pip install translators
# pip install --upgrade translators
# https://pypi.org/project/translators/

# python -m pip install --upgrade pip

import translators as ts
en_lang_men_ap_var = {} #全局变量
def trans_text(text=str, trs_name = "alibaba", to_lang="en", from_lang="zh") -> Union[str, dict]:
    if(to_lang == from_lang):
        return text
    if trs_name == "alibaba":
        result_tr=ts.alibaba(text, "auto", to_lang)
    elif trs_name == "sogou":
        result_tr=ts.sogou(text, "auto", to_lang)
    elif trs_name == "baidu":
        result_tr=ts.baidu(text, "auto", to_lang)
    elif trs_name == "tencent":
        result_tr=ts.tencent(text, "auto", to_lang)
    elif trs_name == "papago":
        result_tr=ts.papago(text, "auto", to_lang)
    elif trs_name == "itranslate":
        result_tr=ts.itranslate(text, "auto", to_lang)
    elif trs_name == "iciba":
        result_tr=ts.iciba(text, "auto", to_lang)
    elif trs_name == "youdao":
        result_tr=ts.youdao(text, "auto", to_lang) 
    elif trs_name == "iflytek":
        result_tr=ts.iflytek(text, "auto", to_lang) 
    elif trs_name == "bing":
        result_tr=ts.bing(text, "auto", to_lang) 
    return result_tr


# 翻译关键字
def TranslatorMap(dictionaryObj, to_lang, trs_name = "alibaba"):
    global en_lang_men_ap_var
    orign_key_text = ""
    orign_text = ""
    after_text = ""
    out_map = {}
    split_ch = '\n'
    for i, (name, score) in enumerate(dictionaryObj.items()):
        print(i, name, score)
        k_name = name
        if len(orign_text) + len(name) > 120:
            after_text=trans_text(orign_text, trs_name, to_lang)
            List_Split_name = orign_key_text.split(split_ch)
            List_Split_value = after_text.split(split_ch)
            if len(List_Split_name) == len(List_Split_value):
                for j in range(0, len(List_Split_name)) :
                    out_map[List_Split_name[j]] = List_Split_value[j].strip()  
            orign_text = ""
            orign_key_text = ""
            after_text = ""

        if to_lang != 'en' and to_lang != 'zh':
            if name in en_lang_men_ap_var:
                name = en_lang_men_ap_var[name]

        if name.find(split_ch) < 0 and k_name.find(split_ch) < 0:
            if len(orign_text) <= 0:
                orign_text += "{}".format(name)
                orign_key_text += "{}".format(k_name)
            else :
                orign_text += "{}{}".format(split_ch, name)
                orign_key_text += "{}{}".format(split_ch, k_name)
        else:
            out_map[k_name] = trans_text(name, trs_name, to_lang)

    if len(orign_text) > 0:
        after_text=trans_text(orign_text, trs_name, to_lang)
        List_Split_name = orign_key_text.split(split_ch)
        List_Split_value = after_text.split(split_ch)
        if len(List_Split_name) == len(List_Split_value):
            for j in range(0, len(List_Split_name)) :
                out_map[List_Split_name[j]] = List_Split_value[j].strip()  
    return out_map



def fixed_writexml(self, writer, indent="", addindent="", newl=""):
    # indent = current indentation
    # addindent = indentation to add to higher levels
    # newl = newline string
    writer.write(indent + "<" + self.tagName)

    attrs = self._get_attributes()
    a_names = attrs.keys()

    for a_name in a_names:
        writer.write(" %s=\"" % a_name)
        xmldom._write_data(writer, attrs[a_name].value)
        writer.write("\"")
    if self.childNodes:
        if len(self.childNodes) == 1 \
                and self.childNodes[0].nodeType == xmldom.Node.TEXT_NODE:
            writer.write(">")
            self.childNodes[0].writexml(writer, "", "", "")
            writer.write("</%s>%s" % (self.tagName, newl))
            return
        writer.write(">%s" % (newl))
        for node in self.childNodes:
            if node.nodeType is not xmldom.Node.TEXT_NODE:
                node.writexml(writer, indent + addindent, addindent, newl)
        writer.write("%s</%s>%s" % (indent, self.tagName, newl))
    else:
        writer.write("/>%s" % (newl))

xmldom.Element.writexml = fixed_writexml

xml_body_template = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
<{} >\n\
{:<s}\
</{}>\n"

# 解析单个文件
def ParseMatchTrFile(xmlfilepath, lang_map):
    if os.path.isfile(xmlfilepath) != True:
        return
    text = ''
    encodelist =['utf-8', 'gbk','utf-16-le','utf-16-be','windows-1251']
    for encodeitem in encodelist:     
        with open(xmlfilepath, 'r', encoding=encodeitem) as file:
            try:
                text = file.read()
            except:
                continue
            else:
                break

    patt='[\"\'>]\s*tr:.*?[\"\'<]'
    result = re.findall(patt, text)
    #print(result)
    for it in result:
        ret = re.findall('[\"\'>]\s*tr:(.*)?[\"\'<]', it)
        tr_text = ret[0]
        if len(tr_text) > 0:
            lang_map[tr_text] = ''
        # print(tr_text)


# 不覆盖现有的xml皮肤文件
def UpdateLangXml(elementobj, dictionaryObj, write_dom, parent_node, to_lang):
    global en_lang_men_ap_var
    for obj in elementobj.childNodes:   
        if obj.nodeType == 1 and obj.attributes.length > 0: 
            node=write_dom.createElement(obj.nodeName)
            if obj.nodeName.lower() == 'lang':
                k_name = obj.getAttribute("name")  # 获取指定tag的属性值
                k_value = obj.getAttribute("value")  # 获取指定tag的属性值
                if k_name in dictionaryObj.keys():  
                    del dictionaryObj[k_name] 
                    if to_lang == 'en':
                        en_lang_men_ap_var[k_name] = k_value
            for attr in obj.attributes._attrs :
                node.setAttribute(attr,obj._attrs[attr].value)
            parent_node.appendChild(node)
            UpdateLangXml(obj, dictionaryObj, write_dom, node, to_lang)

            
# 生成语言函数
def lang_generate(lang_file_outdir, regionName, lang_map_input, trs_name, to_lang, from_lang = "zh"):
    global en_lang_men_ap_var
    cur_time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    lang_map = lang_map_input.copy()
    item_lang_full_path = os.path.join(lang_file_outdir, regionName+ ".xmllang") 
    if os.path.exists(item_lang_full_path) != True:
        # 文件不存在则，创建新的文件
        text_style = ''
        lang_map = TranslatorMap(lang_map, to_lang, trs_name) # 翻译文本
        for keyStyle in lang_map.keys():
            trstring = lang_map[keyStyle]        
            text_style += '\t<lang name=\"{}\" value=\"{}\"/>\n'.format(keyStyle, trstring)
            if to_lang == 'en':
                en_lang_men_ap_var[keyStyle] = trstring
        with open(item_lang_full_path, 'w', encoding='utf-8') as file_object:
            file_object.write(xml_body_template.format("LangFile", text_style, "LangFile"))
            print("语言翻译.创建OK!({})".format(item_lang_full_path))
    else :
        # xml解析
        domobj = xmldom.parse(item_lang_full_path)
        elementobj = domobj.documentElement
        # 1.创建DOM树对象
        dom=xmldom.Document()
        #print(elementobj.nodeName)
        root_node=dom.createElement(elementobj.nodeName)
        dom.appendChild(root_node)
        if elementobj.attributes:   
            for attr in elementobj._attrs :
                root_node.setAttribute(attr,elementobj._attrs[attr].value)
        UpdateLangXml(elementobj, lang_map, dom, root_node, to_lang)
        #剩余写入文件中
        if len(lang_map) > 0 :
            lang_map = TranslatorMap(lang_map, to_lang, trs_name) # 翻译文本
            for keyStyle in lang_map.keys():
                trstring = lang_map[keyStyle] 
                style_node=dom.createElement("lang")
                style_node.setAttribute("name",keyStyle)
                style_node.setAttribute("value", trstring)
                root_node.appendChild(style_node)
                if to_lang == 'en':
                    en_lang_men_ap_var[keyStyle] = trstring
        try:
            with open(item_lang_full_path,'w', encoding='utf-8') as fh:
                # 4.writexml()第一个参数是目标文件对象，第二个参数是根节点的缩进格式，第三个参数是其他子节点的缩进格式，
                # 第四个参数制定了换行格式，第五个参数制定了xml内容的编码。
                dom.writexml(fh,indent='',addindent='\t',newl='\n',encoding='UTF-8')
                print("语言翻译.更新OK!\033[33m{} {}\033[0m".format(cur_time, item_lang_full_path))
        except Exception as err:
            print('错误信息：{0}'.format(err))
                        
# main 
if __name__=="__main__":
    os.system('')
    #命令行参数
    parser = argparse.ArgumentParser("输入xml文件生成皮肤文件")
    parser.add_argument('--output', type=str, default='res/lang', help='lang file output directory.')
    parser.add_argument('--input', type=str, default=['res', "cblueui", "demo", "design-studio"], nargs='+', help='xml file input directory')

    args = parser.parse_args()
    cur_dir = os.path.realpath(__file__)

    input_list = args.input
    outdirlang = args.output

    lang_map_var = {}
    list_input_files =[]

    for dir_item in input_list:
        if not os.path.isdir(dir_item) :
            continue
        for root, dirs, files in os.walk(dir_item):
            print('root_dir:', root)  # 当前目录路径
            print('sub_dirs:', dirs)  # 当前路径下所有子目录
            print('files:', files)  # 当前路径下所有非目录子文件
            if 'depend' in dirs:
                dirs.remove('depend')
            if 'uiweb' in dirs:
                dirs.remove('uiweb')
            for names in files:
                cur_file_path = os.path.join(root, names)
                res_01=os.path.splitext(cur_file_path)
                ext = res_01[1].lower()
                if (ext == '.h' or ext == '.c' or ext == '.cpp' or ext == '.cxx' or ext == '.xml'):
                    list_input_files.append(cur_file_path)

    size_file = len(list_input_files)
    for i in range(0, size_file):
        cur_xml_path = list_input_files[i]
        format_str = "[{}:>{}{}/{}] {}".format('{',len(str(size_file)), '}','{}','{}')
        print(format_str.format(i+1, size_file, cur_xml_path))
        ParseMatchTrFile(cur_xml_path, lang_map_var)


    if len(outdirlang) > 0:
        if os.path.exists(outdirlang) != True:
            os.makedirs(outdirlang)
        # 主要区域语言
        # regionNameArr = ["ar"]
        # for reg_item in regionNameArr:
        #     lang_generate(outdirlang, reg_item, lang_map_var, "alibaba", reg_item)

        # regionNameArr = ["ru","ar", "fr", "zh"]
        regionNameArr = ["en", "ru","ar", "fr", "zh"]
        for reg_item in regionNameArr:
            lang_generate(outdirlang, reg_item, lang_map_var, "alibaba", reg_item)

        regionNameArr = ["ko", "ja"]
        for reg_item in regionNameArr:
            lang_generate(outdirlang, reg_item, lang_map_var, "sogou", reg_item)

        regionNameArr = ["cht"]
        for reg_item in regionNameArr:
            lang_generate(outdirlang, reg_item, lang_map_var, "iciba", reg_item)


















