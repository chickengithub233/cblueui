﻿#!/usr/bin/env python3 
# -*- coding: utf-8 -*-
import os
import sys
import time
import re
import argparse
import shutil
import string
import xml.dom.minidom as xmldom

def fixed_writexml(self, writer, indent="", addindent="", newl=""):
    # indent = current indentation
    # addindent = indentation to add to higher levels
    # newl = newline string
    writer.write(indent + "<" + self.tagName)

    attrs = self._get_attributes()
    a_names = attrs.keys()

    for a_name in a_names:
        writer.write(" %s=\"" % a_name)
        xmldom._write_data(writer, attrs[a_name].value)
        writer.write("\"")
    if self.childNodes:
        if len(self.childNodes) == 1 \
                and self.childNodes[0].nodeType == xmldom.Node.TEXT_NODE:
            writer.write(">")
            self.childNodes[0].writexml(writer, "", "", "")
            writer.write("</%s>%s" % (self.tagName, newl))
            return
        writer.write(">%s" % (newl))
        for node in self.childNodes:
            if node.nodeType is not xmldom.Node.TEXT_NODE:
                node.writexml(writer, indent + addindent, addindent, newl)
        writer.write("%s</%s>%s" % (indent, self.tagName, newl))
    else:
        writer.write("/>%s" % (newl))

xmldom.Element.writexml = fixed_writexml

#提取ui文件中的控件属性
def peek_xml_attribute(curNode, toDom, toNode):
    attr_except = ['style','font','icon','image']

    for obj in curNode.childNodes:   
        if obj.nodeType == 1 and obj.attributes.length >= 0: 
            if obj.nodeName.lower() != 'ui':
                return False
    for obj in curNode.childNodes:   
        if obj.nodeType == 1 and obj.attributes.length >= 0: 
            if obj.nodeName.lower() == 'control':
                node=toDom.createElement('skin')
                classname ='' 
                for attr in obj.attributes._attrs :
                    if attr.lower() == 'class':
                        classname = obj._attrs[attr].value
                    elif attr.lower() == 'name':
                        classname = obj._attrs[attr].value
                node.setAttribute('name',classname)   
                for attr in obj.attributes._attrs :
                    if attr.lower() in attr_except or attr.lower().find('image') >= 0 or attr.lower().find('color') >= 0 or attr.lower().find('gradient') >= 0:
                        node.setAttribute(attr.lower(),obj._attrs[attr].value)    
                toNode.appendChild(node)

            if obj.nodeName.lower() == 'style':
                node=toDom.createElement('style')
                for attr in obj.attributes._attrs :
                    node.setAttribute(attr.lower(),obj._attrs[attr].value)
                toNode.appendChild(node)
            peek_xml_attribute(obj, toDom, toNode)
    return True

#获得所有skin节点
def get_skin_nodes(Node, skinnodelist):
    for obj in Node.childNodes:
        if obj.nodeType == 1: 
            if obj.nodeName.lower() == 'skin':
                skinnodelist.append(obj)
        get_skin_nodes(obj, skinnodelist)

#合并旧版皮肤属性
def merge_xml_attribute(oldNode, toDom, toNode):
    listnode_old= []
    listnode_to = []
    get_skin_nodes(oldNode, listnode_old)
    get_skin_nodes(toNode, listnode_to)
    for old in listnode_to:
        name = old.getAttribute("name")
        if name == None:
            continue
        isfind = False
        for child in listnode_old:
            to_name = child.getAttribute("name")
            if to_name == None:
                continue
            if to_name.lower() != name.lower():
                continue
            for attr in old.attributes._attrs :
                child.setAttribute(attr.lower(), old._attrs[attr].value)
            #listnode_to.remove(child)
            isfind = True
            break
        if not isfind:
            node=toDom.createElement('skin')
            for attr in old.attributes._attrs :
                node.setAttribute(attr.lower(), old._attrs[attr].value)
            oldNode.appendChild(node)
            

# main 
if __name__=="__main__":
    #命令行参数
    parser = argparse.ArgumentParser("输入xml文件生成皮肤文件")
    parser.add_argument('--output', type=str, default='res/skin', help='skin file output directory.')
    parser.add_argument('--input', type=str, default=['res'], nargs='+', help='xml file input directory')
    parser.add_argument('--theme', type=str, default=['default', 'lighting', 'dark', 'night-eye'], nargs='+', help='theme name list')

    args = parser.parse_args()

    os.system('')
    cur_dir = os.path.realpath(__file__)
    list_input_files =[]
    input_list = args.input
    outdirlang = args.output
    theme_list = args.theme

    if(len(theme_list) <= 0):
        exit()
    for dir_item in input_list:
        if not os.path.isdir(dir_item) :
            continue
        for root, dirs, files in os.walk(dir_item):
            print('root_dir:', root)  # 当前目录路径
            print('sub_dirs:', dirs)  # 当前路径下所有子目录
            print('files:', files)  # 当前路径下所有非目录子文件
            for names in files:
                cur_file_path = os.path.join(root, names)
                res_01=os.path.splitext(cur_file_path)
                ext = res_01[1].lower()
                if (ext == '.xml'):
                    list_input_files.append(cur_file_path)
    #生成皮肤文件
    size_file = len(list_input_files)
    for i in range(0, size_file):
        cur_xml_path = list_input_files[i]
        format_str = "[{}:>{}{}/{}] {}".format('{',len(str(size_file)), '}','{}','{}')
        print(format_str.format(i+1, size_file, cur_xml_path))
        # 1.ui文件xml结构数据解析
        domobj = xmldom.parse(cur_xml_path)
        elementobj = domobj.documentElement
        # 2.创建皮肤文件xml结构树
        dom=xmldom.Document()
        #print(elementobj.nodeName)
        root_node=dom.createElement('SkinFile')
        dom.appendChild(root_node)
        # 3.提取默认风格
        if peek_xml_attribute(domobj, dom, root_node) == False:
            continue
        for theme in theme_list:
            basename = os.path.splitext(os.path.basename(cur_xml_path))[0]
            skin_dir = os.path.join(outdirlang, theme)
            if os.path.exists(skin_dir) != True:
                os.mkdir(skin_dir)
            skin_file_path = os.path.join(skin_dir, "{}.xmlskin".format(basename) )
            try:  
                if os.path.exists(skin_file_path) == True:
                    # 保留旧版皮肤属性
                    old_domobj = xmldom.parse(skin_file_path)
                    old_elementobj = old_domobj.documentElement
                    merge_xml_attribute(old_elementobj, old_domobj, root_node)
                    with open(skin_file_path,'w', encoding='UTF-8') as fh:
                        # 4.writexml()第一个参数是目标文件对象，第二个参数是根节点的缩进格式，第三个参数是其他子节点的缩进格式，
                        # 第四个参数制定了换行格式，第五个参数制定了xml内容的编码。
                        old_domobj.writexml(fh,indent='',addindent='\t',newl='\n',encoding='UTF-8')
                        print("皮肤.更新OK!({})".format(skin_file_path))
                else:
                    with open(skin_file_path,'w', encoding='UTF-8') as fh:
                        # 4.writexml()第一个参数是目标文件对象，第二个参数是根节点的缩进格式，第三个参数是其他子节点的缩进格式，
                        # 第四个参数制定了换行格式，第五个参数制定了xml内容的编码。
                        dom.writexml(fh,indent='',addindent='\t',newl='\n',encoding='UTF-8')
                        print("皮肤.更新OK!({})".format(skin_file_path))
            except Exception as err:
                print('错误信息：{0}'.format(err))
                















