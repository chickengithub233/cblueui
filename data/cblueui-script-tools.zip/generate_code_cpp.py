#!/usr/bin/env python3 
# -*- coding: utf-8 -*-
import os
import sys
import time
import re
import argparse
import shutil
import string
import xml.dom.minidom as xmldom

#-----------------------------------------------------------

#h 生成模板
head_temp = "#ifndef UIVIEW_{}_INC_H_\n\
#define UIVIEW_{}_INC_H_\n\n\
#if _MSC_VER > 1000 \n\
#pragma once \n\
#endif // _MSC_VER > 1000 \n\n\
#include \"CBlueUI.h\" \n\n\
/* {:<s} Event handler. */\n\
class {:<s} : public CManagerHandler \n\
{{ \n\
public: \n\
  {:<s}(IManageHandler* pM); \n\
  virtual ~{:<s}(); \n\
  \n\
  void  InitUI(BOOL isNeedDestory = FALSE); \n\
  BOOL  OnMessageHandler(UINT message, WPARAM wp, LPARAM lp) override; \n\
protected:\n\
  /* All named ui controls */\n\
{}\
}}; \n\
\n\
#endif\n"

#cpp 生成模板
cpp_temp="#include \"{}\" \n\n\
{:<s}::{:<s}(IManageHandler* pM) \n\
  :CManagerHandler(pM)\n\
  ,m_isNeedDestory(FALSE) \n\
{{ \n\
{:<s}\
}} \n\n\
{:<s}::~{:<s}()\n\
{{\n\
  if (m_isNeedDestory == FALSE)\n\
    return;\n\
{:<s}\
}}\n\
\n\
void  {:<s}::InitUI(BOOL isNeedDestory)\n\
{{\n\
  m_isNeedDestory = isNeedDestory;\n\
  IManageHandler* pManger = GetUIManager();\n\
  if (pManger == NULL)\n\
    return;\n\
{:<s}\
}}\n\
\n\
BOOL  {:<s}::OnMessageHandler(UINT message, WPARAM wp, LPARAM lp)\n\
{{\n\
  switch (message)\n\
  {{\n\
    case MSG_BIND_UI:\n\
      InitUI();\n\
      break;\n\
    default:\n\
      break;\n\
  }}\n\
  return FALSE;\n\
}}\n\n"




class UINode:
    def __init__(self):
        self.class_name = '';
        self.var_name = '';
        self.text  = '';
        self.isWindows  = '';

def GetAllNodeUI(elementobj, out_lists):
    for obj in elementobj.childNodes:
        if obj.attributes == None or obj.attributes.length <= 0:
            continue
        if obj.nodeName.lower() == 'control' or obj.nodeName.lower() == 'window':
            item = UINode()
            item.isWindows = obj.nodeName.lower() == 'window'
            for attr in obj.attributes._attrs :
                if attr.lower() == 'class' :
                    item.class_name = obj._attrs[attr].value
                elif attr.lower() == 'name' :
                    item.var_name = obj._attrs[attr].value
                elif attr.lower() == 'text' :
                    item.text = obj._attrs[attr].value
                #print(attr)
            if len(item.var_name) > 0 :
                out_lists.append(item)
        GetAllNodeUI(obj, out_lists)


def hpp_generate(xmlfilepath):
    if os.path.exists(xmlfilepath) == False:
        print('不存在文件：'+ xmlfilepath)
        return 
    res_01=os.path.splitext(xmlfilepath)
    if res_01[1].lower() != '.xml':
        print('不是有效的xml文件：'+ xmlfilepath)
        return 

    class_name = os.path.basename(xmlfilepath)
    class_name = os.path.splitext(class_name)[0]
    class_name = class_name.lstrip()
    class_name = class_name.rstrip()
    class_name = class_name.lstrip('0123456789_')
    print(class_name)
    out_file_path = res_01[0] + '.hpp'

        
    print(res_01[1])
    print(res_01[0])
    # 得到文档对象
    domobj = xmldom.parse(xmlfilepath)

    # 得到元素对象
    elementobj = domobj.documentElement
    #print(elementobj.nodeName)

    out_list = []
    GetAllNodeUI(elementobj, out_list)
    
    if len(out_list) <= 0 :
       return 

    class_name_max_len = 0
    var_name_max_len = 0
    text_max_len = 0
    for item in out_list :
        class_name_max_len = max(class_name_max_len, len(item.class_name))
        var_name_max_len = max(var_name_max_len, len(item.var_name))
        text_max_len = max(text_max_len, len(item.text))

    one_skip = '    '
    two_skip = one_skip + one_skip
    # 1.绑定控件cpp代码
    string = ''
    formate_str = '{{:<s}}  {{:<{}s}} {{:<{}s}} {{:<{}s}} {{:<s}}'.format(class_name_max_len+2, var_name_max_len + 4, var_name_max_len+7)
    print(formate_str)
    for item in out_list :
        tip = ''
        if len(item.text) > 0:
            tip = ' // ' + item.text
        string += two_skip + formate_str.format('BIND_CTL_VARIABLE_BY_NAME(pManger, ', item.class_name + ', ', 'm_p' + item.var_name +',', '_T("'+ item.var_name + '")' , ' );' + tip +'\n' )  
    #print(string)

    # 2.声明控件cpp代码
    def_string = ''
    formate_def_str = '{{:<{}s}} {{:<{}s}} {{:<s}}'.format(class_name_max_len+2, var_name_max_len+ 10)
    print(formate_def_str)
    def_string += one_skip + formate_def_str.format('BOOL' , 'm_isNeedDestory;',  '\n')  
    for item in out_list :
        tip = ''
        if len(item.text) > 0:
            tip = ' // ' + item.text
        def_string += one_skip + formate_def_str.format(item.class_name + '* ', 'm_p' + item.var_name +';',  tip +'\n')  
        #def_string += one_skip + formate_def_str.format(item.class_name + '* ', 'm_p' + item.var_name +' = NULL;',  tip +'\n')  
    #print(def_string)
    
    # 3.释放控件内存cpp代码
    free_string = ''
    formate_free_str = 'SAFEDEL({:<s});'
    print(formate_def_str)
    for item in out_list :
        free_string += two_skip + formate_free_str.format('m_p' + item.var_name )  +'\n'
    #print(free_string)

    # 5.构造函数初始化控件cpp代码
    init_string = ''
    for item in out_list :
        init_string += two_skip + 'm_p' + item.var_name  + ' = NULL;' +'\n'
    #print(init_string)

    # class body
    class_text = ''
    class_text += '#ifndef UIVIEW_{}_INC_H_\n'.format(class_name.upper())
    class_text += '#define UIVIEW_{}_INC_H_\n\n'.format(class_name.upper())
    class_text += '#if _MSC_VER > 1000\n'
    class_text += '#pragma once\n'
    class_text += '#endif // _MSC_VER > 1000\n\n'

    class_text += 'class {} \n{{\n'.format(class_name)
    #构造函数
    class_text += 'public:\n' + one_skip + class_name +'()' +'\n'
    class_text += one_skip + '{\n'
    class_text += two_skip + 'm_isNeedDestory = FALSE;\n'
    class_text += init_string 
    class_text += one_skip + '};\n\n'

    #析构函数
    class_text += one_skip + '~' + class_name +'()' +'\n'
    class_text += one_skip + '{\n'
    class_text += two_skip + 'if (m_isNeedDestory == FALSE)\n' + two_skip + one_skip +  'return;' +'\n'
    class_text += free_string 
    class_text += one_skip + '};\n\n'
    # 绑定ui函数
    class_text += one_skip + 'void BindControlUI(IManageHandler* pManger, BOOL isNeedDestory)' +'\n'
    class_text += one_skip + '{\n'
    class_text += two_skip + 'm_isNeedDestory = isNeedDestory;\n'
    class_text += two_skip + 'if (pManger == NULL)\n' + two_skip + one_skip +  'return;' +'\n'
    class_text += string
    class_text += one_skip + '};\n\n'
    class_text += 'public:\n'

    class_text += def_string
    class_text +=  '};\n\n'

    class_text += '#endif\n'
    #print(def_string)

    with open(out_file_path, 'w', encoding='utf-8') as file_object:
        file_object.write(class_text)


def cpp_generate(xmlfilepath, outdirpath):
    if os.path.exists(xmlfilepath) == False:
        print('不存在文件：'+ xmlfilepath)
        return 
    res_01=os.path.splitext(xmlfilepath)
    if res_01[1].lower() != '.xml':
        print('不是有效的xml文件：'+ xmlfilepath)
        return 
    print("outdirpath:"+outdirpath)
    class_name = os.path.basename(xmlfilepath)
    class_name = os.path.splitext(class_name)[0]
    file_name = class_name
    class_name = class_name.lstrip()
    class_name = class_name.rstrip()
    class_name = class_name.lstrip('0123456789_')

    class_name = class_name.capitalize() +'Handler'
    print(class_name)
    source_file_path = outdirpath +"/"+ file_name +'.cpp'
    head_file_path = outdirpath +"/"+ file_name + '.h'
    print(source_file_path)
    print(head_file_path)
    print(res_01[1])
    print(res_01[0])
    print(xmlfilepath)
    # 得到文档对象
    domobj = xmldom.parse(xmlfilepath)

    # 得到元素对象
    elementobj = domobj.documentElement
    #print(elementobj.nodeName)

    result_list = []
    GetAllNodeUI(elementobj, result_list)
    out_list = []
    varname_list = [""]
    for item in result_list :
        if item.var_name not in varname_list :
            varname_list.append(item.var_name)
            out_list.append(item)

    if len(out_list) <= 0 :
       return 

    class_name_max_len = 0
    var_name_max_len = 0
    text_max_len = 0
    for item in out_list :
        class_name_max_len = max(class_name_max_len, len(item.class_name))
        var_name_max_len = max(var_name_max_len, len(item.var_name))
        text_max_len = max(text_max_len, len(item.text))

    one_skip = '  '
    two_skip = one_skip + one_skip
    # 1.绑定控件cpp代码
    string = ''
    formate_str = '{{:<s}}  {{:<{}s}} {{:<{}s}} {{:<{}s}} {{:<s}}'.format(class_name_max_len+2, var_name_max_len + 4, var_name_max_len+7)
    print(formate_str)
    for item in out_list :
        tip = ''
        if len(item.text) > 0:
            tip = ' // ' + item.text
        if item.isWindows == False:
            string += one_skip + formate_str.format('BIND_CTL_VARIABLE_BY_NAME(pManger, ', item.class_name + ', ', 'm_p' + item.var_name +',', '_T("'+ item.var_name + '")' , ' );' + tip +'\n' )  
        else:
            string += one_skip + formate_str.format('BIND_WND_VARIABLE_BY_NAME(pManger, ', item.class_name + ', ', 'm_p' + item.var_name +',', '_T("'+ item.var_name + '")' , ' );' + tip +'\n' ) 
    #print(string)

    # 2.声明控件cpp代码
    def_string = ''
    formate_def_str = '{{:<{}s}} {{:<{}s}} {{:<s}}'.format(class_name_max_len+2, var_name_max_len+ 10)
    print(formate_def_str)
    def_string += one_skip + formate_def_str.format('BOOL' , 'm_isNeedDestory;',  '\n')  
    for item in out_list :
        tip = ''
        if len(item.text) > 0:
            tip = ' // ' + item.text
        def_string += one_skip + formate_def_str.format(item.class_name + '* ', 'm_p' + item.var_name +';',  tip +'\n')  


    # 3.释放控件内存cpp代码
    free_string = ''
    formate_free_str = 'SAFEDEL({:<s});'
    print(formate_def_str)
    for item in out_list :
        free_string += one_skip + formate_free_str.format('m_p' + item.var_name )  +'\n'
    #print(free_string)

    # 5.构造函数初始化控件cpp代码
    init_string = ''
    for item in out_list :
        init_string += one_skip + 'm_p' + item.var_name  + ' = NULL;' +'\n'
    #print(init_string)

    # class body
    print(head_temp)
    class_text = head_temp.format(
            class_name.upper(),
            class_name.upper(),
            class_name,
            class_name,
            class_name,
            class_name,
            def_string
            )

    with open(head_file_path, 'w', encoding='utf-8') as file_object:
        file_object.write(class_text)


    one_skip = ''
    two_skip = '  '
    cpp_text = ''

    h_filebasename = os.path.basename(xmlfilepath)
    h_file_name = os.path.splitext(h_filebasename)[0]+'.h'

    cpp_text = cpp_temp.format(
        h_file_name,
        class_name,
        class_name,
        init_string,
        class_name,
        class_name,
        free_string,
        class_name,
        string,
        class_name,
    )

    with open(source_file_path, 'w', encoding='utf-8') as file_object:
        file_object.write(cpp_text)

# main 
if __name__=="__main__":
    #命令行参数
    parser = argparse.ArgumentParser("输入xml文件生成cpp源文件")
    parser.add_argument('--outdir', type=str, default='', help='Skin file output directory.')
    parser.add_argument('--file', type=str, default='', help='xml file')
    parser.add_argument('--dir', type=str, default='', help='xml file input directory')
    #parser.add_argument('--outdir', action="store_true", help='Skin file output directory.')
    parser.print_help()
    args = parser.parse_args()
    os.system('')
    cur_dir = os.path.abspath('.')

    out_dir = args.outdir
    # out_dir = 'teese'
    if len(out_dir) > 0 :
        if not os.path.exists(out_dir) :
            os.makedirs(out_dir)

    file_path = args.file
    if len(file_path) > 0 :
        if os.path.isfile(file_path):     
            cur_out_dir = out_dir
            if not os.path.isdir(cur_out_dir) :
                cur_out_dir = os.path.dirname(file_path)
            print(file_path)
            cpp_generate(file_path, cur_out_dir)

    dir_path = args.dir
    # dir_path = 'res'

    if len(dir_path) > 0 :
        if not os.path.isdir(dir_path) :
            dir_path = cur_dir +"/"+dir_path
        if os.path.isdir(dir_path) :
            list = os.listdir(dir_path)  # 列出文件夹下所有的目录与文件
            len_files = len(list)
            for i in range(0, len_files):
                path = os.path.join(dir_path, list[i])
                print("[{}/{}] {}".format(i+1, len_files,path))
                cur_out_dir = out_dir
                if not os.path.isdir(cur_out_dir) :
                    cur_out_dir = os.path.dirname(path)
                rel = os.path.relpath(os.path.dirname(path), dir_path)
                if rel != '.':
                    cur_out_dir = cur_out_dir + '/' + rel
                cpp_generate(path, cur_out_dir)

    cur_time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    print("\033[33m \n** UI GENERATECPP FINISHED ** {}\n\033[0m".format(cur_time)) 








