﻿#ifndef CBLUEUI_GTEXTPATHLAYOUT_INCLUDED_
#define CBLUEUI_GTEXTPATHLAYOUT_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"
#include "GPathStorage.h"
#include "GSurface.h"

#include <vector>

namespace BUI {

// class UI_EXP GTextPathLayout : public GPathStorage
//{
// public:
//	GTextPathLayout();
//	~GTextPathLayout();

// protected:
//	GPathStorage m_path_line;
//	TransAlongSinglePath m_textEffect;

//	UINT m_showBitmap; // bit-0:show back，bit-1:show border
//	//// fill style
//	//GColor m_bkColor;
//	//GBrushGradient* m_bkGradientBru;

//	//// border style
//	//GBrushGradient* m_borderGradientBru;
//	//LineStyle m_borderStyle;
//	//int m_borderSize;
//};

}

#endif