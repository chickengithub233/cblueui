#ifndef BLUEUI_CNODEDATAHTML_INCLUDED_
#define BLUEUI_CNODEDATAHTML_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <memory>
#include "core/CCoreBasePro.h"
#include "cstring/GString.h"
#include "cstring/GStringA.h"
#include "platform/GFont.h"
#include "CNodeData.h"

namespace BUI {

class UI_EXP LabelItem
{
  public:
	LabelItem();
	~LabelItem();

  public:
	GString text;
	GString href;
	COLORREF color;
	SIZE sz;
	int font_height;
	int font_style;
	BOOL isNewLine;
	GFont* hFont;
};

struct HtmlItemDataStyle
{
	GFont* font;
	COLORREF textColor;
	int font_style;
	int font_height;
};

class UI_EXP CNodeHtmlTextData : public CNodeData
{
  protected:
	std::vector<std::shared_ptr<LabelItem> > m_Labels;
	UINT m_align;
	BOOL m_bWordWrap;
	int m_dataindex;

  public:
	CNodeHtmlTextData();
	~CNodeHtmlTextData();
	void SetAlign(UINT align);
	void Clear(BOOL bErase = TRUE);
	void Addlabel(LPCTSTR szText, COLORREF color, int size, GFont* font, LPCTSTR szLinkref = NULL);
	void SetItemText(int index, LPCTSTR szText);
	void SetHtmlText(const TCHAR* htmltext, GFont* font = NULL);
	void SetDataIndex(int i);
	int LabelCounts() const;
	int FindItem(LPCTSTR text, BOOL noCase = FALSE) const; // noCase:TRUE 不区分大小写。缺省:区分大小写
	void OnParseHtmlItemData(XMLItem* pNode, HtmlItemDataStyle style);
	void OnParseHtmlData(XMLItem* pNode, GFont* font, COLORREF textColor);

	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;

	void GetPrintText(BasicStringBufferA& str) override;
	void NodeDataToEditor(GString& str) override;       // 传入编辑器显示的文本. node   --> editor
	void EditorToNodeData(const GString& str) override; // 接收编辑器传来的数据. editor --> node

	void GetValueData(DataType type, ValuePack& sortData) override; // 获取数据值,也可用于排序
  protected:
	virtual void OnRefreshHtml();

	SIZE AdaptSize() const;
	int AdaptFixedWidth(int w) const;

	int GetLineHeight(int s, int e) const;
};


}



#endif