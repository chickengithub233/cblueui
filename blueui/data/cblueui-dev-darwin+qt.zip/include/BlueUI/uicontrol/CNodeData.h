
#ifndef BLUEUI_CNODEDATA_0BDC91A2_2B9AC59FEE36_INCLUDED_
#define BLUEUI_CNODEDATA_0BDC91A2_2B9AC59FEE36_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <memory>
#include "core/CCoreBasePro.h"
#include "cstring/GString.h"
#include "cstring/GStringA.h"
#include "cstring/GStringBufferBasic.h"
#include "graphics/GImageIconInfo.h"
#include "graphics/GStyleLine.h"
#include "graphics/GSurface.h"

namespace BUI {

class CControlUI;

enum OrderByType
{
	OrderByASC,  // 升序(A~Z)
	OrderByDESC, // 降序(Z~A)
	OrderByNONE  // 初始顺序
};

enum DataType
{
	ST_NUM,
	ST_FLOAT,
	ST_TEXT,
};

struct ValuePack
{
	long long lNum;
	double fNum;
	GString sText;
};

struct SortData
{
	ValuePack sort_value;
	int sort_i;
};

extern bool CompareValueLong(SortData& v1, SortData& v2);
extern bool CompareValueDouble(SortData& v1, SortData& v2);
extern bool CompareValueText(SortData& v1, SortData& v2);
extern bool CompareValueTextNoCase(SortData& v1, SortData& v2);

/* sort class*/
class UI_EXP CSortContainer
{
  public:
	CSortContainer();
	~CSortContainer();

	void AppendSortData(SortData& data);
	void DeleteSortData(int sort_i);
	void ClearSortData();
	const SortData& At(UINT i) const;

	void SetOrderType(OrderByType order);
	void SetSortType(DataType dtype, BOOL nocase = FALSE);

	void SetPauseStatus(BOOL bPause);
	DataType GetSortDataType() const;

	void DoSort();

  protected:
	void NeedReSort();

  protected:
	BOOL m_bPauseSort;       // 暂停排序
	BOOL m_bNeedReRost;      // 是否需要重排
	OrderByType m_OrderType; // 排序方式
	DataType m_SortType;     // 排序数据类型
	BOOL m_bNoCase;
	std::vector<SortData> m_sortdata;
};

struct ElementLayout
{
	int nWidth_;
	int nHeight_;
	SizeMode nWidMode_;
	SizeMode nHeiMode_;
	SIZE szAdapt_;
};

/* node data base*/
class UI_EXP CNodeData
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeData)
  public:
	CNodeData();
	virtual ~CNodeData();

	virtual void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT align);

	// 获得打印字符串
	virtual void GetPrintText(BasicStringBufferA& str);
	// 传入编辑器显示的文本. node   --> editor
	virtual void NodeDataToEditor(GString& str);
	// 接收编辑器传来的数据. editor --> node
	virtual void EditorToNodeData(const GString& str);

	// 获取数据值,也可用于排序
	virtual void GetValueData(DataType type, ValuePack& sortData);
	// 设置布局信息
	virtual void SetElementLayout(int w, int h, SizeMode stw, SizeMode sth);
	// 获得布局信息
	virtual void GetElementLayout(ElementLayout& ele);
	// 获得布局自适应宽度
	virtual UINT GetNodeAdaptWidth(const GFont* font);
	virtual UINT GetNodeAdaptHeight(const GFont* font);

	virtual void ShellNodeDataAttribute(const char* key, const char* value);
	// 设置可视化区域
	virtual void SetClipRect(RECT& rc);
	// 定位控件
	virtual CControlUI* HitTestCellControl(POINT pt);
	virtual CControlUI* FindCellControl(LPCTSTR name);
	// 添加子node
	virtual BOOL AddChildNodeData(std::shared_ptr<CNodeData> valuedata);
	virtual BOOL InsertChildNodeData(int pos, std::shared_ptr<CNodeData> valuedata);
	virtual BOOL RemoveChildNodeData(int pos);

	void StorageNodeAdaptWidth(UINT size);
	void StorageNodeAdaptHeight(UINT size);

	void DrawNodeTextW(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT align, LPCWSTR text, int length);
	void DrawNodeTextA(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT align, LPCSTR text, int length);

  protected:
	std::shared_ptr<ElementLayout> m_obj_layout;
};

/* node data vector*/
class UI_EXP CNodeDataLists : public CNodeData
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataLists)
  public:
	CNodeDataLists(BOOL isHor = TRUE);
	virtual ~CNodeDataLists();

	void SetLayoutType(BOOL isHor);

	int Size() const;

	std::shared_ptr<CNodeData> GetChildNode(int pos) const;

	// 设置数据的索引，排序的时候会用改索引下的nodedata进行排序
	void SetValueIndex(int index);
	// 两个布局对象的间隔
	void SetLayoutInterval(int spacer);

	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	void GetPrintText(BasicStringBufferA& str) override;
	void NodeDataToEditor(GString& str) override;

	void EditorToNodeData(const GString& str) override;

	void GetValueData(DataType type, ValuePack& sortData) override;

	UINT GetNodeAdaptWidth(const GFont* font) override;
	UINT GetNodeAdaptHeight(const GFont* font) override;

	void ShellNodeDataAttribute(const char* key, const char* value) override;
	CControlUI* HitTestCellControl(POINT pt) override;
	CControlUI* FindCellControl(LPCTSTR name) override;

	BOOL AddChildNodeData(std::shared_ptr<CNodeData> valuedata) override;
	BOOL InsertChildNodeData(int pos, std::shared_ptr<CNodeData> valuedata) override;
	BOOL RemoveChildNodeData(int pos) override;
	void RemoveAll();

	// void  EnableItem(int nIndex, BOOL bEnable);
	// void  VisableItem(int nIndex, BOOL bVisable);
	// void  Enable(BOOL bEnable);
	// void  Visable(BOOL bVisable);


  protected:
	void LayoutNodeHor(RECT rcCell, ISurface* pSurface, int paintState, COLORREF textColor, UINT textAlignFlag);

	void LayoutNodeVer(RECT rcCell, ISurface* pSurface, int paintState, COLORREF textColor, UINT textAlignFlag);

  protected:
	int m_value_index;
	std::vector<std::shared_ptr<CNodeData>> m_nodes;
	BOOL m_isHorLayout; // 水平(TRUE)布局，垂直(FALSE)布局
	int m_nInterval;    // 两个布局对象的间隔
};

/* node ui*/
class UI_EXP CNodeDataControl : public CNodeData
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataControl)
  public:
	CNodeDataControl();
	CNodeDataControl(std::shared_ptr<CControlUI> ui, BOOL bDelega = TRUE);
	virtual ~CNodeDataControl();

	void SetControl(std::shared_ptr<CControlUI> ui, BOOL bDelega);

	/* CNodeData method:*/
	void NodeDataToEditor(GString& str) override;

	void EditorToNodeData(const GString& str) override;

	void GetValueData(DataType type, ValuePack& sortData) override;
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;

	UINT GetNodeAdaptWidth(const GFont* font) override;
	UINT GetNodeAdaptHeight(const GFont* font) override;
	void ShellNodeDataAttribute(const char* key, const char* value) override;

	CControlUI* HitTestCellControl(POINT pt) override;
	CControlUI* FindCellControl(LPCTSTR name) override;

	void SetClipRect(RECT& rc) override;

  protected:
	std::shared_ptr<CControlUI> m_data_ui;
};

/* image of data**/
class UI_EXP CNodeDataImage : public CNodeData
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataImage)
  public:
	CNodeDataImage();
	CNodeDataImage(GImageIconInfo* normal);
	~CNodeDataImage();
	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	void NodeDataToEditor(GString& str) override;
	void EditorToNodeData(const GString& str) override;
	void GetValueData(DataType type, ValuePack& sortData) override;

  protected:
	GImageIconInfo* m_image;
};

/* icon of data*/
class UI_EXP CNodeDataIconPrefix : public CNodeData
{
  public:
	CNodeDataIconPrefix();
	CNodeDataIconPrefix(GImageIconInfo* normal, COLORREF color);
	virtual ~CNodeDataIconPrefix();
	void SetTextStyle(GImageIconInfo* normal, COLORREF color);

	/* CNodeData method:*/
	virtual void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) = 0;

	virtual void NodeDataToEditor(GString& str) = 0;

	virtual void EditorToNodeData(const GString& str) = 0;

	virtual void GetValueData(DataType type, ValuePack& sortData) = 0;

  protected:
	void DrawPrefixText(ISurface* pSurface, RECT rcCell, COLORREF textColor, UINT textAlignFlag, LPCTSTR text, int length);

  protected:
	GImageIconInfo* m_image;
	COLORREF m_textUserColor; // 自定义文本颜色。最高位0为无效，非0为有效
};

/* text of data and icon of text*/
class UI_EXP CNodeDataText : public CNodeDataIconPrefix
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataText)
  public:
	CNodeDataText();
	CNodeDataText(GString text);
	virtual ~CNodeDataText();
	void SetValue(GString text);


	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	void GetPrintText(BasicStringBufferA& str) override;
	void NodeDataToEditor(GString& str) override;
	void EditorToNodeData(const GString& str) override;
	void GetValueData(DataType type, ValuePack& sortData) override;

	UINT GetNodeAdaptWidth(const GFont* font) override;
	UINT GetNodeAdaptHeight(const GFont* font) override;

  protected:
	GString m_text;
};

/* text align */
class UI_EXP CNodeDataTextAlign : public CNodeDataText
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataTextAlign)
  public:
	CNodeDataTextAlign();
	CNodeDataTextAlign(GString text);
	virtual ~CNodeDataTextAlign();

	void SetAlign(UINT formate);                                      // 设置图片和文本的对齐方式
	void ModifyCompositeLayoutFlags(UINT style, UINT op = ADD_FLAGS); // 设置文本和图表组合方式
	UINT IsHasCompositeLayoutFlags(UINT flags) const;

	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	UINT GetNodeAdaptWidth(const GFont* font) override;
	UINT GetNodeAdaptHeight(const GFont* font) override;

  protected:
	SIZE GetLayoutStringSize(ISurface* pSurface, LPCTSTR str);

  protected:
	UINT m_nTextAlign; //  文本对齐方式
	UINT m_layoutFlags;
};

/* text of gradient background*/
class UI_EXP CNodeDataTextGradient : public CNodeDataText, public GradientRoundRect
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataTextGradient)
  public:
	CNodeDataTextGradient();
	CNodeDataTextGradient(GString& text);
	~CNodeDataTextGradient();
	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
};

/* image of gradient background*/
class UI_EXP CNodeDataImageGradient : public CNodeDataImage, public GradientRoundRect
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataImageGradient)
  public:
	CNodeDataImageGradient();
	CNodeDataImageGradient(GImageIconInfo* normal);
	~CNodeDataImageGradient();
	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
};

/* int num of data*/
class UI_EXP CNodeDataInt : public CNodeDataIconPrefix
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataInt)
  public:
	CNodeDataInt(int value = 0);
	virtual ~CNodeDataInt();
	void SetValue(int value);

	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	void GetPrintText(BasicStringBufferA& str) override;
	void NodeDataToEditor(GString& str) override;
	void EditorToNodeData(const GString& str) override;
	void GetValueData(DataType type, ValuePack& sortData) override;

  public:
	int m_num;
};

/* float of data*/
class UI_EXP CNodeDataDouble : public CNodeDataIconPrefix
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataDouble)
  public:
	CNodeDataDouble(double value = 0.0);
	virtual ~CNodeDataDouble();
	void SetValue(double value);

	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	void GetPrintText(BasicStringBufferA& str) override;
	void NodeDataToEditor(GString& str) override;
	void EditorToNodeData(const GString& str) override;
	void GetValueData(DataType type, ValuePack& sortData) override;

  public:
	double m_value;
};

/* color of data*/
class UI_EXP CNodeDataColor : public CNodeData
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataColor)
  public:
	CNodeDataColor(COLORREF color = 0);
	virtual ~CNodeDataColor();
	void SetValue(COLORREF color);

	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	void GetPrintText(BasicStringBufferA& str) override;
	void NodeDataToEditor(GString& str) override;
	void EditorToNodeData(const GString& str) override;
	void GetValueData(DataType type, ValuePack& sortData) override;

  public:
	COLORREF m_color;
};

/* date of data. formate: yyyy-mm-dd*/
class UI_EXP CNodeDataDate : public CNodeData
{
	DECLARE_DYNAMIC_CLASS_BASE(CNodeDataDate)
  public:
	CNodeDataDate(long ymd = 0);
	virtual ~CNodeDataDate();
	void SetValue(double ymd);
	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	void GetPrintText(BasicStringBufferA& str) override;
	void NodeDataToEditor(GString& str) override;
	void EditorToNodeData(const GString& str) override;
	void GetValueData(DataType type, ValuePack& sortData) override;

  public:
	long m_ymd;
};

/* datetime of data. formate: yyyy-mm-dd hh:mm:ss*/
class UI_EXP CNodeDataDateTime : public CNodeData
{
  public:
	CNodeDataDateTime(long ymd, long hms);
	virtual ~CNodeDataDateTime();
	void SetValue(long ymd, long hms);
	/* CNodeData method:*/
	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
	void GetPrintText(BasicStringBufferA& str) override;
	void NodeDataToEditor(GString& str) override;
	void EditorToNodeData(const GString& str) override;
	void GetValueData(DataType type, ValuePack& sortData) override;

  public:
	long m_ymd;
	long m_hms;
};

/* BarOfPercent of data*/
class UI_EXP CNodeDataBarOfPercent : public CNodeDataDouble
{
  public:
	CNodeDataBarOfPercent(double percent);
	virtual ~CNodeDataBarOfPercent();

	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;
};

/* int enum data node*/
class UI_EXP CNodeDataEnum : public CNodeDataInt
{
  public:
	typedef GString (*CallbackIntTransFn)(int);

  public:
	CNodeDataEnum(int value, CallbackIntTransFn trans);
	virtual ~CNodeDataEnum();

	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;

  private:
	CallbackIntTransFn m_trans; // 翻译函数
};

/* text enum data node*/
class UI_EXP CNodeDataEnumText : public CNodeDataText
{
  public:
	typedef GString (*CallbackTextTransFn)(GString&);

  public:
	CNodeDataEnumText(GString value, CallbackTextTransFn trans);
	virtual ~CNodeDataEnumText();

	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;

  private:
	CallbackTextTransFn m_trans; // 翻译函数
};

/* text enum data node*/
class UI_EXP CNodeDataPlaceRect : public CNodeData
{
  public:
	CNodeDataPlaceRect(RECT* m_pRect);
	virtual ~CNodeDataPlaceRect();

	void OnDrawNodeData(ISurface* pSurface, int paintState, RECT rcCell, COLORREF textColor, UINT textAlignFlag) override;

  private:
	RECT* m_pRect;
};

struct WParamAddNodeData
{
	std::shared_ptr<CNodeData> nodedata;
	const char* target;
};



} // #namespace




#endif
