#ifndef BLUEUI_CTREEDATACELL_INCLUDED_
#define BLUEUI_CTREEDATACELL_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CNodeCell.h"

namespace BUI {

// 树单元格容器类
class UI_EXP CTreeRowCell
{
  public:
	CTreeRowCell();
	~CTreeRowCell();

	int Size() const;
	void Clear();

	void AppendDataCell(std::shared_ptr<CNodeSpanCell>& cell);
	BOOL InsertDataCell(int column, std::shared_ptr<CNodeSpanCell>& cell);
	void RemoveDataCell(int column);

	CNodeSpanCell* GetSubCell(int col);
	void OnAllocNodeCell(int nCol, int count);
	void OnDeleteCol(int nCol, int count);

	void OnNodeCollapsed();
	void OnSetNodeRect(int col, int x, int y, int w, int h);
	void OnDrawTreeCell(int col, ISurface* pSurface, RECT rcCell, COLORREF textColor, UINT textAlignFlag);

  protected:
	std::vector<std::shared_ptr<CNodeSpanCell> > m_rowOfcells;
};

enum MatchMask
{
	zero_match         = 0x00,
	search_mask_shift  = 1,
	default_mask_shift = 1 << 1
};

class UI_EXP CTreeModelNode : public CheckBoxMode, public CTreeRowCell
{
  public:
	RECT rcRow;
	RECT rcExpand;     // 折叠按钮有效区域
	BOOL bCollapsed;   // 是否折叠 true 折叠
	UINT uflagVisable; // 可见性标志
	int context_x;     // 保留去掉
	int row_y;         // 行y坐标

	int depth;      // 深度
	int LineNumber; // 行号

	CTreeModelNode* parent;
	CTreeModelNode* firstChild;
	CTreeModelNode* lastChild;
	CTreeModelNode* prevSibling;
	CTreeModelNode* nextSibling;

	std::shared_ptr<IActionNotify> clickAction; // 点击时执行的动作
  public:
	CTreeModelNode();
	~CTreeModelNode();

	/**
	 * @brief   设置集合竞价右键菜单组显示类型
	 * @return  void
	 * @param show  <table>
	 * <tr><th>Date       <th>Version <th>Author  <th>Description
	 * <tr><td>2019-11-17 <td>1.0     <td>wangh     <td>内容
	 * </table>
	 */
	void SetCellVisable(BOOL show);
	/**
	 * @brief func是一个普通成员函数
	 *
	 * @param a [in] param a
	 * @param b [in, out] param b
	 * @param c [out] output
	 * @return int
	 * @retval
	 * 1 : result1；
	 * 2 : result2；
	 * @see f()
	 */
	void SetCellMatched(BOOL matched);

	void SetClickAction(std::shared_ptr<IActionNotify> action);
	void SetExpandRect(int x, int y, int w, int h);
	BOOL PtInExpandRect(POINT pt);

	BOOL IsVisable(UINT mask) const;

	int NodeDepth() const;

	inline BOOL IsHasChild() { return firstChild != NULL; }
};

class UI_EXP CTreeViewModel : public MouseDragHelper
{
  public:
	CTreeViewModel();
	~CTreeViewModel();
	void SetLevelLineColor(COLORREF color);

	int GetRowHeight() const; // 数据行高度
	void SetRowHeight(int h); // 设置行高度
	int GetNodeChildCount(CTreeModelNode* node);
	void SetLevelLineType(LineBrushStyle type); // 设置层级线风格，虚线、实线
	void SetItemRoundRadius(RoundRectRadius& radius);
	void SetItemRoundSize(int rx, int ry);
	void SetSpacing(int space);
	void SetExpandSize(int size);
	void SetChildOffsetX(int size);
	void SetCheckBoxSize(int size);
	void ShowMultiCheckBox(BOOL show);
	void SetSearchMode(BOOL bSearch);
	void SetCheckBoxImage(SelectState state, GImageIconInfo* img); // 设置复选框图案
	void MatchTextNode(LPCTSTR str);                               // 搜索匹配的节点
	void SetExpandBtnStyle(BOOL bTriangle);
	void ShowLevelLine(BOOL show);

	BOOL Expand(CTreeModelNode* hItem, bool bExpand);  // 设定项是否展开 true 展开
	BOOL IsExpand(CTreeModelNode* hItem) const;        // 判断定项是否展开
	BOOL IsInVisibleView(CTreeModelNode* hItem) const; // 是否在可视区域内
	void Clear(BOOL bErase = TRUE);                    // 删除此函数将删除节点的所有子节点
	BOOL RemoveItem(CTreeModelNode* hItem);

	BOOL IsTreeEmpty() const;

	CTreeModelNode* RootNode();
	CTreeModelNode* InsertTreeNode(CTreeModelNode* parent, CTreeModelNode* prev, std::shared_ptr<CNodeSpanCell> item);

	void PrintToFile(FILE* fp, LPCSTR space_prefix = " ");

  protected:
	CTreeModelNode* SelectItem(CTreeModelNode* item);
	CTreeModelNode* SetHighLightItem(CTreeModelNode* item);
	CTreeModelNode* GetTreeLeafEntry(CTreeModelNode* node);
	CTreeModelNode* GetTreeUpEntry(CTreeModelNode* node);
	CTreeModelNode* MoveTreeNodeStep(CTreeModelNode* node, int step);
	CTreeModelNode* PtInTreeNode(int dy);
	CTreeModelNode* GetRowNode(int row) const;

	int GetRowCount() const;
	void ReBuildDepth();
	void DrawTreeCell(CNodeSpanCell* pCell, RECT rcView, COLORREF textColor, UINT textAlignFlag);
	BOOL PtInTreeItemCheckBox(CTreeModelNode* hItem, POINT pt);
	BOOL PtInExpandBtn(CTreeModelNode* hItem, POINT pt);
	void SetTreeItemCheckBox(CTreeModelNode* hItem, SelectState state);
	void SetChildItemCheckState(CTreeModelNode* hchild, SelectState nstate);
	void DrawTreeItem(ISurface* pSurface, RECT* lpUpdate, CTreeModelNode* node, COLORREF color, int dx = 0);
	void DrawTreeDataCell(ISurface* pSurface, int paintState, RECT* lpUpdate, CTreeModelNode* node, RECT rcCell, COLORREF color);

	void DrawTreeItemLevelLine(ISurface* pSurface, RECT& rcView, CTreeModelNode* node, COLORREF color, int fontHeight, int firstRow, int scroll_x,
	                           int scroll_y);

	void RefreshTreeNode(CTreeModelNode* node1, CTreeModelNode* node2, int base_x, int width);
	BOOL GetTreeNodeCellYBound(CTreeModelNode* node, int& y1, int& y2) const;
	void ShellModeAttribute(const char* szName, const char* szText);

	/* this override methods:*/
	virtual void OnInvalidateRect(RECT* rc, BOOL bClient) = 0;

	virtual int GetModelColumCount() = 0;

	virtual POINT GetScrollOffsetPoint() = 0;

	virtual void OnSelectItem(CTreeModelNode* item) = 0;

  private:
	void DoPrintToFile(FILE* fp, CTreeModelNode* hItem, LPCSTR prefix, int depth);
	void FreeTreeItem(CTreeModelNode* hItem);

	CTreeModelNode* AllocTreeObject(); // 分配节点

	void ReclaimTreeObject(CTreeModelNode* entry); // 回收节点

	void ItemMatched(CTreeModelNode* hItem);

	void ItemChildMatched(CTreeModelNode* hItem);

	void BuildDepth(CTreeModelNode* node, int depth, int& row_i);

	CTreeModelNode* FindTreeNodeByLineNum(CTreeModelNode* node, int row) const;

  protected:
	CTreeModelNode m_root;
	std::deque<CTreeModelNode*> m_alloc_node_buffer; // 节点内存池
	int m_nPoolSize;
	int m_nRowCount;
	int m_nTotolCount;
	int m_nItemHeight;    // 项的高度
	int m_nInterval;      // 元素之间的间隔
	int m_nExpandWidth;   // 扩展线宽度
	int m_nCheckBoxSize;  // 选中和扩展按钮的大小
	int m_nSubLineOffset; // 子节点线偏移量

	BOOL m_bShowCheckBox;
	BOOL m_bTriStyle;      // 采用三角扩展按钮风格
	BOOL m_bTreeLineStyle; // 没有层级线条
	UINT m_uMatchMask;     // 匹配掩码
	LineBrushStyle m_levelLineType;
	RoundRectRadius m_RoundRadiusHighlight; // 选中高亮圆角尺寸
	GImageIconInfo* m_pImgCheck[3];         // 复选框绘制图标(依次:未知，选中，未选中)
	CTreeModelNode* m_hBeginShowNode;       // 可见首行
	CTreeModelNode* m_hSelectedItem;        // 当前选中项
	CTreeModelNode* m_hHovenItem;           // 当前热点项

	CTreeModelNode* m_hDropItem; // 拖拽目标节点
	BOOL m_bInsetPrev;           // 拖拽目标节点插入上一个节点

	MouseDragHelper m_dragMgr; // 节点移动管理
	MouseHoverState m_expandHover;

	COLORSTYLE m_treeLevelLineColors; // 层级线颜色
	COLORSTYLE m_ChkboxColors;        // 复选框颜色风格
};


} // #namespace

#endif
