#ifndef BLUEUI_CTABCONTAINUI_BYMD_INC_H_
#define BLUEUI_CTABCONTAINUI_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CContainLayoutUI.h"
#include "CNodeCell.h"

namespace BUI {

// 标签页的容器
class UI_EXP CContainTabUI : public CControlUI
{
	DECLARE_DYNAMIC_CLASS(CContainTabUI)
  private:
	std::map<UINT, std::pair<CContainLayoutUI*, BOOL>> m_mapTabPages;
	int m_uCurSel;
	bool m_bNeedReLayout;

  public:
	CContainTabUI();
	~CContainTabUI();

	int GetTabCurSel();
	void SetTabCurSel(UINT nID);
	void RemoveTabPage(UINT nID);
	void AddTabPage(UINT nID, CContainLayoutUI* pTabPageUI, BOOL bAutoDestory = TRUE);

	void OnControlSize() override;
	void ShellAttribute(const char* szName, const char* szText) override;
	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;

  private:
	void ShowTabCtrls(UINT nID, bool bVisable);
};

}

#endif
