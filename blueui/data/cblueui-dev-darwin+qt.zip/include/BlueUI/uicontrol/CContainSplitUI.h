#ifndef BLUEUI_CSPLITCONTAINERUI_H_DDVU35K_FQX03_481VQ_45P5Z_YF0VD_INCLUDED_
#define BLUEUI_CSPLITCONTAINERUI_H_DDVU35K_FQX03_481VQ_45P5Z_YF0VD_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CContainLayoutUI.h"
#include "layout/CLayoutManager.h"

namespace BUI {

class UI_EXP CContainSplitUI : public CContainLayoutUI
{
	DECLARE_DYNAMIC_CLASS(CContainSplitUI)
  protected:
	BOOL m_bHorizontal;
	POINT m_pt;
	int m_nMaxOffset;
	int m_nSlpitWidth;
	CBaseLayout* m_changeLayout;

  public:
	CContainSplitUI();
	~CContainSplitUI();

	void SetSplitBarWidth(int width);
	void ChangeLayout(BOOL bHorizontal);

	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const char* szName, const char* szText) override;

	void OnControlSize() override;
	BOOL OnNcHitTest(POINT pt) override;
	BOOL OnLButtonDown(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseLeave(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseMove(WPARAM wParam, LPARAM lParam) override;
};




}
#endif
