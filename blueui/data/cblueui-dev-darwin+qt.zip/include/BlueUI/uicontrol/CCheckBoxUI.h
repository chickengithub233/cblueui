#ifndef BLUEUI_CHECKBOX_BYMD_INC_H_
#define BLUEUI_CHECKBOX_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif

#include "CControlUI.h"
#include "CBaseSelectState.h"

namespace BUI {

class UI_EXP CCheckBoxUI : public CControlUI, public CSelectState
{
	DECLARE_DYNAMIC_CLASS(CCheckBoxUI)
  private:
	GImageIconInfo* m_pImgCheck[3]; // 复选框绘制图标(依次:未知，选中，未选中)
	GImageIconInfo* m_pImageIcon;   // 控件图标
  public:
	CCheckBoxUI();
	~CCheckBoxUI();

	void SetCheckBoxImage(SelectState state, GImageIconInfo* img); // 设置复选框图片

	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	void Activate() override;
	int LayoutAdaptWidth(int expH) override;
	BOOL OnNcHitTest(POINT pt) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	BOOL OnLButtonDown(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const char* szName, const char* szText) override;
};

class UI_EXP CBinaryBoxUI : public CCheckBoxUI
{
	DECLARE_DYNAMIC_CLASS(CBinaryBoxUI)
  private:
	GString m_strTrue;
	GString m_strFalse;

  public:
	CBinaryBoxUI();
	~CBinaryBoxUI();

	BOOL SetCheckStateText(LPCTSTR strTrue = NULL, LPCTSTR strfalse = NULL); // 设置两种状态的显示文本
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
};


}


#endif