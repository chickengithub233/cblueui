﻿#ifndef BLUEUI_LABEL_BYMD_INC_H_
#define BLUEUI_LABEL_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CControlUI.h"

namespace BUI {

class UI_EXP CLabelUI : public CControlUI
{
	DECLARE_DYNAMIC_CLASS(CLabelUI)
  protected:
	UINT m_nTextAlign;          // 文本对齐方式
	GImageIconInfo* m_iconInfo; // 图标
	UINT m_layoutFlags;
	int m_icon_interval; // 图标和文本的间隔
  public:
	CLabelUI();
	~CLabelUI();

	void ModifyCompositeLayoutFlags(UINT style, UINT op = ADD_FLAGS); // 设置文本和图表组合方式
	UINT IsHasCompositeLayoutFlags(UINT flags) const;

	void SetControlIcon(GImageIconInfo* icon); // 设置图标
	void SetTextAlign(UINT formate);           // 设置图片和文本组合整体的对齐方式

	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;
	void OnCreate() override;
	void OnControlSize() override;
	void OnCtrlKillFocus() override;

	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const char* szName, const char* szText) override;


  protected:
	void DrawButton(ISurface* pSurface, RECT rcView, GImageIconInfo* img, int paintStates, LPCTSTR text, COLORREF color, UINT textalign, int interval,
	                RECT* lpUpdate);

	SIZE GetLayoutStringSize(LPCTSTR str);
};





}
#endif