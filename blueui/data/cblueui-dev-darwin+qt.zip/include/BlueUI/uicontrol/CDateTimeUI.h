#ifndef BLUEUI_CDATETIMEUI_BYMD_INC_H_
#define BLUEUI_CDATETIMEUI_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CControlUI.h"
#include "CButtonUI.h"
#include "CEditTextUI.h"
#include "CNodeData.h"
#include "function/DateInfo.h"

namespace BUI {

enum DateTimeFlag
{
	NotSelectableWeekDay,   // 周末不可选择
	NotSelectableFutureDay, // 未来日不可选择
	ShowLunar,              // 显示农历
};

class UI_EXP CDateTimeUI : public CEditList, public CControlUI
{
	DECLARE_DYNAMIC_CLASS(CDateTimeUI)
  private:
	DateInfo m_date; // 当前展示日期起点
	int m_nTitleHeight;
	int m_nItemHeight;
	DateInfo m_focusDate;
	UINT m_nHitFlag;

	DateInfo m_datebegin;
	DateInfo m_dateEnd;
	DateInfo m_SelectDate; // 当前选择日期

	UINT m_nDateModeFlags;
	GString m_splitText;

  public:
	CDateTimeUI();
	~CDateTimeUI();

	DateInfo GetDate();
	void GoTodday();
	void ModifyDateTimeFlags(UINT style, UINT op = ADD_FLAGS); // 设置日期控件属性
	BOOL IsHasDateTimeFlags(UINT flags) const;

	void SetCurselDate(int y, int m, int d); ///< 设置选中日期
	void SetCurselDate(LPCTSTR strDate);
	void SetCalendarRange(DateInfo begin, DateInfo end);
	void SetItemHeight(int h);
	void SetTitleHeight(int h);
	void GetDateTimeText(BasicStringBuffer& str) const;

	void OnCreate() override;
	GString GetControlText() override;
	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	BOOL OnKeyDown(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseMove(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseLeave(WPARAM wParam, LPARAM lParam) override;

	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const char* szName, const char* szText) override;

  protected:
	void CreateEditControl();
	void SetDateEditText(DateInfo& date);
	BOOL OnEditChange();
	BOOL IsEnableSelectDay(DateInfo& date);                      // 是否满足当前选择条件
	BOOL SetDate(int y, int m, int d, BOOL updateEditui = TRUE); // 设置选中日期
	BOOL SetDate(LPCTSTR strDate, BOOL updateEditui = TRUE);
};


}

#endif