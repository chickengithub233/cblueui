#ifndef BLUEUI_CKEYBOARDEDITUI_BYMD_INC_H_
#define BLUEUI_CKEYBOARDEDITUI_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "CControlUI.h"
#include "CEditTextUI.h"

namespace BUI {

/* 快捷键输入框*/
class UI_EXP CEditKeyBoardUI : public CEditTextUI
{
	DECLARE_DYNAMIC_CLASS(CEditKeyBoardUI)
  private:
	UINT m_vInputKeyCtrl; // 快捷键控制码
	UINT m_vInputKeyCode; // 快捷键码
  public:
	CEditKeyBoardUI();
	~CEditKeyBoardUI();

	UINT KeyCtrl() const;
	UINT KeyCode() const;
	void SetKeyBoard(const char* text);

	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	BOOL OnChar(WPARAM wParam, LPARAM lParam) override;
	void ShellAttribute(const char* szName, const char* szText) override;
};


}

#endif
