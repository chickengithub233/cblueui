#ifndef BLUEUI_CLABELMULTISTYLEUI_BYMD_INC_H_
#define BLUEUI_CLABELMULTISTYLEUI_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CControlUI.h"
#include "CNodeDataHtml.h"

namespace BUI {


class UI_EXP CLabelMultiStyleUI : public CControlUI, public CNodeHtmlTextData
{
	DECLARE_DYNAMIC_CLASS(CLabelMultiStyleUI)
  public:
	CLabelMultiStyleUI();
	~CLabelMultiStyleUI();

	void OnParseItemData(XMLItem* pNode) override;
	BOOL OnLButtonDown(WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const char* szName, const char* szText) override;

	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;

  protected:
	void OnRefreshHtml() override;
};



}

#endif