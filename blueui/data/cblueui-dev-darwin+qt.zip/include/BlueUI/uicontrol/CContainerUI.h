/****************************************************************************
 *
 * 虚拟窗口类
 *
 * BUI窗口控件，并不是windows那种含有窗口句柄的窗口。是我们dui架构中自我实现的类似窗口的一个容器控件
 * 可以实现自动UI布局，和拖拽，调整大小，自动适应滚动范围
 ****************************************************************************/

#ifndef BLUEUI_VIRWINDOWS_BYMD_INC_H_
#define BLUEUI_VIRWINDOWS_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CControlUI.h"
#include "CScrollBarUI.h"

namespace BUI {

enum DragMode
{
	DRAG_ANYWHERE, // 无论何时都可以拖拽
	DRAG_CAPTION,  // 仅当标题栏可以拖拽
	DRAG_NONE      // 不可拖拽
};

enum ContainerFlag
{
	Contain_showCaption      = 1 << 0, // 是否显示标题栏，标题栏具有双击展开，显示文本的功能
	Contain_UpdateView       = 1 << 1, // 更新视窗滚动范围
	Contain_EnableChangeSize = 1 << 2, // 是否可以从右下角调整自身大小
	Contain_IsZoom           = 1 << 3, // 是否最小化
	Contain_EnableZoom       = 1 << 4, // 最大最小化功能是否可用
	Contain_ShowCloseBtn     = 1 << 5,
	Contain_ShowScrollBar    = 1 << 6, // 是否显示滚动条
	Contain_DragMoveWidget   = 1 << 7, // 鼠标按下拖动窗口标识
	Contain_bkImgFullFill    = 1 << 8, // 背景图片全覆盖填充
};

/**
 * @brief 无布局功能的容器类,控件的位置全靠用户的绝对位置来确定。改变控件位置，需要开发者控制。
 *
 */
class UI_EXP CContainerUI : public CScrollAreaUI
{
	DECLARE_DYNAMIC_CLASS(CContainerUI)
  protected:
	COLORSTYLE m_titleBkColors;   // 标题栏背景颜色风格
	COLORSTYLE m_titleTextColors; // 标题栏文本颜色风格
	RECT m_rcZoom;                // 最小化记录原先的位置信息
	UINT m_nCaptionHeight;        // 标题栏高度
	UINT m_uModel;                // 模态标志，0-非模态 1- 模态
	UINT m_uHit;
	UINT m_uHitClick;
	DragMode m_dragMode;
	SIZE m_minSize;             // 窗口最小尺寸
	SIZE m_maxSize;             // 窗口最大尺寸
	UINT m_containFlags;        // ContainerFlag
	GImageIconInfo* m_pBkImage; // 背景图片
	MouseState m_closeState;    // 关闭按钮区域的鼠标状态监视

	CBrushGradientSet m_bkGradientBru;      // 背景渐变画刷
	CBrushGradientSet m_bkTitleGradientBru; // 标题背景渐变画刷
  public:
	CContainerUI();
	~CContainerUI();

	void ModifyContainerFlags(UINT style, UINT op = ADD_FLAGS); // 设置容器控件风格
	UINT IsHasContainerFlags(UINT flags) const;

	void SetBkImage(GImageIconInfo* img);
	SIZE GetChildMaxViewSize() const; // 获得所有子控件的可见范围
	void SetCaptionHeight(int h);
	void SetDragType(DragMode type);
	UINT DoModal(int nMesc = 0);

	void OnControlSize() override;
	BOOL OnNcHitTest(POINT pt) override;
	BOOL OnLButtonDown(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonCliked(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseMove(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMouseLeave(WPARAM wParam, LPARAM lParam) override;

	BOOL OnVSCrollBar(WPARAM wParam, LPARAM lParam) override;
	BOOL OnHSCrollBar(WPARAM wParam, LPARAM lParam) override;
	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	BOOL DoPaintBackGround(ISurface* pSurface, RECT* lpUpdate) override;
	void CloneAttribute(CControlUI* clone) override;
	void ShellAttribute(const char* szName, const char* szText) override;

  protected:
	void Zoomed();
	void DragMove(POINT pt);
	void OnChangeChildsPos();
	void GetCloseRect(RECT* rc);
	UINT HitTestType(POINT point);
};




}
#endif
