#ifndef BLUEUI_COPTIONCONTAINUI_BYMD_INC_H_
#define BLUEUI_COPTIONCONTAINUI_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CContainLayoutUI.h"
#include "CButtonUI.h"

namespace BUI {

class UI_EXP COptionUI : public CButtonUI, public CSelectState
{
	DECLARE_DYNAMIC_CLASS(COptionUI)
  public:
	COptionUI();
	~COptionUI();

	void OnCreate() override;
	void OnShow(bool bShow) override;
	void Activate() override;
	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
	BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;
	BOOL DoPaintBorder(ISurface* pSurface, RECT* lpUpdate) override;
	BOOL DoPaintBackGround(ISurface* pSurface, RECT* lpUpdate) override;
	int LayoutAdaptWidth(int expH) override;
	int LayoutAdaptHeight(int expW) override;
	void ShellAttribute(const char* szName, const char* szText) override;

  protected:
	int m_dir; // 标签页方向
};

class UI_EXP COptionNodeUI : public COptionUI
{
	DECLARE_DYNAMIC_CLASS(COptionNodeUI)
  public:
	COptionNodeUI();
	~COptionNodeUI();

	BOOL DoPaint(ISurface* pSurface, RECT* lpUpdate) override;

  protected:
	CNodeDataLists m_nodeList;
};

#if 0
class UI_EXP COptionItemUI : public CContainLayoutUI
{
    DECLARE_DYNAMIC_CLASS(COptionItemUI)
public:
    COptionItemUI();
    ~COptionItemUI();

    void SetOptionSelected(BOOL bSelect);
    BOOL IsOptionSelected() const;
    void OnCreate() override;
    void OnShow(bool bShow) override;
    BOOL OnLButtonUp(WPARAM wParam, LPARAM lParam) override;
    BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;
    void ShellAttribute(const char* szName, const char* szText) override;
private:
    BOOL  m_bSelected;
    std::map<GString, CControlUI*>  m_LinkVisibleUIs; // 关联控件列表
    std::map<GString, CControlUI*>  m_LinkEnableUIs;  // 可用性控件列表
};

#endif

// 单选容器，每次收到MSG_OPTION_CHANGED 消息会向其它控件发送取消选中消息
class UI_EXP CContainOptionUI : public CContainLayoutUI
{
	DECLARE_DYNAMIC_CLASS(CContainOptionUI)
  public:
	CContainOptionUI();
	~CContainOptionUI();

	BOOL OnMessageHandler(UINT message, WPARAM wParam, LPARAM lParam) override;

  private:
	BOOL m_bSyncing;
	std::vector<CControlUI*> m_option_uis;
};


}

#endif
