﻿#ifndef BLUEUI_CSCRIPTPLUGIN_BYMD_INC_H_
#define BLUEUI_CSCRIPTPLUGIN_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include "core/CCoreBasePro.h"



extern "C" {

/*
*Summary: 脚本执行入口

*Parameters:
*   char* funcname: 命令名称

*   char* argv[]: 参数数组

*   int argc: 参数个数

*Return:  0 is connect successfully
          1 is 参数不匹配
*/
UI_EXP int script_main_cmd(char* funcname, char* argv[], int argc);


/* 外部脚本插件DLL,需要实现任意一个合法的导出函数*/

typedef int (*execute_dofile)(const char* file);
typedef int (*execute_dostring)(const char* str);
}


#endif