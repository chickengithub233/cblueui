﻿#ifndef BUILIB_STACKSTRING_BYMD_INC_H_
#define BUILIB_STACKSTRING_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"
#include "GStringBufferBasic.h"

class UI_EXP GStringShortA64 : public BasicStringBufferA
{
  public:
	GStringShortA64();
	GStringShortA64(const char* str, int count = -1);
	GStringShortA64(const wchar_t* wstr, int count = -1, unsigned int CodePage = CP_UTF8);

	~GStringShortA64();

  private:
	char buffer[64];
};

class UI_EXP GStringShortA128 : public BasicStringBufferA
{
  public:
	GStringShortA128();
	GStringShortA128(const char* str, int count = -1);
	GStringShortA128(const wchar_t* wstr, int count = -1, unsigned int CodePage = CP_UTF8);
	~GStringShortA128();

  private:
	char buffer[128];
};

class UI_EXP GStringShortA260 : public BasicStringBufferA
{
  public:
	GStringShortA260();
	GStringShortA260(const char* str, int count = -1);
	GStringShortA260(const wchar_t* wstr, int count = -1, unsigned int CodePage = CP_UTF8);
	~GStringShortA260();

  private:
	char buffer[260];
};

class UI_EXP GStringShortW64 : public BasicStringBufferW
{
  public:
	GStringShortW64();
	GStringShortW64(const char* str, int count = -1, unsigned int CodePage = CP_ACP);
	GStringShortW64(const wchar_t* wstr, int count = -1);
	~GStringShortW64();

  private:
	wchar_t buffer[64];
};

class UI_EXP GStringShortW128 : public BasicStringBufferW
{
  public:
	GStringShortW128();
	GStringShortW128(const char* str, int count = -1, unsigned int CodePage = CP_ACP);
	GStringShortW128(const wchar_t* wstr, int count = -1);
	~GStringShortW128();

  private:
	wchar_t buffer[128];
};

class UI_EXP GStringShortW260 : public BasicStringBufferW
{
  public:
	GStringShortW260();
	GStringShortW260(const char* str, int count = -1, unsigned int CodePage = CP_ACP);
	GStringShortW260(const wchar_t* wstr, int count = -1);
	~GStringShortW260();

  private:
	wchar_t buffer[260];
};

// 通用字符预定义
#ifdef _UNICODE
typedef GStringShortW64 GStringShort64;
typedef GStringShortW128 GStringShort128;
typedef GStringShortW260 GStringShort260;
#else
typedef GStringShortA64 GStringShort64;
typedef GStringShortA128 GStringShort128;
typedef GStringShortA260 GStringShort260;
#endif



#endif
