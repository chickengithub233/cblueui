﻿#ifndef BLUEUI_STRING_STRINGBUFFERBASIC_BYMD_INC_H_
#define BLUEUI_STRING_STRINGBUFFERBASIC_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"

int check_text_len_a(const char* str, int len);
int check_text_len_w(const wchar_t* str, int len);

/**
 * @brief 绑定字符流，会改变字符流数据(多字符集)
 *
 */
class UI_EXP BasicStringBufferA
{
  public:
	/**
	 * @param source 源字符
	 * @param capacity  源字符容量
	 */
	BasicStringBufferA(char* source, int capacity);
	~BasicStringBufferA();
	int length() const;        ///< 字符串长度
	const char* c_str() const; ///< 源字符串

	void append(const char* str, int len = -1);               ///< 尾部添加字符串
	void append(char ch, int repeat = 1);                     ///< 尾部添加单个字符
	int replace_char(char chOld, char chNew);                 ///< 替换字符
	int replace_string(const char* chOld, const char* chNew); ///< 替换字符串
	void trim();                                              ///< 剔除字符串头尾空白符(空格、换行、tab)
	void trim_left();                                         ///< 剔除字符串前缀空白符(空格、换行、tab)
	void trim_right();                                        ///< 剔除字符串末尾空白符(空格、换行、tab)
	void trim_all();                                          ///< 剔除字符串任意位置空白符(空格、换行、tab)
	void format_ellipsis(const char* str, UINT align);        ///< 长度超出范围时显示省略号
	void format(const char* lpszFormat, ...);                 ///< 格式化打印
	void format_v(const char* lpszFormat, va_list args);


	void insert(int nIndex, const char* str, int count = -1); ///< 插入字符串
	void erase(int nIndex, int nCount = 1);                   ///< 删除字符
	void remove_float_last_zero();                            ///<  去除浮点数多余的0后缀
	void add_numeric_thousand_separator();                    ///< 数字千分分隔符
	void clear();                                             ///< 清空字符串
	void resize(unsigned len);
	void init(const char* str, int count = -1);
	void init(const wchar_t* wstr, int count = -1, unsigned int CodePage = CP_UTF8);
	void join_path(const char* str);

  protected:
	void _alloc_size(int size);

  private:
	char* m_data_ptr;
	char* m_source_; // 缓冲区
	int m_buf_len;   // 固定缓冲容量
	int m_nCapacity; // 字符重新分配容量
};

/**
 * @brief 绑定字符流，会改变字符流数据(宽字符集)
 *
 */
class UI_EXP BasicStringBufferW
{
  public:
	BasicStringBufferW(wchar_t* source, int capacity);
	~BasicStringBufferW();

	int length() const;
	const wchar_t* c_str() const;

	void append(const wchar_t* str, int len = -1);
	void append(wchar_t ch, int repeat = 1);
	int replace_char(wchar_t chOld, wchar_t chNew);
	int replace_string(const wchar_t* chOld, const wchar_t* chNew);

	void trim();                                          ///< 剔除字符串头尾空白符(空格、换行、tab)
	void trim_left();                                     ///< 剔除字符串前缀空白符(空格、换行、tab)
	void trim_right();                                    ///< 剔除字符串末尾空白符(空格、换行、tab)
	void trim_all();                                      ///< 剔除字符串任意位置空白符(空格、换行、tab)
	void format_ellipsis(const wchar_t* str, UINT align); ///< 长度超出范围时显示省略号
	void format(const wchar_t* lpszFormat, ...);
	void format_v(const wchar_t* lpszFormat, va_list args);
	void insert(int nIndex, const wchar_t* str, int count = -1);
	void erase(int nIndex, int nCount = 1);
	void remove_float_last_zero();
	void add_numeric_thousand_separator(); ///< 数字千分分隔符

	void clear();
	void resize(unsigned len);
	void init(const char* str, int count = -1, unsigned int CodePage = CP_UTF8);
	void init(const wchar_t* wstr, int count = -1);

	void join_path(const wchar_t* wstr);

  protected:
	void _alloc_size(int size);

  private:
	wchar_t* m_data_ptr;
	wchar_t* m_source_;
	int m_buf_len;
	int m_nCapacity;
};


#ifdef _UNICODE
typedef BasicStringBufferW BasicStringBuffer;
#else
typedef BasicStringBufferA BasicStringBuffer;
#endif

#endif
