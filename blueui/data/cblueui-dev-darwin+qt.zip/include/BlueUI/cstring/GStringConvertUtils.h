#ifndef BLUEUI_STRINGCONVERTUTILS_BYMD_INC_H_
#define BLUEUI_STRINGCONVERTUTILS_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"
#include "GStringBufferBasic.h"
#include <string>
#include <vector>

namespace UtilsString {

/**
 * @brief 判断字符串是否为ASCII
 *
 */
UI_EXP bool IsASCIIText(const char* str);

/**
 * @brief 判断字符串是否为ASCII
 *
 */
UI_EXP bool IsASCIITextW(const wchar_t* str);

UI_EXP int ConverterMultiByteToWideChar(UINT CodePage, const char* lpMultiByteStr, int cbMultiByte, wchar_t* lpWideCharStr, int cchWideChar);


UI_EXP int ConverterWideCharToMultiByte(UINT CodePage, const wchar_t* lpWideCharStr, int cchWideChar, char* lpMultiByteStr, int cbMultiByte);

/**
 * @brief 判断字符是否是UTF8编码方式
 *
 */
UI_EXP bool IsUTF8(const char* str);

/**
 * @brief 判断字符是否是GBK编码方式
 *
 */
UI_EXP bool IsGBK(const char* str);

/**
 * @brief convert unicode to utf8
 *
 * @param buf 输出utf8格式字符缓冲
 * @param buf_size
 * @param wide_char 宽字符编码
 * @return int 返回utf8字节数
 */
UI_EXP int WideCharToUtf8(char* buf, int buf_size, unsigned int wide_char);

/**
 * @brief convert utf8 to unicode
 *
 * @param out_char 输出unicode字符
 * @param in_text 起始字符
 * @param in_text_end 结束字符
 * @return int 返回转换utf8占用字节数
 */
UI_EXP int Utf8CharToWide(unsigned int* out_char, const char* in_text, const char* in_text_end);

/**
 * @brief unicode转换为utf-8格式
 *
 */
UI_EXP int UnicodeToUtf8(const wchar_t* wc, int len, BasicStringBufferA& outstr);

/**
 * @brief utf-8转换为unicode格式
 *
 */
UI_EXP int Utf8ToUnicode(const char* src, int len, BasicStringBufferW& outstr);

/**
 * @brief utf-8转换为unicode格式
 *
 */
UI_EXP int UTF8toANSI(const char* strUTF8, int len, BasicStringBufferA& outstr);

/**
 * @brief unicode to utf-8
 *
 */
UI_EXP int ANSIToUTF8(const char* strUTF8, int len, BasicStringBufferA& outstr);

enum ChinaPinyinOption
{
	PY_MASK_FULLNAME     = 1,      // bit0:  1代表全拼 0 代表简称
	PY_MASK_FIRST_CAPS   = 1 << 1, // bit1:  1首字母大写 0 全部小写
	PY_MASK_ALL_CAPS     = 1 << 2, // bit2:  1全部大写 0 全部小写
	PY_MASK_INSERT_SPACE = 1 << 3, // bit3:  1汉字间插入空格 0 不插入符号

};

/**
 * @brief 转换为拼音
 *
 * @param utf8Str utf8格式字符
 * @param options :ChinaPinyinOption
 * @param [#out] result:
 */
UI_EXP void UnicodeToChinaPinyin(LPCSTR utf8Str, UINT options, std::string& result);

UI_EXP bool ParseRange(const char* szText, double* min, double* max);

UI_EXP BOOL IsLittleEnding(); // 是否是小端模式
UI_EXP BOOL IsStackPtr(void* p);

UI_EXP BOOL IsDecimalFormateA(const char* str, int len = -1); // 是否满足小数输入格式
UI_EXP BOOL IsIntegerA(const char* str, int len = -1);
UI_EXP BOOL IsIdentfierA(const char* str, int len = -1);

UI_EXP BOOL IsDecimalFormateW(const wchar_t* str, int len = -1); // 是否满足小数输入格式
UI_EXP BOOL IsIntegerW(const wchar_t* str, int len = -1);
UI_EXP BOOL IsIdentfierW(const wchar_t* str, int len = -1);

UI_EXP BOOL IsDecimalFormate(const TCHAR* str, int len = -1); // 是否满足小数输入格式
UI_EXP BOOL IsInteger(const TCHAR* str, int len = -1);
UI_EXP BOOL IsIdentfier(const TCHAR* str, int len = -1);

UI_EXP int GetIntegerCharCount(int v); //获得整数需要的十进制位数位数
// 返回字符个数
UI_EXP int GetCharsCount(LPCTSTR text, int count);

UI_EXP std::vector<std::string> SplitWithCharA(const char* str, const char* pattern, int count = 0);

UI_EXP std::vector<std::string> SplitWithTextA(std::string str, std::string pattern, int count = 0);

UI_EXP std::vector<std::wstring> SplitWithCharW(const wchar_t* str, const wchar_t* pattern, int count = 0);

UI_EXP std::vector<std::wstring> SplitWithTextW(std::wstring str, std::wstring pattern, int count = 0);

UI_EXP void SplitAttribute(const char* text, std::vector<std::pair<std::string, std::string>>& result);

// 获取上级目录
UI_EXP void GetPrevDirPath(LPCTSTR fullname, BasicStringBuffer& prev_path);

// 获取文件后缀 isComplete完整后缀
UI_EXP void GetFileSuffix(LPCTSTR fullname, BasicStringBuffer& suffix, BOOL isComplete = TRUE);

// 获取不包含后缀的文件名 isComplete完整后缀
UI_EXP void GetFileBaseNmae(LPCTSTR fullname, BasicStringBuffer& basename, BOOL isComplete = TRUE);

// 获取文件名称
UI_EXP void GetFileNmae(LPCTSTR fullname, BasicStringBuffer& filename);

// 获取路径，不包含文件
UI_EXP void GetFilePath(LPCTSTR fullname, BasicStringBuffer& filepath);

}

class UI_EXP NumericalValueList
{
  public:
	NumericalValueList(const char* str, const char* delimiter = ",");
	~NumericalValueList();

	void SetValueText(const char* str, const char* delimiter);

	double operator[](int nIndex) const;

	RECT ToRect() const;

  private:
	int m_count;
	double m_value[8];
	std::vector<double> m_value_ex;
};






#endif
