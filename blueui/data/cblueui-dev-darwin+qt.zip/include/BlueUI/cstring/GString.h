
#ifndef BLUEUI_UStringUU_BYMD_INC_H_
#define BLUEUI_UStringUU_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <stdlib.h>
#include <atomic>
#include "core/CCoreBasePro.h"
#include "GStringConvertUtils.h"

#define ALIGN_SIZE_U     (7) // 编译器的对齐字节数
#define MIN_ALLOC_SIZE_U 32  // 最小分配大小

struct StringHeadInfoU
{
	std::atomic_long nRefs;    // 引用记数 当前拥有此块内存的对象个数. 引用为0表示空字符串
	unsigned int nDataLength;  // 字符使用长度
	unsigned int nAllocLength; // 分配长度
	wchar_t* after_tr;         // 翻译后的文本

	StringHeadInfoU()
	    : nRefs(1)
	    , nDataLength(0)
	    , nAllocLength(0)
	    , after_tr(NULL)
	{}

	wchar_t* data()
	{
		return (wchar_t*)(this + 1); // 存放字符串的地方
	}
};

struct MemBufferU
{
	char* pmem;     // 内存地址
	UINT nmem_size; // 内存长度
};

class UI_EXP GStringW
{
  public:
	GStringW();
	GStringW(int nLength); // nLength是预分配长度
	GStringW(const GStringW& stringSrc);
	GStringW(wchar_t ch, int repeats);

	GStringW(LPCWSTR lpsz, int nlen = -1);

	GStringW(LPCSTR lpsz, int nlen = -1, UINT codepage = CP_ACP);
	~GStringW();
	const wchar_t* c_str() const; // 获得内存数据

	const GStringW& operator=(const GStringW& stringSrc);
	const GStringW& operator=(LPCWSTR lpsz);
	const GStringW& operator=(LPCSTR ansi);
	const GStringW& operator=(wchar_t ch);

	GStringW operator+(const GStringW& src) const;
	GStringW operator+(LPCWSTR pstr) const;
	const GStringW& operator+=(const GStringW& src);
	const GStringW& operator+=(LPCWSTR pstr);
	const GStringW& operator+=(const wchar_t ch);

	bool operator==(const GStringW& str) const;
	bool operator==(LPCWSTR lpsz) const;
	bool operator!=(const GStringW& str) const;
	bool operator!=(LPCWSTR lpsz) const;
	bool operator<(const GStringW& str) const;
	bool operator>(const GStringW& str) const;
	bool operator<=(const GStringW& str) const;
	bool operator>=(const GStringW& str) const;

	wchar_t& operator[](int nIndex) const;
	int length() const; // 得到字符长度

	int capacity() const; // 得到分配的内存长度

	bool is_empty() const; // 判断字符长度是否为0

	bool is_number() const; // 判断是否全部为整数

	bool is_email(); // 判断是否是邮箱

	bool is_ipv4(); // 判断是否是IPV4地址
	bool is_ipv6(); // 判断是否是IPV6地址

	bool is_decimal_number() const; // 判断是否为小数

	int repeat_counts(wchar_t ch); // 字符重复的次数

	void empty();

	void release(); // 若引用<= 1释放内存 引用记数器并判断是否删除内存

	int erase(int nIndex, int nCount = 1);
	int append(LPCWSTR lpsz);
	int append(const wchar_t ch);
	int append(LPCWSTR lpsz, unsigned int nlen);
	int append(const GStringW& strSrc);
	int append(const GStringW& strSrc, unsigned int nlen);

	void join_path(const wchar_t* wstr);

	int insert(int nIndex, wchar_t ch); // 在nIndex前面插入
	int insert(int nIndex, LPCWSTR pstr, int len = -1);

	int replace_char(wchar_t chOld, wchar_t chNew); // 替换
	int replace_string(LPCWSTR lpszOld, LPCWSTR lpszNew);

	int toInt() const; // 转换成数字

	double tofloat() const; // 转换 浮点型

	void trim(); // 整理字符串, 清除指定字符串
	void trim_left();
	void trim_right();
	void remove(wchar_t chTarget);
	void remove(LPCWSTR lpszTargets);
	void remove_float_last_zero(); //  去除浮点数多余的0后缀
	void make_upper();
	void make_lower();

	GStringW mid(int nStart, int nCount) const;

	int compare(LPCWSTR lpsz) const; // 区分大小写 ，<0 表示 自己strself小于lpsz （stringSrc）
	int compare(const GStringW& stringSrc) const;

	int compare_no_case(LPCWSTR lpsz) const; // 不区分大小写
	int compare_no_case(const GStringW& stringSrc) const;

	void format(LPCWSTR lpszFormat, ...);
	int find(wchar_t ch) const; // 查找
	int find(wchar_t ch, int nStart) const;
	int reverse_find(wchar_t ch) const;
	int find(LPCWSTR lpszSub) const;
	int find(LPCWSTR lpszSub, int nStart) const;
	int find_one_of(LPCWSTR lpszCharSet) const; // 得到第一个匹配lpszCharSet中其中一个字符的位置 调用_tcspbrk

  private:
	StringHeadInfoU* get_data() const; // 获得指定的数据结构

	void release(StringHeadInfoU* pData);

	void free_string_data(StringHeadInfoU* pData); // 释放指定结构

	void init_string();

	void formate_v(LPCWSTR lpszFormat, va_list argList); // 格式化

	int safe_strlen(LPCWSTR lpsz);

	void assign_copy(int nSrcLen, LPCWSTR lpszSrcData); // 分配字符空间

	void alloc_buffer(int nLen); // 给CStringData分配内存 并将内存块的数据长度设置为 nLen

	void copy_before_write(); // 脱离数据块

	void free_real_memory(char* pFree); // 字符内存释放

	unsigned int get_alloc_memsize(unsigned int nlen); // 返回值是内存块的大小

	MemBufferU alloc_real_memory(unsigned int nSize); // 字符内存分配

	static BOOL is_valid_string(LPCWSTR lpsz, int nLength = -1);

  private:
	wchar_t* m_pchData; // 底层 字符串指针
};


#if defined(UNICODE) || defined(_UNICODE)
typedef GStringW GString;
#endif

#endif