﻿
#ifndef BLUEUI_CMAINEVENTHANDLER_PRO_BYMD_INC_H_
#define BLUEUI_CMAINEVENTHANDLER_PRO_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CCoreBasePro.h"
#include "CCoreEventHandler.h"
#include "CCoreObject.h"

namespace BUI {

class UI_EXP CManagerHandler : public IEventHandler
{
  public:
	CManagerHandler(IManageHandler* pM);
	virtual ~CManagerHandler();

	void BindUI();

	IManageHandler* GetUIManager();

	virtual BOOL OnMessageHandler(UINT message, WPARAM wp, LPARAM lp);

  protected:
	IManageHandler* m_manager;
};

}

#endif