﻿#ifndef BLUEUI_BASE_MARKUPITEM_BYMD_INC_H_
#define BLUEUI_BASE_MARKUPITEM_BYMD_INC_H_

#include "CCoreBasePro.h"
#include <vector>

namespace BUI {

class UI_EXP StringPair
{
  public:
	const char* m_name;
	const char* m_value;

	StringPair()
	    : m_name(NULL)
	    , m_value(NULL)
	{
	}

	StringPair(const char* name, const char* value)
	    : m_name(name)
	    , m_value(value)
	{
	}

	StringPair(const StringPair& pair)
	    : m_name(pair.m_name)
	    , m_value(pair.m_value)
	{
	}
};

class UI_EXP XMLItem
{
  public:
	XMLItem()
	    : parent(NULL)
	    , firstChild(NULL)
	    , lastChild(NULL)
	    , prevSibling(NULL)
	    , nextSibling(NULL){

	      };

	StringPair& LabelPair()
	{
		return label;
	}

	StringPair& AttrbuteTextPair(unsigned int i)
	{
		return attributeList[i];
	}

	unsigned int AttrbuteCount() const
	{
		return attributeList.size();
	}

	XMLItem* FirstChild() const
	{
		return firstChild;
	}

	XMLItem* LastChild() const
	{
		return lastChild;
	}

	XMLItem* PrevSibling() const
	{
		return prevSibling;
	}

	XMLItem* NextSibling() const
	{
		return nextSibling;
	}

	XMLItem* Parent() const
	{
		return parent;
	}

	const char* FindAttribute(const char* name)
	{
		int len = attributeList.size();
		for (int i = 0; i < len; ++i)
			if (stricmp(attributeList[i].m_name, name) == 0)
				return attributeList[i].m_value;
		return NULL;
	}

	// 不用递归的遍历时调用
	static XMLItem* NextItem(XMLItem* item)
	{
		XMLItem* next = item->firstChild;
		if (next == NULL)
		{
			XMLItem* pParent = item;
			while (pParent)
			{
				next = pParent->nextSibling;
				if (next)
					break;
				pParent = pParent->parent;
			}
		}
		return next;
	}


  public:
	XMLItem* parent;
	XMLItem* firstChild;
	XMLItem* lastChild;
	XMLItem* prevSibling;
	XMLItem* nextSibling;
	StringPair label;
	std::vector<StringPair> attributeList;
};


}
#endif