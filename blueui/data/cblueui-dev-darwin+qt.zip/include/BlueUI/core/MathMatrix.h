﻿#ifndef BLUEUI_UTILSMATRIX_CORE_PRO_BYMD_INC_H_
#define BLUEUI_UTILSMATRIX_CORE_PRO_BYMD_INC_H_

#include <stdio.h>
#include <math.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"


// 二维矩阵运算
#define EPSILON 0.000001

#define ROUND(x) (((x) >= 0) ? (int)(x + 0.5) : (int)(x - 0.5))


class Matrix3x3;
class Matrix4x4;

// begin
//----------------------------------------------------------------SRect
template <class T> struct SGRect
{

	T left, top, right, bottom;

	SGRect()
	    : left(0)
	    , top(0)
	    , right(0)
	    , bottom(0)
	{}

	SGRect(T l, T t, T r, T b)
	    : left(l)
	    , top(t)
	    , right(r)
	    , bottom(b)
	{}

	void SetSRect(T l, T t, T r, T b)
	{
		left   = l;
		top    = t;
		right  = r;
		bottom = b;
	}

	bool HitTest(T x, T y) const { return (x >= left && x <= right && y >= top && y <= bottom); }

	void CenterPoint(T* x, T* y)
	{
		assert(x && y);
		*x = (left + right) * 0.5;
		*y = (top + bottom) * 0.5;
	}
};

typedef SGRect<int> SG_RECT;
typedef SGRect<float> SG_RECT_FLOAT;
typedef SGRect<float> SG_RECT_DOUBLE;

//---------------------------------------    SPoint
template <class T> struct SGPoint
{
	T PosX, PosY;

	SGPoint()
	    : PosX(0)
	    , PosY(0)
	{}

	SGPoint(T x, T y)
	    : PosX(x)
	    , PosY(y)
	{}

	void operator=(const SGPoint<T>& pt)
	{
		PosX = pt.PosX;
		PosY = pt.PosY;
	}

	SGPoint operator+(const SGPoint<T>& pt) { return SGPoint((T)(PosX + pt.PosX), (T)(PosY + pt.PosY)); }

	////根据矩阵变换后的结果
	// SGPoint & Transform2D(const Matrix3x3 & mat)
	//{
	//	float  x  = PosX, y = PosY;
	//	float  rx  = 0, ry  = 0, rw  = 1;
	//	rx = x * mat._m11 + y * mat._m21 + mat._m31;
	//	ry = x * mat._m12 + y * mat._m22 + mat._m32;
	//	PosX = rx; PosY = ry;
	//       return  *this;
	//}

	void SetPostion(T x, T y)
	{
		PosX = x;
		PosY = y;
	}
};

typedef SGPoint<int> SG_POINT;
typedef SGPoint<float> SG_POINT_FLOAT;
typedef SGPoint<float> SG_POINT_DOUBLE;

//----------------------------------------------
template <class T> struct SGPoint3D
{
	T PosX, PosY, PosZ;

	SGPoint3D()
	    : PosX(0)
	    , PosY(0)
	    , PosZ(0)
	{}

	SGPoint3D(T x, T y, T z)
	    : PosX(x)
	    , PosY(y)
	    , PosZ(z)
	{}

	void operator=(const SGPoint3D<T>& pt)
	{
		PosX = pt.PosX;
		PosY = pt.PosY;
		PosZ = pt.PosZ;
	}

	SGPoint3D<T> operator+(const SGPoint3D<T>& pt) { return SGPoint3D((T)(PosX + pt.PosX), (T)(PosY + pt.PosY), T(PosZ + pt.PosZ)); }

	SGPoint3D<T> operator*(float s) { return SGPoint3D((T)(s * PosX), (T)(s * PosY), T(s * PosZ)); }

	void operator*=(float s)
	{
		PosX = (T)(s * PosX);
		PosY = (T)(s * PosY);
		PosZ = (T)(s * PosZ);
	}

	// SGPoint3D & Transform3D(const Matrix4x4 & mat)
	//{
	//	float  x  = 	 PosX, y = PosY, z = PosZ;
	//	float  rx  = 0, ry = 0, rz = 0;
	//	rx = x * mat._m11 + y * mat._m21 + z * mat._m31 + mat._m41;
	//	ry = x * mat._m12 + y * mat._m22 + z * mat._m32 + mat._m42;
	//	rz = x * mat._m13 + y * mat._m23 + z * mat._m33 + mat._m43;
	//	return  SGPoint3D((T)rx, (T)ry, T(rz));
	// }


	void SetPostion(T x, T y, T z)
	{
		PosX = x;
		PosY = y;
		PosZ = z;
	}
};

typedef SGPoint3D<int> SG_POINT3D;
typedef SGPoint3D<float> SG_POINT3D_FLOAT;
typedef SGPoint3D<float> SG_POINT3D_DOUBLE;

//----------------------------------------------------------------SSize
template <class T> struct SGSize
{

	T cx, cy;

	SGSize()
	    : cx(0)
	    , cy(0)
	{}

	SGSize(T width, T height)
	    : cx(width)
	    , cy(height)
	{}

	void operator=(const SGSize<T>& size)
	{
		cx = size.cx;
		cy = size.cy;
	}
};

typedef SGSize<int> SG_SIZE;
typedef SGSize<float> SG_SIZE_FLOAT;
typedef SGSize<float> SG_SIZE_DOUBLE;

class UI_EXP Matrix3x3
{
  public:
	float _m11, _m12, _m13;
	float _m21, _m22, _m23;
	float _m31, _m32, _m33;

  public:
	Matrix3x3() { Normal(); }

	Matrix3x3(float m11, float m12, float m13, float m21, float m22, float m23, float m31, float m32, float m33)
	{
		_m11 = m11;
		_m12 = m12;
		_m13 = m13;
		_m21 = m21;
		_m22 = m22;
		_m23 = m23;
		_m31 = m31;
		_m32 = m32;
		_m33 = m33;
	}

	~Matrix3x3() {}

	// 单位化
	void Normal()
	{
		_m11 = 1;
		_m12 = 0;
		_m13 = 0;
		_m21 = 0;
		_m22 = 1;
		_m23 = 0;
		_m31 = 0;
		_m32 = 0;
		_m33 = 1;
	}

	void operator=(const Matrix3x3& c)
	{
		_m11 = c._m11;
		_m12 = c._m12;
		_m13 = c._m13;
		_m21 = c._m21;
		_m22 = c._m22;
		_m23 = c._m23;
		_m31 = c._m31;
		_m32 = c._m32;
		_m33 = c._m33;
	}

	Matrix3x3 operator*(const Matrix3x3& c)
	{
		return Matrix3x3(
		_m11 * c._m11 + _m12 * c._m21 + _m13 * c._m31, _m11 * c._m12 + _m12 * c._m22 + _m13 * c._m32, _m11 * c._m13 + _m12 * c._m23 + _m13 * c._m33,
		_m21 * c._m11 + _m22 * c._m21 + _m23 * c._m31, _m21 * c._m12 + _m22 * c._m22 + _m23 * c._m32, _m21 * c._m13 + _m22 * c._m23 + _m23 * c._m33,
		_m31 * c._m11 + _m32 * c._m21 + _m33 * c._m31, _m31 * c._m12 + _m32 * c._m22 + _m33 * c._m32, _m31 * c._m13 + _m32 * c._m23 + _m33 * c._m33);
	}

	template <typename T> Matrix3x3& operator*(T* c)
	{
		_m11 *= c;
		_m12 *= c;
		_m13 *= c;
		_m21 *= c;
		_m22 *= c;
		_m23 *= c;
		_m31 *= c;
		_m32 *= c;
		_m33 *= c;
		return *this;
	}

	// 旋转 单位是弧度
	Matrix3x3& Rotate(float angle)
	{
		float cosT = cos(angle);
		float sinT = sin(angle);
		Matrix3x3 t(cosT, -sinT, 0, sinT, cosT, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 平移
	Matrix3x3& Translate(float dx, float dy)
	{
		Matrix3x3 t(1, 0, 0, 0, 1, 0, dx, dy, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 转置
	Matrix3x3& Transposition()
	{
		float temp = 0.0;
		temp       = _m21;
		_m21       = _m12;
		_m12       = temp;
		temp       = _m31;
		_m31       = _m13;
		_m13       = temp;
		temp       = _m32;
		_m32       = _m23;
		_m23       = temp;
		return *this;
	}

	// 中心对成
	Matrix3x3& MirrorCenter()
	{
		Matrix3x3 t(-1, 0, 0, 0, -1, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// X对称
	Matrix3x3& MirrorX()
	{
		Matrix3x3 t(1, 0, 0, 0, -1, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// Y轴对称
	Matrix3x3& MirrorY()
	{
		Matrix3x3 t(-1, 0, 0, 0, 1, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 比例变换
	Matrix3x3& Scale(float sx, float sy)
	{
		Matrix3x3 t(sx, 0, 0, 0, sy, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	inline float Determinant() { return _m22 * (_m11 * _m33 - _m13 * _m31) + _m12 * (_m23 * _m13 - _m21 * _m33) + _m32 * (_m13 * _m21 - _m11 * _m23); }

	// 逆矩阵
	Matrix3x3 Inverse()
	{
		float det = Determinant();
		float _r11, _r12, _r13;
		float _r21, _r22, _r23;
		float _r31, _r32, _r33;
		if (det <= EPSILON)
		{
			_r11 = 0;
			_r12 = 0;
			_r13 = 0;
			_r21 = 0;
			_r22 = 0;
			_r23 = 0;
			_r31 = 0;
			_r32 = 0;
			_r33 = 0;
		}
		else
		{

			_r11 = (_m22 * _m33 - _m23 * _m32) / det;
			_r12 = (_m13 * _m32 - _m12 * _m33) / det;
			_r13 = (_m12 * _m23 - _m13 * _m22) / det;

			_r21 = (_m23 * _m31 - _m21 * _m33) / det;
			_r22 = (_m11 * _m33 - _m13 * _m31) / det;
			_r23 = (_m13 * _m21 - _m11 * _m23) / det;

			_r31 = (_m21 * _m32 - _m22 * _m31) / det;
			_r32 = (_m12 * _m31 - _m11 * _m32) / det;
			_r33 = (_m11 * _m22 - _m12 * _m21) / det;
		}
		return Matrix3x3(_r11, _r12, _r13, _r21, _r22, _r23, _r31, _r32, _r33);
	}
};

class UI_EXP Matrix4x4
{
  public:
	float _m11, _m12, _m13, _m14;
	float _m21, _m22, _m23, _m24;
	float _m31, _m32, _m33, _m34;
	float _m41, _m42, _m43, _m44;

  public:
	Matrix4x4() { Normal(); }

	Matrix4x4(float m11, float m12, float m13, float m14, float m21, float m22, float m23, float m24, float m31, float m32, float m33, float m34, float m41,
	          float m42, float m43, float m44)
	{
		_m11 = m11;
		_m12 = m12;
		_m13 = m13;
		_m14 = m14;
		_m21 = m21;
		_m22 = m22;
		_m23 = m23;
		_m24 = m24;
		_m31 = m31;
		_m32 = m32;
		_m33 = m33;
		_m34 = m34;
		_m41 = m41;
		_m42 = m42;
		_m43 = m43;
		_m44 = m44;
	}

	// 单位化
	void Normal()
	{
		_m11 = 1;
		_m12 = 0;
		_m13 = 0;
		_m14 = 0;
		_m21 = 0;
		_m22 = 1;
		_m23 = 0;
		_m24 = 0;
		_m31 = 0;
		_m32 = 0;
		_m33 = 1;
		_m34 = 0;
		_m41 = 0;
		_m42 = 0;
		_m43 = 0;
		_m44 = 1;
	}

	void operator=(const Matrix4x4& c)
	{
		_m11 = c._m11;
		_m12 = c._m12;
		_m13 = c._m13;
		_m14 = c._m14;
		_m21 = c._m21;
		_m22 = c._m22;
		_m23 = c._m23;
		_m24 = c._m24;
		_m31 = c._m31;
		_m32 = c._m32;
		_m33 = c._m33;
		_m34 = c._m34;
		_m41 = c._m41;
		_m42 = c._m42;
		_m43 = c._m43;
		_m44 = c._m44;
	}

	Matrix4x4 operator*(const Matrix4x4& c)
	{
		return Matrix4x4(_m11 * c._m11 + _m12 * c._m21 + _m13 * c._m31 + _m14 * c._m41, _m11 * c._m12 + _m12 * c._m22 + _m13 * c._m32 + _m14 * c._m42,
		                 _m11 * c._m13 + _m12 * c._m23 + _m13 * c._m33 + _m14 * c._m43, _m11 * c._m14 + _m12 * c._m24 + _m13 * c._m34 + _m14 * c._m44,

		                 _m21 * c._m11 + _m22 * c._m21 + _m23 * c._m31 + _m24 * c._m41, _m21 * c._m12 + _m22 * c._m22 + _m23 * c._m32 + _m24 * c._m42,
		                 _m21 * c._m13 + _m22 * c._m23 + _m23 * c._m33 + _m24 * c._m43, _m21 * c._m14 + _m22 * c._m24 + _m23 * c._m34 + _m24 * c._m44,

		                 _m31 * c._m11 + _m32 * c._m21 + _m33 * c._m31 + _m34 * c._m41, _m31 * c._m12 + _m32 * c._m22 + _m33 * c._m32 + _m34 * c._m42,
		                 _m31 * c._m13 + _m32 * c._m23 + _m33 * c._m33 + _m34 * c._m43, _m31 * c._m14 + _m32 * c._m24 + _m33 * c._m34 + _m34 * c._m44,

		                 _m41 * c._m11 + _m42 * c._m21 + _m43 * c._m31 + _m44 * c._m41, _m41 * c._m12 + _m42 * c._m22 + _m43 * c._m32 + _m44 * c._m42,
		                 _m41 * c._m13 + _m42 * c._m23 + _m43 * c._m33 + _m44 * c._m43, _m41 * c._m14 + _m42 * c._m24 + _m43 * c._m34 + _m44 * c._m44);
	}

	template <typename T> Matrix4x4& operator*(T* c)
	{
		_m11 *= c;
		_m12 *= c;
		_m13 *= c;
		_m14 *= c;
		_m21 *= c;
		_m22 *= c;
		_m23 *= c;
		_m24 *= c;
		_m31 *= c;
		_m32 *= c;
		_m33 *= c;
		_m34 *= c;
		_m41 *= c;
		_m42 *= c;
		_m43 *= c;
		_m44 *= c;
		return *this;
	}

	// 比例变换
	Matrix4x4& Scale(float sx, float sy, float sz)
	{
		Matrix4x4 t(sx, 0, 0, 0, 0, sy, 0, 0, 0, 0, sz, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 绕X旋转 转角的方向满足右手螺旋法则：大拇指指向旋转轴正向，四指弯曲的方向为转角方向
	Matrix4x4& RotateX(float angle)
	{
		float cosT = cos(angle);
		float sinT = sin(angle);
		Matrix4x4 t(1, 0, 0, 0, 0, cosT, sinT, 0, 0, -sinT, cosT, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 旋转
	Matrix4x4& RotateY(float angle)
	{
		float cosT = cos(angle);
		float sinT = sin(angle);
		Matrix4x4 t(cosT, 0, -sinT, 0, 0, 1, 0, 0, sinT, 0, cosT, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 旋转
	Matrix4x4& RotateZ(float angle)
	{
		float cosT = cos(angle);
		float sinT = sin(angle);
		Matrix4x4 t(cosT, sinT, 0, 0, -sinT, cosT, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 反射变换
	//  X对称
	Matrix4x4& MirrorX()
	{
		Matrix4x4 t(1, 0, 0, 0, 0, -1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	Matrix4x4& MirrorY()
	{
		Matrix4x4 t(-1, 0, 0, 0, 0, 1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 基于XoY平面反射
	Matrix4x4& MirrorXOY()
	{
		Matrix4x4 t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	Matrix4x4& MirrorYOZ()
	{
		Matrix4x4 t(-1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	Matrix4x4& MirrorXOZ()
	{
		Matrix4x4 t(1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 平移
	Matrix4x4& Translate(float dx, float dy, float dz)
	{
		Matrix4x4 t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, dx, dy, dz, 1);
		(*this) = (*this) * t;
		return *this;
	}

	// 转置
	Matrix4x4& Transposition()
	{
		float temp = 0.0;
		temp       = _m21;
		_m21       = _m12;
		_m12       = temp;
		temp       = _m31;
		_m31       = _m13;
		_m13       = temp;
		temp       = _m41;
		_m41       = _m14;
		_m14       = temp;

		temp = _m32;
		_m32 = _m23;
		_m23 = temp;
		temp = _m42;
		_m42 = _m24;
		_m24 = temp;

		temp = _m43;
		_m43 = _m34;
		_m34 = temp;

		return *this;
	}

	// 正交投影 XOY
	Matrix4x4& ProjectionXoY()
	{
		Matrix4x4 t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	Matrix4x4& ProjectionXoZ()
	{
		Matrix4x4 t(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	Matrix4x4& ProjectionYoZ()
	{
		Matrix4x4 t(0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		(*this) = (*this) * t;
		return *this;
	}

	inline float Determinant()
	{
		// 矩阵的行列式
		return (_m11 * (_m22 * _m33 - _m21 * _m32) - _m12 * (_m21 * _m33 - _m21 * _m31) + _m13 * (_m21 * _m32 - _m22 * _m31));
	}

	// 逆矩阵
	Matrix4x4 Inverse()
	{
		float det = Determinant();
		float _r11, _r12, _r13, _r14;
		float _r21, _r22, _r23, _r24;
		float _r31, _r32, _r33, _r34;
		float _r41, _r42, _r43, _r44;
		if (det <= EPSILON)
		{
			_r11 = 0;
			_r12 = 0;
			_r13 = 0;
			_r14 = 0;
			_r21 = 0;
			_r22 = 0;
			_r23 = 0;
			_r24 = 0;
			_r31 = 0;
			_r32 = 0;
			_r33 = 0;
			_r34 = 0;
			_r41 = 0;
			_r42 = 0;
			_r43 = 0;
			_r44 = 0;
		}
		else
		{
			_r11 = (_m22 * _m33 - _m23 * _m32) / det;
			_r12 = -(_m12 * _m33 - _m13 * _m32) / det;
			_r13 = (_m12 * _m23 - _m13 * _m22) / det;
			_r14 = 0.0;


			_r21 = -(_m21 * _m33 - _m23 * _m31) / det;
			_r22 = (_m11 * _m33 - _m13 * _m31) / det;
			_r23 = -(_m11 * _m23 - _m13 * _m21) / det;
			_r24 = 0.0;

			_r31 = (_m21 * _m32 - _m22 * _m31) / det;
			_r32 = -(_m11 * _m32 - _m12 * _m31) / det;
			_r33 = (_m11 * _m22 - _m12 * _m21) / det;
			_r34 = 0.0;

			_r41 = -(_m41 * _r11 + _m42 * _r21 + _m43 * _r31) / det;
			_r42 = -(_m41 * _r12 + _m42 * _r22 + _m43 * _r32) / det;
			_r43 = -(_m41 * _r13 + _m42 * _r23 + _m43 * _r33) / det;
			_r44 = 1.0;
		}
		return Matrix4x4(_r11, _r12, _r13, _r14, _r21, _r22, _r23, _r24, _r31, _r32, _r33, _r34, _r41, _r42, _r43, _r44);
	}
};



#endif
