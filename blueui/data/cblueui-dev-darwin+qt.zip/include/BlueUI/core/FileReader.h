﻿#ifndef BLUEUI_FILEREADER_BYMD_INC_H_
#define BLUEUI_FILEREADER_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
#include <vector>
#include <string>

#include "core/CCoreBasePro.h"

class UI_EXP FileReader
{
  protected:
	DataBuffer m_buf;

  public:
	FileReader();
	~FileReader();

	int LoadFileA(const char* filename);
#ifdef _WIN32
	int LoadImageFromResource(HMODULE hMod, const TCHAR* resid, const TCHAR* restype);
#endif
	DataBuffer GetDataBuffer(BOOL skipBom = FALSE) const;
	void ClearCxxStyleComments(); // 清除注释

	static void SaveAsFile(const char* filepath, const char* data, int len);
};

//
//// 通过资源定位url，读取出数据
// class UI_EXP FileResourceByUrl : public FileReader
//{
// protected:
//     DataBuffer  m_buf_no_free;  //析构时不需要自动释放
//     DataBuffer* m_bur_cur_ptr;
// public:
//     FileResourceByUrl();
//     ~FileResourceByUrl();
//
//     DataBuffer GetDataBuffer() const;
//
//     void LoadUrl(const char* filename);
// };


#endif
