﻿#ifndef BLUEUI_XML_PARSE_DESIGNER_H__
#define BLUEUI_XML_PARSE_DESIGNER_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <assert.h>
#include <string>
#include <vector>
#include <map>

#include "core/CCoreBasePro.h"
#include "core/CCoreObject.h"
#include "core/CCoreEventHandler.h"
#include "function/XmlStorage.h"

namespace BUI {

class CControlUI;

struct ParseSetting
{
	IManageHandler* pManger;
	CControlUI* pParent;
	ILayout* pLayoutBox;
	IEventHandler* handler;
};

struct LayoutSize
{
	int layWidth;
	int layHeight;
	SizeMode wType;
	SizeMode hType;
};

typedef CControlUI* (*CreateControl_cb)(const char* typeName, const char* desClassName, const char* className);

class UI_EXP XmlBuilder
{
	typedef void (XmlBuilder::*ParseNodeProc_cb)(XMLItem* pNode, ParseSetting* param);

  public:
	XmlBuilder();
	virtual ~XmlBuilder();

	// 加载xml中的图片和文件资源
	static void ApplyResourceWithFile(const char* uixml);
	static void ApplyResourceWithFile(const wchar_t* uixml);
	static void ApplyResourceWithData(const char* data);

	/* 加载ui到指定控件内*/
	static int LoadControlUIFile(const char* file, CControlUI* pCtrl, IEventHandler* handler = NULL);
	static int LoadControlUIString(const char* xmlcontent, CControlUI* pCtrl, IEventHandler* handler = NULL);

	void SetDesignParse(BOOL bDesignParse);

	/* interface api*/
	void LoadUIFileA(LPCSTR filepath, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL);

	void LoadUIFileW(LPWSTR filepath, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL);

	void LoadBuffer(const char* xmlText, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL);
#ifdef _WIN32
	void LoadUIResource(UINT nID, LPCTSTR szType, HINSTANCE hMode, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL,
	                    IEventHandler* handler = NULL);
#endif
	void LoadUITempCache(XmlStorage* templat, IManageHandler* pManger, CControlUI* pParent = NULL, ILayout* pLayBox = NULL, IEventHandler* handler = NULL);

  private:
	void ParseUiFileUNICODE(const wchar_t* wfilename, IManageHandler* pManger, CControlUI* pParent, ILayout* pParBox, IEventHandler* handler);

	void ParseUiFile(const char* filename, IManageHandler* pManger, CControlUI* pParent, ILayout* pParBox, IEventHandler* handler);

	void ParseNode(XMLItem* pNode, ParseSetting* param);

	void ParseDesignWindow(XMLItem* pNode, ParseSetting* param);

	CControlUI* ParseControl(XMLItem* pNode, ParseSetting* param, CreateControl_cb lpCreateControl);

	void ParseNodedata(XMLItem* pNode, ParseSetting* param, CreateControl_cb lpCreateControl);

	void ParseControlFont(XMLItem* pNode, ParseSetting* param);

	void ParseImage(XMLItem* pNode, ParseSetting* param);

	void ParseDesignLayout(XMLItem* pNode, ParseSetting* param);

	void ParseLayout(XMLItem* pNode, ParseSetting* param);

	void ParseZipResurce(XMLItem* pNode, ParseSetting* param);

	void ParseSharedNode(XMLItem* pNode);

	void PreLoadClassStyle(XMLItem* root);

	XMLItem* GetStyleNode(const char* name);

  public:
	virtual void OnParseWindow(const char* desClassName, const char* className);
	virtual void OnParseControl(CControlUI* pObjCtl, const char* desClassName, const char* className, const char* objName);
	virtual CControlUI* OnParseDesLayout(IManageHandler* pM, CControlUI* parent, const char* layoutname, LayoutSize* infodata, ILayout** outBoxLayout);

  private:
	GString m_skinModule;
	GStringA m_prefix_path; // 路径前缀
	ParseNodeProc_cb m_ParseWindows_cbfun;
	ParseNodeProc_cb m_ParseLayoyt_cbfun;
	CreateControl_cb m_CreateControl_cbfun;
	std::map<std::string, XMLItem*> m_StroageStyle; // 共享风格缓存
	SIZE m_szie;
};




}

#endif