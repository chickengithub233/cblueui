#ifndef BLUEUI_XML_UIXMLTEMPLATE_BYMD_INC_H_
#define BLUEUI_XML_UIXMLTEMPLATE_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <assert.h>
#include <string>
#include <vector>

#include "core/CCoreBasePro.h"
#include "core/MarkupItem.hpp"
#include "cstring/GStringA.h"
#include "cstring/GString.h"

namespace BUI {

class UI_EXP XmlStorage
{
  private:
	BOOL m_bUtf8; // 是否进行UTF-8 To ANSI格式转换
	XMLItem m_treeRoot;
	GString m_filebaseName;
	std::vector<GStringA> m_share;

  public:
	XmlStorage();
	XmlStorage(const char* file);
	XmlStorage(const wchar_t* file);
	~XmlStorage();

	static void SaveAsXmlFile(const XMLItem* root, const char* filepath);
	void ConvertToUtf8();

	void ConfigUtf8(BOOL bUtf8);
	const char* AddShareLabel(const char* str, BOOL isKey = FALSE);
	void LoadBuffer(const char* xmlText, int len = -1);
	GString FileBaseName() const;

	XMLItem* Root();
	XMLItem* AllocXmlNode();

  private:
	void ReadFileA(const char* filefullpath);
	void FreeAlloc();
	void ReleaseTreeNode(XMLItem* node);
};



}
#endif