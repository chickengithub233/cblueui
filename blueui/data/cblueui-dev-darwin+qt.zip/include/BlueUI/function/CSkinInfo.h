﻿#ifndef BLUEUI_CSKININFO_BYMD_INC_H_
#define BLUEUI_CSKININFO_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <map>
#include <atomic>
#include "core/CCoreBasePro.h"

namespace BUI {


// 皮肤文件类
class UI_EXP CSkinStyle
{
  public:
	typedef std::string skin_strid;
	typedef std::string style_strid;

	struct pair_string
	{
		std::string name;
		std::string value;
	};

	typedef std::vector<pair_string> list_string_pair;

  public:
	CSkinStyle();
	~CSkinStyle();

	void LoadSkinFile(LPCSTR file);

	int SkinCount() const;

	skin_strid ModuleName();
	const list_string_pair* FindSkin(LPCSTR skinid);
	const list_string_pair* FindStyle(LPCSTR stylename);

  private:
	std::map<style_strid, list_string_pair> m_share_styles; // 风格储存
	std::map<skin_strid, list_string_pair> m_skins;         // 皮肤
	skin_strid m_skin_module_name;                          // 模块名
#ifdef _DEBUG
	skin_strid m_skin_file_full_name;
#endif
};

// 皮肤管理类
class UI_EXP CManagerSkin
{
	typedef std::string skin_module;

  public:
	CManagerSkin();
	~CManagerSkin();

	void LoadSkinFile(LPCSTR file);

	int Size();

	CSkinStyle* GetSkinFile(LPCSTR skin_module_name); // 获得皮肤文件对象
  private:
	std::map<skin_module, CSkinStyle> m_skin_files; // 所有皮肤映射关系
};

// 语言翻译类
class UI_EXP CLanguageTranslator
{
	typedef std::string language_string;

  public:
	CLanguageTranslator();
	~CLanguageTranslator();


	/**
	 * @brief : 加载语言文件
	 * @return: void
	 * @param : LPCSTR file 文件路径
	 * @param : BOOL bClear TRUE:清除原来的语言映射关系。
	 */
	void LoadLanguageFile(LPCSTR file, BOOL bClear = TRUE);

	LPCSTR Translate(LPCSTR key) const; // 翻译指定文本
  private:
	std::map<language_string, language_string> m_languages; // 语言映射表
};

extern "C" {
// 安装语言管理对象
UI_EXP void InstallLanguageTranslator(CLanguageTranslator* lang_trans);

// 获得语言管理对象
UI_EXP CLanguageTranslator* LanguageTranslator();

UI_EXP LPCSTR ExtractTranslateString(LPCSTR text);
}


}


#endif
