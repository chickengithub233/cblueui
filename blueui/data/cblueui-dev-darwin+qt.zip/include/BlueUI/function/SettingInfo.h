#ifndef BLUEUI_SETTING_LITE_BYMD_INC_H_
#define BLUEUI_SETTING_LITE_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
#include <vector>
#include <string>
#include <memory>
#include "core/CCoreBasePro.h"
#include "core/LinkTree.hpp"

/*JSON Types: */
#define JSON_FALSE  0
#define JSON_TRUE   1
#define JSON_NULL   2
#define JSON_NUMBER 3
#define JSON_STRING 4
#define JSON_ARRAY  5
#define JSON_OBJECT 6

class UI_EXP JsonObject
{
  public:
	JsonObject(int type);
	virtual ~JsonObject();

	void SetKeyName(const char* keyname);
	void SetValue(const char* value);

	LPCSTR ValueText() const;

	int GetObjectSize() const;

	JsonObject* GetChildObject(int index) const;

	JsonObject* FindObjectByKeyPath(const char* keyPath) const;

	JsonObject* AddLastChild(int type, const char* keyname);

	void Clear();

	void RemoveChild(JsonObject* child); // 移除某个子节点
  protected:
	void Print(FILE* fp, BOOL bFormate = FALSE, int depth = 0) const;

  public:
	std::string m_key_s;
	std::string m_value_s;
	int m_type;
	int m_valueint;
	double m_valuedouble;

	JsonObject* parent;
	JsonObject* firstChild;
	JsonObject* lastChild;
	JsonObject* prevSibling;
	JsonObject* nextSibling;
};

class UI_EXP JsonSetting : public JsonObject
{
  public:
	JsonSetting();
	virtual ~JsonSetting();

	void LoadBuffer(const char* data);

	void LoadFile(const char* filePath);

	void SaveAsFile(const char* filePath);
};






#endif
