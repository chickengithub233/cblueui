﻿
#ifndef BLUEUI_LAYOUT_BYMD_INC_H_
#define BLUEUI_LAYOUT_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string.h>
#include <vector>

#include "core/CCoreBasePro.h"
#include "core/CCoreObject.h"
#include "cstring/GStringA.h"

namespace BUI {

class CBaseLayout;

struct LayoutLinkNode
{
	BOOL isNeedFree;
	CBaseLayout* this_layout;
	struct LayoutLinkNode* prev;
	struct LayoutLinkNode* next;
};

class UI_EXP CBaseLayout : public ILayout
{
  public:
	CBaseLayout();
	virtual ~CBaseLayout();

	AlignmentStyle HorAlign();
	AlignmentStyle VerAlign();

	SizeMode WidthType();
	SizeMode HeightType();

	/**
	 *@brief: 提交边界偏移量
	 */
	void CommitCacheOffset();

	void SetDpi(int uDpi);

	/**
	 * @brief 获得布局容器的宽度
	 * @return int
	 */
	virtual int Width();
	/**
	 * @brief: 获得布局容器的高度
	 */
	virtual int Height();

	virtual void GetPosition(RECT& rc);


	int GetAdaptWidth(int expH) override;
	int GetAdaptHeight(int expW) override;

	/**
	 * @brief 设置布局信息
	 *
	 * @param w 布局占位宽度
	 * @param h 布局占位高度
	 * @param tw 布局占位方式 FILL=自适应 ，PIXEL = 像素指定值w(或h)，PERCENTAGE = 百分比
	 * @param th
	 */
	void SetLayoutInfo(int w, int h, SizeMode tw, SizeMode th) override;

	void GetLayoutInfo(int& w, int& h, SizeMode& tw, SizeMode& th) override;
	/**
	 * @brief 设置布局容器内的对象水平和垂直的对齐风格
	 *
	 * @param hor  居中，左对齐，右对齐
	 * @param ver
	 */
	void SetAlignment(AlignmentStyle hor, AlignmentStyle ver) override;

	/**
	 * @brief 设置内边距
	 *
	 * @param l 左
	 * @param r 右
	 * @param t 上
	 * @param b 下
	 */
	void SetPadding(int l, int r, int t, int b) override;

	bool IsVaild() override;
	bool IsVisibleLayout() override;

	/**
	 * @brief 执行布局操作
	 */
	void Layout(int x, int y, int w, int h) override;

	/**
	 * @brief 布局对象消息处理函数
	 */
	BOOL OnLayoutMessageProc(UINT message, WPARAM wParam, LPARAM lParam) override;

	ILayout* GetParentLayout() override;

	bool IsHasAdaptLayout() override;

	void RebuildLayout(bool isForceUpdate) override;

	LayoutType GetLayoutType() const;

  private:
	virtual BOOL ResetLayout();

  public:
	GStringA m_strName;

	int m_nScaleFactor; // 用于DPI计算
	int m_nWidth;
	int m_nHeight;

	int m_nCacheOffsetLeft;
	int m_nCacheOffsetRight;
	int m_nOffsetLeft;
	int m_nOffsetRight;

	int m_nCacheOffsetTop;
	int m_nCacheOffsetBottom;
	int m_nOffsetTop;
	int m_nOffsetBottom;

	SizeMode m_nWidMode;
	SizeMode m_nHeiMode;

	AlignmentStyle m_horAlign;
	AlignmentStyle m_verAlign;

	LayoutType m_LayoutType;
	CBaseLayout* m_pParentLayout;
	LayoutLinkNode m_link;

	PaddingInfo m_padding;

	SIZE m_szAdapt;
};

/**
 * @brief 弹性占位布局对象
 */
class UI_EXP SpacerLayout : public CBaseLayout
{
  public:
	SpacerLayout();
	~SpacerLayout();
};

/**
 * @brief UI控件布局对象
 */
class UI_EXP ControlLayout : public CBaseLayout
{
  public:
	IControlUI* m_pIControl;
	SIZE m_adaptSize;

  public:
	ControlLayout(IControlUI* pObj);
	~ControlLayout();

	int Width() override;
	int Height() override;
	int GetAdaptWidth(int expH) override;
	int GetAdaptHeight(int expW) override;
	void GetPosition(RECT& rc) override;
	bool IsVisibleLayout() override;
	bool IsVaild() override;
	void Layout(int x, int y, int w, int h) override;

	BOOL OnLayoutMessageProc(UINT message, WPARAM wParam, LPARAM lParam) override;
};

/**
 * @brief 盒子布局容器类.
 *        水平盒子: 水平计算布局对象
 *        垂直盒子: 垂直计算布局对象
 *        层叠盒子: Z方向计算方式，所有对象共享区域
 */
class UI_EXP CBoxContainLayout : public CBaseLayout
{
  public:
	LayoutLinkNode m_head;
	BOOL m_bReverse;          // 反序排列
	int m_nInterval;          // 控件之间的间隔
	int m_nOverlapOffset;     // 重叠区域位置偏移量(第二控件开始生效)
	BOOL m_bEnableAutoScroll; // 自动滚动
	int m_nAutoScrollOffset;  // 自动滚动的偏移量
	RECT m_rcBox;

	int m_nFillOrAdaptCount; // 自适应布局数量
  public:
	CBoxContainLayout(ContainLayoutBoxType boxType = VERTICAL);
	~CBoxContainLayout();
	int GetCount() const;
	SIZE GetAdaptSize();                                      // 获得布局对象适应大小
	void EnableAutoScroll(BOOL isEnable);                     // 自动滚动
	void AddAutoScrollOffset(int step);                       // 增加偏移量
	void GetAllLayout(std::vector<CBaseLayout*> lists) const; // 获得子布局列表，调试用

	int Width() override;
	int Height() override;
	bool IsVisibleLayout() override;

	void SetDpi(int uDpi);
	void RemoveAllLayout();
	int GetDistance(); // 获得行程距离

	void Layout(int x, int y, int w, int h) override;

	void SetLayoutType(ContainLayoutBoxType boxType = HORIZONTAL);
	void SetLayoutCurSel(int index);
	void SetLayoutReverse(BOOL bReverse); // 反方向排列
	void SetCrossOffset(int d);           // 设置交叉偏移量
	BOOL LayoutReverse() const;

	int GetAdaptWidth(int expH) override;
	int GetAdaptHeight(int expW) override;
	bool IsHasAdaptLayout() override;
	void GetPosition(RECT& rc) override;
	BOOL OnLayoutMessageProc(UINT message, WPARAM wParam, LPARAM lParam) override;

	/* CBaseLayout methods:*/
	BOOL ResetLayout() override;


	// 添加的布局对象需要由用户自己释放。传入指针，不负责指针的销毁
	BOOL AddLayout(CBaseLayout* pObj, BOOL bManualFree = FALSE);

	CBoxContainLayout* AddVerLayout(int w, int h, SizeMode stw, SizeMode sth);
	CBoxContainLayout* AddHorLayout(int w, int h, SizeMode stw, SizeMode sth);
	CBoxContainLayout* AddLayeredLayout(int w, int h, SizeMode stw, SizeMode sth);
	SpacerLayout* AddSpacer(int w, int h, SizeMode stw, SizeMode sth);
	ControlLayout* AddLayoutCtrl(IControlUI* pObj, int w, int h, SizeMode stw, SizeMode sth);

	// 测试点命中布局间隔的信息
	CBaseLayout* HitTestSplit(POINT pt) const;


  private:
	void LayoutHorizontal(int size, int x, int y, int w, int h);
	void LayoutVertical(int size, int x, int y, int w, int h);
	void LayoutStackBox(int x, int y, int w, int h);
};

/**
 * @brief 圆形布局对象
 */
class UI_EXP CCircleLayout : public CBoxContainLayout
{
  public:
	int m_nRadius;

  public:
	CCircleLayout();
	~CCircleLayout();

	void Layout(int x, int y, int w, int h) override;
};

/**
 * @brief  网格布局
 */
class UI_EXP CGridLayout : public CBoxContainLayout
{
  public:
	int m_columnCount;
	int m_nCellWidth;
	int m_nCellHeight;
	SizeMode m_nCellWidMode;
	SizeMode m_nCellHeiMode;
	SIZE m_invetalSize; // 网格间距尺寸
  public:
	CGridLayout();
	~CGridLayout();
	void SetIntervalSize(int cx, int cy);
	void SetColumCount(int count);
	void SetCellLayoutInfo(int w, int h, SizeMode stw, SizeMode sth);

	void Layout(int x, int y, int w, int h) override;
};


}

#endif
