﻿#ifndef BLUEUI_CMARKSHAPESTYLE_H_INCLUDED_
#define BLUEUI_CMARKSHAPESTYLE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdlib.h>
#include "core/CCoreBasePro.h"
#include "graphics/GSurface.h"

namespace BUI {

enum TypeMarkShape
{
	MS_NO_MARK = 0,
	MS_TRIANGLE,
	MS_TRIANGLE_DOWM,
	MS_TRIANGLE_LEFT,
	MS_TRIANGLE_RIGHT,
	MS_RECT,
	MS_CIRCLE,
	MS_DIAMOND,
	MS_CROSS,
};

class UI_EXP GStyleMarkShape
{
  public:
	GStyleMarkShape();
	~GStyleMarkShape();

	void SetMarkStyle(TypeMarkShape style);
	void SetMarkSize(double marksize);
	void SetMarkColor(COLORREF color);

	TypeMarkShape GetMarkStyle() const;
	double GetMarkSize() const;
	COLORREF GetMarkColor() const;

	void OnPaintMarkShape(ISurface* pSurface, int cx, int cy, const RECT& rcDiagram, RECT* rcClip);
	void OnPaintMarkShape(ISurface* pSurface, int cx, int cy, int size, const RECT& rcDiagram, RECT* rcClip);
	BOOL OnPtInMarkShape(POINT pt, int cx, int cy);

	static void PaintMarkShape(ISurface* pSurface, int cx, int cy, TypeMarkShape style, int size, COLORREF color, const RECT& rcDiagram, RECT* rcClip);
	static BOOL PtInMarkShape(POINT pt, int cx, int cy, TypeMarkShape style, int size);

  protected:
	TypeMarkShape m_markStyle;
	double m_nMarkSize;
	COLORREF m_MarkColor;
};

}
#endif
