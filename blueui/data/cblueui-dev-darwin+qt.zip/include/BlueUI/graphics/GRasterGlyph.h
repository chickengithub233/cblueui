﻿#ifndef BLUEUI_CGLYPHRASTER_BYMD_INC_H_
#define BLUEUI_CGLYPHRASTER_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"

class UI_EXP GRasterGlyph
{
  public:
	GRasterGlyph(const UINT8* font, unsigned glyph_index);
	GRasterGlyph(const UINT8* bits);

	GRasterGlyph(const UINT8* bits, int w, int h);

	~GRasterGlyph();

	void Attach(const UINT8* font, unsigned glyph_index);
	void Attach(const UINT8* bits);
	int width() const;
	int height() const;

	const UINT8* Bits() const;

  protected:
	const UINT8* m_bits;
	int m_width_;
	int m_height_;
};

/* bitmap mono font (点阵位图字体等宽字体)*/
class UI_EXP UIFontBM
{
  public:
	UIFontBM(unsigned char* bits, int w, int h);

	~UIFontBM();

	unsigned char* GetGlphyByIndex(int i) const;

	int Width() const;
	int Height() const;
	int GlphySize() const;

  protected:
	unsigned char* bitmapdata_;
	int w_;
	int h_;
};


#endif
