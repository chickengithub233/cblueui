﻿#ifndef BLUEUI_CCOLORUNTILS_INCLUDED_
#define BLUEUI_CCOLORUNTILS_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"

namespace UtilsColor {

UI_EXP COLORREF GrayColor(COLORREF color);
UI_EXP COLORREF HSVColor(float h, float s = 1, float v = 1);
UI_EXP COLORREF ParseColor(const char* lpcolor);

UI_EXP COLORREF Get24PhaseColor(int i);
UI_EXP BOOL ParseHSVColor(const char* lpcolor, float* h, float* s, float* v);


UI_EXP void RGB_2_HSV(COLORREF color, float* h, float* s, float* v);
/*r|g|b = [0 - 1], h = [0,360] s= [0, 1] v = [0, 1]*/
UI_EXP void RGB_2_HSV(float r, float g, float b, float* h, float* s, float* v);
UI_EXP void HSV_2_RGB(float* r, float* g, float* b, float h, float s, float v);
UI_EXP bool ParseStringToColor(const TCHAR* lpcolor, COLORREF* color);


};

class UI_EXP GColor
{
  public:
	GColor();
	GColor(ULONG color);
	GColor(ULONG color, UINT8 alpha);
	GColor(UINT8 ir, UINT8 ig, UINT8 ib, UINT8 ia = 255);

	~GColor();

	const GColor& operator=(const GColor& other);
	bool operator==(const GColor& other);
	bool operator!=(const GColor& other);

	DWORD ToABGR() const; // 转换颜色为aBGR顺序

	void ToHsvColor(float& h, float& s, float v); // 转换颜色为HSV顺序
	COLORREF ToGray(); //转换为灰度值
public:
	UINT8 r;
	UINT8 g;
	UINT8 b;
	UINT8 a; // 0:全透明，255不透明
};

class UI_EXP GColorHSV
{
  public:
	GColorHSV();
	GColorHSV(float h_, float s_ = 1, float v_ = 1);
	~GColorHSV();

	GColor ToRGBColor();

  public:
	float h; // [0~360]
	float s; // [0~1]
	float v; // [0~1]
};




#endif