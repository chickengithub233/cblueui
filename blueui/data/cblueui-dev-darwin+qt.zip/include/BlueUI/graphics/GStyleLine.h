﻿#ifndef BLUEUI_CLINESTYLE_H_INCLUDED_
#define BLUEUI_CLINESTYLE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdlib.h>
#include "core/CCoreBasePro.h"
#include "graphics/GSurface.h"

namespace BUI {

enum LineMode
{
	LM_NO_Line, // 无线条
	LM_Step,    // 步进式
	LM_Line,    // 直线
	LM_Spline,  // spline插值样条
};

class UI_EXP GStyleLine
{
  public:
	GStyleLine();
	~GStyleLine();

	void SetLineColor(GColor color);
	void SetLineType(LineBrushStyle style);
	void FillAreaPath(BOOL bFill);
	void SetLineMode(LineMode mode);
	void SetLineWidth(int weight);

	BOOL IsFillAreaPath() const;
	int GetLineWidth() const;
	GColor GetLineColor() const;
	LineBrushStyle GetLineType() const;
	LineMode GetLineMode() const;

  protected:
	LineBrushStyle m_penType;
	LineMode m_lineMode;
	GColor m_pencolor;
	BOOL m_bFillPath;
	int m_nPenWidth;
};

// 渐变背景
class UI_EXP GradientRoundRect
{
  public:
	GradientRoundRect(GColor color);
	GradientRoundRect(GBrushGradient* bru = NULL);
	~GradientRoundRect();

	void SetRoundRectRadius(RoundRectRadius& radius);
	void SetSolidColor(GColor color);
	void SetGraientColor(GBrushGradient* bru);
	void DrawBackGround(ISurface* pSurface, RECT& rcView);


  protected:
	GColor m_solid_color;
	GBrushGradient* m_bru;
	RoundRectRadius m_RoundRadius;
};




}
#endif
