﻿
#ifndef BLUEUI_CRESOURCEGRAPHICS_BYMD_INC_H_
#define BLUEUI_CRESOURCEGRAPHICS_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
#include "core/CCoreBasePro.h"
#include "cstring/GStringA.h"
#include "cstring/GString.h"


class GImage;
class GImageGIF;
class GPathStorageSVG;
class GradientColors;
class GBrushGradient;
class GImageIconInfo;
#ifdef USE_MINIZIP
class FileReaderZip;
#endif

class UI_EXP CResourceGraphics
{
  public:
	CResourceGraphics();
	~CResourceGraphics();

  private:
	std::map<GStringA, std::map<GStringA, COLORREF> > m_mapColors;
	std::map<GStringA, GImage*> m_mapSGimg;
	std::map<GStringA, GImageGIF*> m_mapSGimgGif;
	std::map<GStringA, GPathStorageSVG*> m_mapSvg;

	std::map<GStringA, GradientColors*> m_mapGradientColors;
	std::map<GStringA, GBrushGradient*> m_mapGradientBrush;

	std::map<GStringA, GImageIconInfo*> m_mapImageStatus; // 图标组合状态
#ifdef USE_MINIZIP
	std::map<GStringA, FileReaderZip*> m_mapZip;
#endif
  public:
	// GImage资源
	GImage* LoadSGImageFromBuffer(const char* id, unsigned char* buffer, UINT dwSize);
	GImage* GetSGImage(const char* id);

	// GImage GIF资源
	GImageGIF* LoadSGImageGIFFromBuffer(const char* id, unsigned char* buffer, UINT dwSize);
	GImageGIF* GetSGImageGIF(const char* id);

	// SVG_HANDLE资源
	GPathStorageSVG* LoadSVGFromBuffer(const char* id, const char* buffer, UINT dwSize);
	GPathStorageSVG* GetSVGImage(const char* id);

	// Colors资源
	void AddColors(const char* id, std::map<GStringA, COLORREF>& colors);
	void GetColors(const char* id, COLORSTYLE& outColors);

	// Gradient Colors资源
	void AddGradientColors(const char* id, GradientColors* gra_colors);
	GradientColors* GetGradientColors(const char* id);


	// Gradient brush
	void AddGradientBrush(const char* id, GBrushGradient* linear);
	GBrushGradient* GetGradientBrush(const char* id);


	// Gradient brush
	void AddSGImageIconInfo(const char* id, GImageIconInfo* icon);
	GImageIconInfo* GetSGImageIconInfo(const char* id);

	// zip resource
	DataBuffer GetZipArchiveFileData(const char* zipfile, const char* archiveName);
};

extern "C" {
// 安装资源管理对象
UI_EXP void InstallResourceGraphics(CResourceGraphics* res);
// 获得资源管理对象
UI_EXP CResourceGraphics* ResourceGraphics();
}


#endif