﻿#ifndef BLUEUI_SGENGINE_CORE_SGImage_PRO_H_INCLUDED_
#define BLUEUI_SGENGINE_CORE_SGImage_PRO_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdlib.h>
#include "core/CCoreBasePro.h"
#include "core/CTimerWheel.h"

class UI_EXP GImage
{
  public:
	GImage();
	virtual ~GImage();

	virtual bool LoadBufferImage(unsigned char* buffer, UINT dwSize);

	UBYTE* Buffer() const;

	SIZE ImageSize() const;

	// 获得多帧图片的某一帧
	void GetXImageInfoInFrames(XImageInfo* info, BOOL isHroz, int current, int frameCounts) const;

	// 获得整张图片
	void GetXImageInfo(XImageInfo* info) const;

	// 获得某一区域
	void GetXImageInfoInArea(XImageInfo* info, int x, int y, int w, int h) const;

	int Stride() const;
	int StrideAbs() const;
	int PixelBitCounts() const;

	void Destory();

  protected:
	int m_iWidth;
	int m_iHeight;
	int m_nBpp;
	int m_nStride;
	unsigned char* m_pBuffer;
	XPixelFormat m_pixelformat; // 像素格式
};

class UI_EXP IGIFHost
{
  public:
	IGIFHost()
	    : next(NULL)
	    , prev(NULL){};
	~IGIFHost(){};
	virtual void OnUpdataUI(){};
	virtual void OnUpdataAll(){};
	virtual void OnFreeObject(){};

  public:
	IGIFHost* next;
	IGIFHost* prev;
};

class UI_EXP GImageGIF : public GImage
{

  public:
	GImageGIF();
	virtual ~GImageGIF();

	bool LoadBufferImage(unsigned char* buffer, UINT dwSize) override;

	/* gif api*/
	int LayerCounts() const;
	int Delay(int l) const;
	int GetCurPos() const;

	void AddHost(IGIFHost* host);

  protected:
	void OnTimerGif();

  protected:
	int m_nLayers;
	int* m_nDelays;
	timer_handler* m_timer_;
	UINT m_nCurpos;

	IGIFHost m_head; // ui 列表
};

#endif
