#ifndef BLUEUI_PLATFORMDEF_ALL_BYMD_INC_H_
#define BLUEUI_PLATFORMDEF_ALL_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#if (defined USE_LIB_SDL2)
#include "platform/SDL2/WindowPlatform.h"
#elif (defined USE_LIB_QT)
#include "platform/qt/WindowPlatform.h"
#elif (defined _WIN32)
#include "platform/win/WindowPlatform.h"
#endif



#endif