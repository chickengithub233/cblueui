﻿#ifndef BLUEUI_CRESOURCEFONT_BYMD_INC_H_
#define BLUEUI_CRESOURCEFONT_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "core/CCoreBasePro.h"
#include "platform/GFont.h"

#include <map>

enum FONT_SIZE_LEVEL
{
	FLS_LEVEL_0 = 0x01, // 标题字体(值越大，字体越小)
	FLS_LEVEL_0_LOW,
	FLS_LEVEL_1,
	FLS_LEVEL_2,
	FLS_LEVEL_2_LOW,
	FLS_LEVEL_3,
	FLS_LEVEL_4,
	FLS_LEVEL_4_LOW,
	FLS_LEVEL_5,
	FLS_LEVEL_5_LOW,
	FLS_LEVEL_6,
	FLS_LEVEL_7
};

class UI_EXP CResourceFont
{
  private:
	GFont* m_FontNormal[FLS_LEVEL_7];     // 7级普通文体
	GFont* m_FontUnderline[FLS_LEVEL_7];  // 7级下划线字体
	GFont* m_FontBold[FLS_LEVEL_7];       // 7级粗体
	GFont* m_FontItalic[FLS_LEVEL_7];     // 7级斜体
	std::map<GString, GFont*> mapFont;    // 字体缓存
	std::map<GStringA, GFont*> mapidFont; // 字体缓存
  public:
	CResourceFont();
	~CResourceFont();

	void AddFont(const char* id, GFont* hFont);
	GFont* GetFont(const char* id);
	GFont* GetFont(LPCTSTR lpName, int lfHeight, UINT style);
	GFont* GetFontNormal(UINT fontID);
	GFont* GetFontUnderLine(UINT fontID);
	GFont* GetFontBold(UINT fontID);
	GFont* GetFontItalic(UINT fontID);
};

/* 字体资源工具集 */
namespace UtilsFont {

UI_EXP GFont* GetDefaultFontNormal();
UI_EXP GFont* GetDefaultLinkFont();
UI_EXP GFont* GetDefaultFontBold();
UI_EXP GFont* GetDefaultFontItalic();

UI_EXP GFont* GetHFont(LPCTSTR lpName, int lfHeight, UINT style);

UI_EXP void AddFont(const char* id, GFont* hFont);
UI_EXP GFont* GetHFont(const char* id);

};

extern "C" {
// 安装字体管理对象
UI_EXP void InstallResourceFont(CResourceFont* fontMgr);

UI_EXP CResourceFont* ResourceFont(); // 获得字体管理对象
}

#endif
