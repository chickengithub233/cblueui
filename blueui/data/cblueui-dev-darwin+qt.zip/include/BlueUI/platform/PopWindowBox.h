#ifndef BLUEUI_POPWINDOWBOX_BYMD_INC_H_
#define BLUEUI_POPWINDOWBOX_BYMD_INC_H_

#pragma once

#include "platform/WindowPlatformInc.h"
#include "platform/UIManager.h"

namespace BUI {

class UI_EXP PopWindowManager
{
  public:
	PopWindowManager();
	~PopWindowManager();

	void PopFrameShow(UIManager* manager, RECT* rcView);

  protected:
	WindowPlatform* GetWindowPlatform(void* ptr);

  public:
	std::map<void*, WindowPlatform*> m_mapwins;
};

}

extern "C" {
// ��װ������������
UI_EXP void InstallPopWindowManager(PopWindowManager* popwin);

// ��õ�����������
UI_EXP PopWindowManager* GetPopWindowManager();
}

#endif