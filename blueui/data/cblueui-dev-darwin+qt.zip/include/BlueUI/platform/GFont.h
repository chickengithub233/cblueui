#ifndef BLUEUI_UIFONT_PLATFORM_BYMD_INC_H_
#define BLUEUI_UIFONT_PLATFORM_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#ifdef FT2_BUILD_LIBRARY
#include "platform/SDL2/OnTTF/GFontTTF.h"
#elif (defined USE_LIB_QT)
#include "platform/qt/GFontQt.h"
#elif defined __APPLE__
#include "platform/SDL2/OnCocoa/GFontCocoa.h"
#elif defined _WIN32
#include "platform/win/GFontWin.h"
#endif



#endif
