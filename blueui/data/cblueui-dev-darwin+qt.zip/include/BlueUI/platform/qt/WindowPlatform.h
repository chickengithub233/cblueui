#ifndef BLUEUI_PLATFORMDEF_18DD04_INC_H_
#define BLUEUI_PLATFORMDEF_18DD04_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <memory>

#include "CWidgetQt.h"
#include "AdapterPlatformQt.h"

namespace BUI {

class UI_EXP WindowPlatform
{
  public:
	WindowPlatform();
	~WindowPlatform();

	void CreatePlatform(WindowPlatform* parent, LPCTSTR title, UINT style, RECT rc);
	std::shared_ptr<IAdapterPlatform> CreateAapter(IManageHandler* manager);

	void CenterWindow();
	UINT DoModal();
	BOOL IsShow() const;

  public:
	CWidgetQt wnd_;
};
}



#endif