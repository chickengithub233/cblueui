﻿#ifndef BLUEUI_DISPLAY_GSURFACEPAINTER_QT_INC_H_
#define BLUEUI_DISPLAY_GSURFACEPAINTER_QT_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "platform/GSurfacePainter.h"
#include <qpainter.h>

class GSurfacePainterQt : public GSurfacePainter
{
  public:
	QPainter* m_painter;

  public:
	GSurfacePainterQt(QPainter* painter);
	virtual ~GSurfacePainterQt();

	GFont* SelectPainterFont(GFont* font) override;
	void SetPainterClipRect(int x, int y, int w, int h, bool enable, int orgX = 0, int orgY = 0) override;
	void DoPaintTextMultiLine(int x, int y, TextMultilineInfo* multiText, COLORREF color, UINT align = DT_LEFT | DT_TOP, int orgX = 0, int orgY = 0) override;
	void DoPaintTextOutW(int x, int y, LPCWSTR text, int c, COLORREF color, UINT align = DT_LEFT | DT_TOP, int orgX = 0, int orgY = 0) override;
	void DoPaintTextOutA(int x, int y, LPCSTR text, int c, COLORREF color, UINT align = DT_LEFT | DT_TOP, int orgX = 0, int orgY = 0) override;
	void DoPaintTextOut(int x, int y, LPCTSTR text, int c, COLORREF color, UINT align = DT_LEFT | DT_TOP, int orgX = 0, int orgY = 0) override;

	void DoPaintTextW(LPRECT lprc, LPCWSTR text, int c, COLORREF color, UINT format, int orgX = 0, int orgY = 0) override;
	void DoPaintTextA(LPRECT lprc, LPCSTR text, int c, COLORREF color, UINT format, int orgX = 0, int orgY = 0) override;
	void DoPaintText(LPRECT lprc, LPCTSTR text, int c, COLORREF color, UINT format, int orgX = 0, int orgY = 0) override;

	void DoPaintTextAngleW(int x, int y, float angle, LPCWSTR sztext, int nlen, COLORREF color, UINT align = DT_LEFT | DT_TOP, int orgX = 0,
	                       int orgY = 0) override;
	void DoPaintTextAngleA(int x, int y, float angle, LPCSTR sztext, int nlen, COLORREF color, UINT align = DT_LEFT | DT_TOP, int orgX = 0,
	                       int orgY = 0) override;
	void DoPaintTextAngle(int x, int y, float angle, LPCTSTR sztext, int nlen, COLORREF color, UINT align = DT_LEFT | DT_TOP, int orgX = 0,
	                      int orgY = 0) override;
};

#endif
