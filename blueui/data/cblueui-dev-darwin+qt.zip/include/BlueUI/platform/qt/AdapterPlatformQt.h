#ifndef ADAPTERPLATFORMQT_H
#define ADAPTERPLATFORMQT_H

#pragma once

#include "core/CCoreBasePro.h"
#include "core/CCoreObject.h"

#include <qwidget.h>
#include <qevent.h>
#include <qimage.h>

namespace BUI {

class UI_EXP AdapterPlatformQt : public QObject, public IAdapterPlatform
{
  public:
	AdapterPlatformQt(IManageHandler* manager, QWidget* wnd);
	~AdapterPlatformQt();

	/* QObject  menthos:*/
	bool eventFilter(QObject* watched, QEvent* event) override;

	/* IAdapterPlatform menthos: */
	UINT MessageLoop() override;
	BOOL IsZoomed() override;
	BOOL IsWindowVisible() override;
	BOOL SendMessage(UINT uMsg, WPARAM wParam = 0L, LPARAM lParam = 0L) override;
	BOOL PostMessage(UINT uMsg, WPARAM wParam = 0L, LPARAM lParam = 0L) override;
	BOOL OnPlatformHandler(UINT message, WPARAM wp, LPARAM lp) override;
	void GetClientRect(RECT* rc) override;
	void GetWindowRect(RECT* rc) override;
	void SetActiveWindow() override;
	void EnableWindow(BOOL enable) override;
	void ShowWindow(UINT model) override;
	void MoveWindow(int X, int Y, int nWidth, int nHeight, BOOL bRepaint) override;
	void InvalidateRect(RECT* rc, BOOL bSyncUpdate = FALSE) override;
	void ClientPointToScreen(POINT* pt) override;
	void ScreenPointToClient(POINT* pt) override;
	BOOL AnimateWindow(DWORD dwTime, DWORD dwFlags) override;

  protected:
	bool mousemoveEvent(QMouseEvent* event, QEvent::Type type);
	bool mousebuttonEvent(QMouseEvent* event, QEvent::Type type);

	void keyboardEvent(QKeyEvent* event, QEvent::Type type);
	void inputMethodEvent(QInputMethodEvent* e);
	void mousewheelEvent(QWheelEvent* event);
	void paintEvent(QPaintEvent* event);
	void paintSurface(QPainter* paint, QImage* paintbuf, double ra, QRect& rcClip, QRect& rcSource, int orgX, int orgY);

	void SetMouseCursor(CURSOR_MOUSE id);

	void OpenSystemFile(WPARAM wp);
	void OpenSystemFont(WPARAM wp);
	void OpenSystemColor(WPARAM wp);

	void CheckBufferSurfaceSize(double ra); // ��֤����ʹ�����ͬ����С
  protected:
	QWidget* m_wnd;
	QRect m_restore_max_rc;
	COLORREF m_bg_color;
	POINT m_ime_cursor_pos;
	BOOL m_need_show_ime;
	UINT m_Types;
	QImage* m_bufferSurface;
	QImage* m_backBuf;
};

}

#endif
