﻿#ifndef BLUEUI_CGLOBALRESOURCES_BYMD_INC_H_
#define BLUEUI_CGLOBALRESOURCES_BYMD_INC_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <map>
#include <atomic>
#include "core/CCoreBasePro.h"
#include "core/CCoreObject.h"
#include "core/CTimerWheel.h"
#include "function/CSkinInfo.h"
#include "uicontrol/CControlUI.h"
#include "graphics/CResourceGraphics.h"
#include "CControlGC.h"
#include "PopWindowBox.h"
#include "CResourceFont.h"

namespace BUI {


struct UI_EXP UISystemStartUp
{
	UISystemStartUp();
	~UISystemStartUp();

	POINT ptTrace;
	CLanguageTranslator langTranslator;
	CControlGC controlGC;
	PopWindowManager windowManager;
	TimerWheel timerMgr;
	CResourceFont resFont;
	CResourceGraphics resGraphics;
};

extern "C" {

/**
 * @brief 初始化UI系统，并启动服务
 *
 */
UI_EXP int InitializeUISystem(UISystemStartUp* gc); // 初始化UI系统，并启动服务

/**
 * @brief 设置鼠标的跟踪的起点位置，该位置用来计算当前位置，与跟踪位置的距离
 *
 * @param pt 需要标记的位置
 */
UI_EXP void SetMouseTracePoint(POINT pt);

/**
 * @brief 获得跟踪标记的位置
 *
 */
UI_EXP POINT GetMouseTracePoint();
}



}
#endif
